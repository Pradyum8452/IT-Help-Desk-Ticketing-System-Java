-- =====================================================================
-- PROJECT: IT Help Desk Ticketing and Service Management System
-- COURSE : TY EXTC Java Programming Micro Project (A.Y. 2026-2027)
-- DBMS   : MySQL 8.0+
-- FILE   : database/helpdesk.sql
-- =====================================================================

DROP DATABASE IF EXISTS helpdesk_db;
CREATE DATABASE helpdesk_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE helpdesk_db;

-- =====================================================================
-- 1. TABLE: users
-- Stores all system accounts (ADMIN, TECHNICIAN, USER).
-- Passwords are stored as 64-character SHA-256 hexadecimal hashes.
-- =====================================================================
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    department VARCHAR(80) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(64) NOT NULL,
    role ENUM('ADMIN', 'TECHNICIAN', 'USER') NOT NULL DEFAULT 'USER',
    status ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================================
-- 2. TABLE: technicians
-- Stores technician profile, specialization, and availability status.
-- Linked optionally to users(user_id) for role-based technician login.
-- =====================================================================
CREATE TABLE technicians (
    technician_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    specialization ENUM('Hardware', 'Software', 'Network', 'Database', 'General Support') NOT NULL,
    status ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_technician_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 3. TABLE: tickets
-- Stores support tickets raised by users and assigned to technicians.
-- Relationships:
--   users (1)       ---> (M) tickets (via user_id)
--   technicians (1) ---> (M) tickets (via technician_id)
-- =====================================================================
CREATE TABLE tickets (
    ticket_id VARCHAR(20) PRIMARY KEY,
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Hardware', 'Software', 'Network', 'Printer', 'Email', 'Account/Login', 'Other') NOT NULL,
    priority ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
    status ENUM('OPEN', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED') NOT NULL DEFAULT 'OPEN',
    user_id INT NOT NULL,
    technician_id INT NULL,
    resolution_details TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    CONSTRAINT fk_ticket_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_ticket_technician
        FOREIGN KEY (technician_id) REFERENCES technicians(technician_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 4. TABLE: ticket_history
-- Stores chronological audit trail of every status and assignment change.
-- Relationship:
--   tickets (1) ---> (M) ticket_history (via ticket_id)
-- =====================================================================
CREATE TABLE ticket_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(20) NOT NULL,
    previous_status VARCHAR(30) NULL,
    new_status ENUM('OPEN', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED') NOT NULL,
    changed_by INT NOT NULL,
    change_description TEXT NOT NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_ticket
        FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_history_user
        FOREIGN KEY (changed_by) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- =====================================================================
-- 5. SAMPLE DATA: USERS (ADMIN, TECHNICIANS, USERS)
-- SHA-256 Hashes:
--   Admin@123 -> e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7
--   Tech@123  -> ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99
--   User@123  -> 3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72
-- =====================================================================
INSERT INTO users (user_id, name, email, phone, department, username, password, role, status, created_at) VALUES
(1, 'System Administrator', 'admin@helpdesk.com', '9876543210', 'IT Administration', 'admin',
    'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'ADMIN', 'ACTIVE', '2026-09-01 09:00:00'),
(2, 'Rohan Deshmukh', 'technician@helpdesk.com', '9876543211', 'IT Infrastructure', 'technician',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-01 09:15:00'),
(3, 'Ananya Kulkarni', 'ananya.tech@helpdesk.com', '9876543212', 'IT Software Support', 'ananya_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-02 10:00:00'),
(4, 'Vikram Joshi', 'vikram.tech@helpdesk.com', '9876543213', 'Hardware & Peripherals', 'vikram_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-02 11:00:00'),
(5, 'Suresh Nair', 'suresh.tech@helpdesk.com', '9876543214', 'Database Operations', 'suresh_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'INACTIVE', '2026-09-03 10:00:00'),
(6, 'Aarav Sharma', 'user@helpdesk.com', '9820112233', 'EXTC Engineering Lab', 'user',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-05 09:30:00'),
(7, 'Priya Patil', 'priya.patil@helpdesk.com', '9820112244', 'Accounts & Finance', 'priya_p',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-06 10:15:00'),
(8, 'Karan Mehta', 'karan.mehta@helpdesk.com', '9820112255', 'Human Resources', 'karan_m',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-07 14:20:00');

-- =====================================================================
-- 6. SAMPLE DATA: TECHNICIANS
-- =====================================================================
INSERT INTO technicians (technician_id, user_id, name, email, phone, specialization, status, created_at) VALUES
(1, 2, 'Rohan Deshmukh', 'technician@helpdesk.com', '9876543211', 'Network', 'ACTIVE', '2026-09-01 09:15:00'),
(2, 3, 'Ananya Kulkarni', 'ananya.tech@helpdesk.com', '9876543212', 'Software', 'ACTIVE', '2026-09-02 10:00:00'),
(3, 4, 'Vikram Joshi', 'vikram.tech@helpdesk.com', '9876543213', 'Hardware', 'ACTIVE', '2026-09-02 11:00:00'),
(4, 5, 'Suresh Nair', 'suresh.tech@helpdesk.com', '9876543214', 'Database', 'INACTIVE', '2026-09-03 10:00:00');

-- =====================================================================
-- 7. SAMPLE DATA: TICKETS
-- =====================================================================
INSERT INTO tickets (ticket_id, subject, description, category, priority, status, user_id, technician_id, resolution_details, created_at, updated_at, resolved_at) VALUES
('HD-2026-0001', 'Lab Switch Port VLAN Connectivity Drop',
 'Workstations in EXTC Lab 3 cannot reach the internal license server on subnet 10.20.4.0/24 since morning reboot.',
 'Network', 'Critical', 'IN_PROGRESS', 6, 1, NULL,
 '2026-10-01 09:15:00', '2026-10-01 10:45:00', NULL),

('HD-2026-0002', 'MATLAB 2026a License Activation Error on Workstation 12',
 'Launching MATLAB displays Error -96: License Manager daemon unreachable after Windows security update.',
 'Software', 'High', 'ASSIGNED', 6, 2, NULL,
 '2026-10-02 11:20:00', '2026-10-02 12:00:00', NULL),

('HD-2026-0003', 'HP LaserJet Pro M404 Paper Jam & Toner Sensor Fault',
 'Department network printer shows persistent paper jam message even after clearing the rear duplex tray.',
 'Printer', 'Medium', 'OPEN', 7, NULL, NULL,
 '2026-10-03 14:10:00', '2026-10-03 14:10:00', NULL),

('HD-2026-0004', 'Outlook IMAP Sync Freezing on Large Attachments',
 'Corporate email client hangs whenever synchronizing attachments larger than 10 MB.',
 'Email', 'Low', 'RESOLVED', 6, 1,
 'Rebuilt local OST cache file, enabled cached Exchange mode with 6-month sync window, and verified TLS 1.3 port 993 settings.',
 '2026-09-28 10:00:00', '2026-09-29 16:30:00', '2026-09-29 16:30:00'),

('HD-2026-0005', 'SSD Boot Failure on Accounts Desktop PC-04',
 'System halts at BIOS splash screen with SMART status warning on primary NVMe drive.',
 'Hardware', 'Critical', 'CLOSED', 7, 3,
 'Replaced faulty 512GB NVMe SSD under warranty, restored disk image from nightly NAS backup, and verified user data integrity.',
 '2026-09-25 08:45:00', '2026-09-26 17:15:00', '2026-09-26 15:00:00'),

('HD-2026-0006', 'SSO Portal Password Reset & 2FA Token Lockout',
 'Unable to log into the employee self-service portal after changing mobile handset.',
 'Account/Login', 'High', 'OPEN', 8, NULL, NULL,
 '2026-10-04 08:30:00', '2026-10-04 08:30:00', NULL);

-- =====================================================================
-- 8. SAMPLE DATA: TICKET HISTORY
-- =====================================================================
INSERT INTO ticket_history (ticket_id, previous_status, new_status, changed_by, change_description, changed_at) VALUES
('HD-2026-0001', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: Critical).', '2026-10-01 09:15:00'),
('HD-2026-0001', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Rohan Deshmukh (Network) by Admin.', '2026-10-01 09:40:00'),
('HD-2026-0001', 'ASSIGNED', 'IN_PROGRESS', 2, 'Technician Rohan Deshmukh accepted ticket and started VLAN trunk diagnostics.', '2026-10-01 10:45:00'),

('HD-2026-0002', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: High).', '2026-10-02 11:20:00'),
('HD-2026-0002', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Ananya Kulkarni (Software) by Admin.', '2026-10-02 12:00:00'),

('HD-2026-0003', NULL, 'OPEN', 7, 'Ticket created by user Priya Patil (Priority: Medium).', '2026-10-03 14:10:00'),

('HD-2026-0004', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: Low).', '2026-09-28 10:00:00'),
('HD-2026-0004', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Rohan Deshmukh by Admin.', '2026-09-28 11:15:00'),
('HD-2026-0004', 'ASSIGNED', 'IN_PROGRESS', 2, 'Technician started rebuilding Outlook profile.', '2026-09-29 11:00:00'),
('HD-2026-0004', 'IN_PROGRESS', 'RESOLVED', 2, 'Resolved: Rebuilt local OST cache file and verified TLS 1.3 settings.', '2026-09-29 16:30:00'),

('HD-2026-0005', NULL, 'OPEN', 7, 'Ticket created by user Priya Patil (Priority: Critical).', '2026-09-25 08:45:00'),
('HD-2026-0005', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Vikram Joshi (Hardware) by Admin.', '2026-09-25 09:05:00'),
('HD-2026-0005', 'ASSIGNED', 'IN_PROGRESS', 4, 'Technician diagnosed faulty NVMe drive and initiated replacement.', '2026-09-25 11:30:00'),
('HD-2026-0005', 'IN_PROGRESS', 'RESOLVED', 4, 'Resolved: Replaced NVMe SSD and restored backup image.', '2026-09-26 15:00:00'),
('HD-2026-0005', 'RESOLVED', 'CLOSED', 7, 'User confirmed resolution and closed ticket.', '2026-09-26 17:15:00'),

('HD-2026-0006', NULL, 'OPEN', 8, 'Ticket created by user Karan Mehta (Priority: High).', '2026-10-04 08:30:00');
