package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DBConnection handles JDBC connectivity to the MySQL 8+ helpdesk_db database.
 * Demonstrates Centralized Connection Management and Resource Cleanup.
 */
public class DBConnection {

    // Database configuration constants
    private static final String DB_HOST = System.getenv().getOrDefault("DB_HOST", "localhost");
    private static final String DB_PORT = System.getenv().getOrDefault("DB_PORT", "3306");
    private static final String DB_NAME = System.getenv().getOrDefault("DB_NAME", "helpdesk_db");
    private static final String DB_USER = System.getenv().getOrDefault("DB_USER", "root");
    private static final String DB_PASSWORD = System.getenv().getOrDefault("DB_PASSWORD", "root");

    // JDBC URL for MySQL 8+ Connector/J
    private static final String JDBC_URL = String.format(
            "jdbc:mysql://%s:%s/%s?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
            DB_HOST, DB_PORT, DB_NAME
    );

    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    // Static initializer loads the MySQL JDBC driver once when the class is loaded
    static {
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("[DBConnection] CRITICAL ERROR: MySQL JDBC Driver not found in classpath.");
            System.err.println("Please add mysql-connector-j-8.x.x.jar to your project libraries.");
        }
    }

    // Private constructor prevents unnecessary instantiation
    private DBConnection() {
    }

    /**
     * Opens and returns a new Connection to the MySQL database.
     *
     * @return active java.sql.Connection
     * @throws SQLException if database credentials are wrong or MySQL server is down
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }

    /**
     * Tests whether the database connection is available.
     *
     * @return true if connection succeeds, false otherwise
     */
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("[DBConnection] Connection test failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Safely closes a Connection resource without throwing checked exceptions.
     */
    public static void closeQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing Connection: " + e.getMessage());
            }
        }
    }

    /**
     * Safely closes a PreparedStatement resource.
     */
    public static void closeQuietly(PreparedStatement pstmt) {
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing PreparedStatement: " + e.getMessage());
            }
        }
    }

    /**
     * Safely closes a ResultSet resource.
     */
    public static void closeQuietly(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing ResultSet: " + e.getMessage());
            }
        }
    }

    /**
     * Overloaded utility method to close ResultSet, PreparedStatement, and Connection in reverse order.
     */
    public static void closeQuietly(ResultSet rs, PreparedStatement pstmt, Connection conn) {
        closeQuietly(rs);
        closeQuietly(pstmt);
        closeQuietly(conn);
    }
}
