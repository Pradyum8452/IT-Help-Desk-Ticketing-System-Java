package utils;

import model.Technician;
import model.User;

/**
 * SessionManager maintains the currently authenticated User and Technician
 * across Swing frames and enforces role-based access checks.
 */
public class SessionManager {

    private static User currentUser;
    private static Technician currentTechnician;

    private SessionManager() {
    }

    public static void login(User user, Technician technician) {
        currentUser = user;
        currentTechnician = technician;
    }

    public static void logout() {
        currentUser = null;
        currentTechnician = null;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static Technician getCurrentTechnician() {
        return currentTechnician;
    }

    public static boolean isLoggedIn() {
        return currentUser != null;
    }

    public static boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }

    public static boolean isTechnician() {
        return currentUser != null && currentUser.isTechnician();
    }

    public static boolean isRegularUser() {
        return currentUser != null && currentUser.isRegularUser();
    }
}
