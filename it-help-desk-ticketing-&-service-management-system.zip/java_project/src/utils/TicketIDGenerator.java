package utils;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Year;

/**
 * TicketIDGenerator automatically generates unique sequential Ticket IDs
 * in the format HD-YYYY-XXXX (e.g., HD-2026-0001).
 */
public class TicketIDGenerator {

    private static final String PREFIX = "HD";

    private TicketIDGenerator() {
    }

    /**
     * Queries the MySQL tickets table for the latest ticket ID in the current year
     * and generates the next sequential ID (e.g., HD-2026-0007).
     */
    public static String generateNextTicketId() {
        int currentYear = Year.now().getValue();
        String yearPrefix = String.format("%s-%d-", PREFIX, currentYear);
        String sql = "SELECT ticket_id FROM tickets WHERE ticket_id LIKE ? ORDER BY ticket_id DESC LIMIT 1";

        int nextSequence = 1;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, yearPrefix + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String lastId = rs.getString("ticket_id"); // e.g., HD-2026-0006
                    String[] parts = lastId.split("-");
                    if (parts.length == 3) {
                        nextSequence = Integer.parseInt(parts[2]) + 1;
                    }
                }
            }
        } catch (SQLException | NumberFormatException e) {
            System.err.println("[TicketIDGenerator] Fallback ID generation: " + e.getMessage());
            nextSequence = (int) (System.currentTimeMillis() % 9000) + 1000;
        }

        return String.format("%s-%d-%04d", PREFIX, currentYear, nextSequence);
    }
}
