import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import ui.LoginFrame;

/**
 * Main entry point for the IT Help Desk Ticketing and Service Management System.
 * Course: TY EXTC Java Programming Micro Project (A.Y. 2026-2027)
 * Tech Stack: Java 22, Java Swing, MySQL 8+, JDBC
 */
public class Main {

    public static void main(String[] args) {
        // Set cross-platform Swing Look and Feel for consistent colors across Windows/macOS/Linux
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("[Main] Warning: Could not set LookAndFeel: " + e.getMessage());
        }

        // Launch the LoginFrame on the Event Dispatch Thread (EDT)
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}
