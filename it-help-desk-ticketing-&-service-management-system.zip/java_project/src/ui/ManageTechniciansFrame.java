package ui;

import dao.TechnicianDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import utils.PasswordUtil;
import utils.SessionManager;

/**
 * ManageTechniciansFrame allows the Administrator to Add, Edit, Delete,
 * Search, View Details, and Activate/Deactivate Technicians.
 */
public class ManageTechniciansFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final Runnable onChangeCallback;

    private JTextField txtTechId;
    private JTextField txtName;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JComboBox<String> cmbSpecialization;
    private JComboBox<String> cmbStatus;
    private JTextField txtSearch;

    private DefaultTableModel tableModel;
    private JTable table;

    public ManageTechniciansFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        if (!SessionManager.isAdmin()) {
            JOptionPane.showMessageDialog(null, "Access Denied: Admin privileges required.", "Security", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }
        setTitle("Manage Technicians — IT Help Desk Admin");
        setSize(1040, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadTechnicians(technicianDAO.getAllTechnicians());
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Manage Technicians & Specializations");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Left Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setPreferredSize(new Dimension(350, 0));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(10, 14, 10, 6),
                BorderFactory.createTitledBorder("Technician Form")
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        txtTechId = new JTextField();
        txtTechId.setEditable(false);
        txtTechId.setBackground(new Color(238, 242, 246));

        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();
        cmbSpecialization = new JComboBox<>(new String[]{
                "Hardware", "Software", "Network", "Database", "General Support"
        });
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        int row = 0;
        addField(formPanel, gbc, row++, "Technician ID:", txtTechId);
        addField(formPanel, gbc, row++, "Name *:", txtName);
        addField(formPanel, gbc, row++, "Email *:", txtEmail);
        addField(formPanel, gbc, row++, "Phone (10 digits) *:", txtPhone);
        addField(formPanel, gbc, row++, "Specialization:", cmbSpecialization);
        addField(formPanel, gbc, row++, "Status:", cmbStatus);

        JPanel btnGrid = new JPanel(new GridLayout(3, 2, 8, 8));
        btnGrid.setBackground(Color.WHITE);

        JButton btnAdd = new JButton("Add Technician");
        btnAdd.setBackground(PRIMARY_COLOR);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> handleAddTechnician());

        JButton btnUpdate = new JButton("Edit Technician");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateTechnician());

        JButton btnToggle = new JButton("Activate / Deactivate");
        btnToggle.setBackground(ACCENT_COLOR);
        btnToggle.setForeground(Color.WHITE);
        btnToggle.addActionListener(e -> handleToggleActive());

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(220, 38, 38));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> handleDeleteTechnician());

        JButton btnDetails = new JButton("View Details");
        btnDetails.addActionListener(e -> showSelectedDetails());

        JButton btnClear = new JButton("Clear");
        btnClear.addActionListener(e -> clearForm());

        btnGrid.add(btnAdd);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnToggle);
        btnGrid.add(btnDelete);
        btnGrid.add(btnDetails);
        btnGrid.add(btnClear);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.insets = new Insets(16, 6, 6, 6);
        formPanel.add(btnGrid, gbc);

        add(formPanel, BorderLayout.WEST);

        // Right Table
        JPanel rightPanel = new JPanel(new BorderLayout(8, 8));
        rightPanel.setBackground(BG_COLOR);
        rightPanel.setBorder(new EmptyBorder(10, 6, 10, 14));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Search Technician:"));
        txtSearch = new JTextField(20);
        searchBar.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> loadTechnicians(technicianDAO.searchTechnicians(txtSearch.getText())));
        searchBar.add(btnSearch);

        JButton btnAll = new JButton("Show All");
        btnAll.setBackground(SECONDARY_COLOR);
        btnAll.setForeground(Color.WHITE);
        btnAll.addActionListener(e -> {
            txtSearch.setText("");
            loadTechnicians(technicianDAO.getAllTechnicians());
        });
        searchBar.add(btnAll);

        rightPanel.add(searchBar, BorderLayout.NORTH);

        String[] cols = {"Technician ID", "Name", "Email", "Phone", "Specialization", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtTechId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                txtName.setText(String.valueOf(tableModel.getValueAt(r, 1)));
                txtEmail.setText(String.valueOf(tableModel.getValueAt(r, 2)));
                txtPhone.setText(String.valueOf(tableModel.getValueAt(r, 3)));
                cmbSpecialization.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 4)));
                cmbStatus.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 5)));
            }
        });

        rightPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        add(rightPanel, BorderLayout.CENTER);
    }

    private void addField(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1; gbc.weightx = 0.35;
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(lbl, gbc);

        gbc.gridx = 1; gbc.weightx = 0.65;
        panel.add(comp, gbc);
    }

    private void loadTechnicians(List<Technician> list) {
        tableModel.setRowCount(0);
        for (Technician t : list) {
            tableModel.addRow(new Object[]{
                    t.getTechnicianId(), t.getName(), t.getEmail(),
                    t.getPhone(), t.getSpecialization(), t.getStatus()
            });
        }
    }

    private void handleAddTechnician() {
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String spec = (String) cmbSpecialization.getSelectedItem();
        String status = (String) cmbStatus.getSelectedItem();

        if (name.isEmpty() || !PasswordUtil.isValidEmail(email) || !PasswordUtil.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid Name, Email, and 10-digit Phone number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Technician t = new Technician(null, name, email, phone, spec, status);
        if (technicianDAO.addTechnician(t)) {
            JOptionPane.showMessageDialog(this, "Technician added successfully!");
            clearForm();
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateTechnician() {
        if (txtTechId.getText().isEmpty()) return;
        int id = Integer.parseInt(txtTechId.getText());
        Technician t = new Technician(
                id, null, txtName.getText().trim(), txtEmail.getText().trim(),
                txtPhone.getText().trim(), (String) cmbSpecialization.getSelectedItem(),
                (String) cmbStatus.getSelectedItem(), null
        );
        if (technicianDAO.updateTechnician(t)) {
            JOptionPane.showMessageDialog(this, "Technician updated successfully!");
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleToggleActive() {
        if (txtTechId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a technician first.");
            return;
        }
        int id = Integer.parseInt(txtTechId.getText());
        String current = (String) cmbStatus.getSelectedItem();
        String next = "ACTIVE".equalsIgnoreCase(current) ? "INACTIVE" : "ACTIVE";
        if (technicianDAO.updateTechnicianStatus(id, next)) {
            JOptionPane.showMessageDialog(this, "Technician #" + id + " status changed to " + next + ".");
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleDeleteTechnician() {
        if (txtTechId.getText().isEmpty()) return;
        int id = Integer.parseInt(txtTechId.getText());
        if (JOptionPane.showConfirmDialog(this, "Delete Technician #" + id + "?", "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            if (technicianDAO.deleteTechnician(id)) {
                clearForm();
                loadTechnicians(technicianDAO.getAllTechnicians());
                if (onChangeCallback != null) onChangeCallback.run();
            }
        }
    }

    private void showSelectedDetails() {
        if (txtTechId.getText().isEmpty()) return;
        String msg = String.format(
                "Technician ID: %s\nName: %s\nEmail: %s\nPhone: %s\nSpecialization: %s\nStatus: %s",
                txtTechId.getText(), txtName.getText(), txtEmail.getText(),
                txtPhone.getText(), cmbSpecialization.getSelectedItem(), cmbStatus.getSelectedItem()
        );
        JOptionPane.showMessageDialog(this, msg, "Technician Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearForm() {
        txtTechId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        cmbSpecialization.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        table.clearSelection();
    }
}
