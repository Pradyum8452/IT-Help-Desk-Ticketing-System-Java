package ui;

import dao.UserDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.User;
import utils.PasswordUtil;
import utils.SessionManager;

/**
 * ManageUsersFrame allows the Administrator to Add, Edit, Delete, Search,
 * and View all Users in a JTable.
 */
public class ManageUsersFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final UserDAO userDAO = new UserDAO();
    private final Runnable onChangeCallback;

    private JTextField txtUserId;
    private JTextField txtName;
    private JTextField txtEmail;
    private JTextField txtPhone;
    private JTextField txtDepartment;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JComboBox<String> cmbRole;
    private JComboBox<String> cmbStatus;
    private JTextField txtSearch;

    private DefaultTableModel tableModel;
    private JTable table;

    public ManageUsersFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        if (!SessionManager.isAdmin()) {
            JOptionPane.showMessageDialog(null, "Access Denied: Admin privileges required.", "Security", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }
        setTitle("Manage Users — IT Help Desk Admin");
        setSize(1080, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadUsersTable(userDAO.getAllUsers());
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Manage System Users (Add / Edit / Delete / Search)");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Left Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setPreferredSize(new Dimension(360, 0));
        formPanel.setBorder(BorderFactory.createCompoundBorder(
                new EmptyBorder(10, 14, 10, 6),
                BorderFactory.createTitledBorder("User Details Form")
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        txtUserId = new JTextField();
        txtUserId.setEditable(false);
        txtUserId.setBackground(new Color(238, 242, 246));

        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();
        txtDepartment = new JTextField();
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();
        cmbRole = new JComboBox<>(new String[]{"USER", "TECHNICIAN", "ADMIN"});
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        int row = 0;
        addFormField(formPanel, gbc, row++, "User ID:", txtUserId);
        addFormField(formPanel, gbc, row++, "Full Name *:", txtName);
        addFormField(formPanel, gbc, row++, "Email *:", txtEmail);
        addFormField(formPanel, gbc, row++, "Phone (10 digits) *:", txtPhone);
        addFormField(formPanel, gbc, row++, "Department *:", txtDepartment);
        addFormField(formPanel, gbc, row++, "Username *:", txtUsername);
        addFormField(formPanel, gbc, row++, "Password (SHA-256):", txtPassword);
        addFormField(formPanel, gbc, row++, "Role:", cmbRole);
        addFormField(formPanel, gbc, row++, "Status:", cmbStatus);

        // CRUD Buttons
        JPanel crudBtnPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        crudBtnPanel.setBackground(Color.WHITE);

        JButton btnAdd = new JButton("Add User");
        btnAdd.setBackground(PRIMARY_COLOR);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> handleAddUser());

        JButton btnUpdate = new JButton("Edit / Update");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateUser());

        JButton btnDelete = new JButton("Delete User");
        btnDelete.setBackground(new Color(220, 38, 38));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> handleDeleteUser());

        JButton btnClear = new JButton("Clear Form");
        btnClear.addActionListener(e -> clearForm());

        crudBtnPanel.add(btnAdd);
        crudBtnPanel.add(btnUpdate);
        crudBtnPanel.add(btnDelete);
        crudBtnPanel.add(btnClear);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        gbc.insets = new Insets(14, 6, 6, 6);
        formPanel.add(crudBtnPanel, gbc);

        add(formPanel, BorderLayout.WEST);

        // Right Table + Search Panel
        JPanel rightPanel = new JPanel(new BorderLayout(8, 8));
        rightPanel.setBackground(BG_COLOR);
        rightPanel.setBorder(new EmptyBorder(10, 6, 10, 14));

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Search User:"));
        txtSearch = new JTextField(20);
        searchBar.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> loadUsersTable(userDAO.searchUsers(txtSearch.getText())));
        searchBar.add(btnSearch);

        JButton btnViewAll = new JButton("View All Users");
        btnViewAll.setBackground(ACCENT_COLOR);
        btnViewAll.setForeground(Color.WHITE);
        btnViewAll.addActionListener(e -> {
            txtSearch.setText("");
            loadUsersTable(userDAO.getAllUsers());
        });
        searchBar.add(btnViewAll);

        rightPanel.add(searchBar, BorderLayout.NORTH);

        String[] cols = {"User ID", "Name", "Email", "Phone", "Department", "Username", "Role", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                txtUserId.setText(String.valueOf(tableModel.getValueAt(r, 0)));
                txtName.setText(String.valueOf(tableModel.getValueAt(r, 1)));
                txtEmail.setText(String.valueOf(tableModel.getValueAt(r, 2)));
                txtPhone.setText(String.valueOf(tableModel.getValueAt(r, 3)));
                txtDepartment.setText(String.valueOf(tableModel.getValueAt(r, 4)));
                txtUsername.setText(String.valueOf(tableModel.getValueAt(r, 5)));
                cmbRole.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 6)));
                cmbStatus.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 7)));
                txtPassword.setText("");
            }
        });

        rightPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        add(rightPanel, BorderLayout.CENTER);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1; gbc.weightx = 0.35;
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(lbl, gbc);

        gbc.gridx = 1; gbc.weightx = 0.65;
        panel.add(comp, gbc);
    }

    private void loadUsersTable(List<User> users) {
        tableModel.setRowCount(0);
        for (User u : users) {
            tableModel.addRow(new Object[]{
                    u.getUserId(), u.getName(), u.getEmail(), u.getPhone(),
                    u.getDepartment(), u.getUsername(), u.getRole(), u.getStatus()
            });
        }
    }

    private void handleAddUser() {
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String dept = txtDepartment.getText().trim();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        String role = (String) cmbRole.getSelectedItem();
        String status = (String) cmbStatus.getSelectedItem();

        if (name.isEmpty() || email.isEmpty() || phone.isEmpty() || dept.isEmpty() || username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields including Password are required when adding a new user.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!PasswordUtil.isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!PasswordUtil.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Phone number must be exactly 10 digits.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!PasswordUtil.isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, "Password must be at least 6 characters.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (userDAO.isEmailTaken(email, 0)) {
            JOptionPane.showMessageDialog(this, "Email address is already registered.", "Duplicate Email", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (userDAO.isUsernameTaken(username, 0)) {
            JOptionPane.showMessageDialog(this, "Username is already taken.", "Duplicate Username", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User newUser = new User(name, email, phone, dept, username, PasswordUtil.hashPassword(password), role, status);
        if (userDAO.addUser(newUser)) {
            JOptionPane.showMessageDialog(this, "User added successfully!");
            clearForm();
            loadUsersTable(userDAO.getAllUsers());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateUser() {
        if (txtUserId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a user from the table to edit.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int userId = Integer.parseInt(txtUserId.getText());
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String dept = txtDepartment.getText().trim();
        String username = txtUsername.getText().trim();
        String newPass = new String(txtPassword.getPassword()).trim();
        String role = (String) cmbRole.getSelectedItem();
        String status = (String) cmbStatus.getSelectedItem();

        if (!PasswordUtil.isValidEmail(email) || !PasswordUtil.isValidPhone(phone)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email and 10-digit phone number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (userDAO.isEmailTaken(email, userId)) {
            JOptionPane.showMessageDialog(this, "Another user already uses this email.", "Duplicate Email", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User updated = new User(userId, name, email, phone, dept, username, "", role, status, null);
        if (userDAO.updateUser(updated, newPass)) {
            JOptionPane.showMessageDialog(this, "User updated successfully!");
            clearForm();
            loadUsersTable(userDAO.getAllUsers());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleDeleteUser() {
        if (txtUserId.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a user to delete.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int userId = Integer.parseInt(txtUserId.getText());
        int confirm = JOptionPane.showConfirmDialog(this, "Delete User #" + userId + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            if (userDAO.deleteUser(userId)) {
                JOptionPane.showMessageDialog(this, "User deleted.");
                clearForm();
                loadUsersTable(userDAO.getAllUsers());
                if (onChangeCallback != null) onChangeCallback.run();
            } else {
                JOptionPane.showMessageDialog(this, "Cannot delete user with existing linked tickets. Set status to INACTIVE instead.", "Delete Restricted", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void clearForm() {
        txtUserId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtDepartment.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
        cmbRole.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
        table.clearSelection();
    }
}
