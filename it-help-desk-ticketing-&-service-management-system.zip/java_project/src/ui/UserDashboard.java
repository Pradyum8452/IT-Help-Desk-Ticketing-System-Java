package ui;

import dao.TicketDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;

/**
 * UserDashboard is the primary workspace for employees/users with role USER.
 * Displays real-time ticket statistics and quick access to Create New Ticket,
 * My Tickets, Track Ticket, Profile, and Logout.
 */
public class UserDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final TicketDAO ticketDAO = new TicketDAO();

    private JLabel lblTotalCount;
    private JLabel lblOpenCount;
    private JLabel lblInProgressCount;
    private JLabel lblResolvedCount;
    private JLabel lblClosedCount;

    public UserDashboard() {
        // Role security check
        if (!SessionManager.isLoggedIn()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }

        setTitle("User Dashboard — IT Help Desk Ticketing System");
        setSize(1020, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        refreshDashboardStats();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        User user = SessionManager.getCurrentUser();
        String welcomeText = user != null
                ? "Welcome, " + user.getName() + "  |  Department: " + user.getDepartment()
                : "Welcome, User";

        // Left Sidebar Navigation
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(240, 0));
        sidebar.setBorder(new EmptyBorder(20, 16, 20, 16));

        JPanel navButtonsPanel = new JPanel(new GridLayout(6, 1, 0, 10));
        navButtonsPanel.setOpaque(false);

        JLabel brandLabel = new JLabel("USER HELP DESK");
        brandLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        brandLabel.setForeground(ACCENT_COLOR);
        navButtonsPanel.add(brandLabel);

        JButton btnCreateTicket = createNavButton("Create New Ticket");
        btnCreateTicket.addActionListener(e -> new CreateTicketFrame(this::refreshDashboardStats).setVisible(true));

        JButton btnMyTickets = createNavButton("My Tickets");
        btnMyTickets.addActionListener(e -> new MyTicketsFrame().setVisible(true));

        JButton btnTrackTicket = createNavButton("Track Ticket");
        btnTrackTicket.addActionListener(e -> new TicketDetailsFrame("").setVisible(true));

        JButton btnProfile = createNavButton("My Profile");
        btnProfile.addActionListener(e -> showProfileDialog());

        JButton btnRefresh = createNavButton("Refresh Statistics");
        btnRefresh.addActionListener(e -> refreshDashboardStats());

        navButtonsPanel.add(btnCreateTicket);
        navButtonsPanel.add(btnMyTickets);
        navButtonsPanel.add(btnTrackTicket);
        navButtonsPanel.add(btnProfile);
        navButtonsPanel.add(btnRefresh);

        sidebar.add(navButtonsPanel, BorderLayout.NORTH);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnLogout.addActionListener(e -> handleLogout());
        sidebar.add(btnLogout, BorderLayout.SOUTH);

        add(sidebar, BorderLayout.WEST);

        // Main Workspace Area
        JPanel mainContent = new JPanel(new BorderLayout(16, 16));
        mainContent.setBackground(BG_COLOR);
        mainContent.setBorder(new EmptyBorder(24, 28, 24, 28));

        // Top Welcome Banner
        JPanel welcomeBanner = new JPanel(new BorderLayout());
        welcomeBanner.setBackground(Color.WHITE);
        welcomeBanner.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(18, 22, 18, 22)
        ));

        JLabel lblWelcome = new JLabel(welcomeText);
        lblWelcome.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblWelcome.setForeground(PRIMARY_COLOR);
        welcomeBanner.add(lblWelcome, BorderLayout.WEST);

        mainContent.add(welcomeBanner, BorderLayout.NORTH);

        // Statistics Cards + Quick Action Panel
        JPanel centerPanel = new JPanel(new BorderLayout(0, 20));
        centerPanel.setBackground(BG_COLOR);

        JPanel statsGrid = new JPanel(new GridLayout(1, 5, 14, 0));
        statsGrid.setBackground(BG_COLOR);

        lblTotalCount = new JLabel("0");
        lblOpenCount = new JLabel("0");
        lblInProgressCount = new JLabel("0");
        lblResolvedCount = new JLabel("0");
        lblClosedCount = new JLabel("0");

        statsGrid.add(createStatCard("Total Tickets", lblTotalCount, PRIMARY_COLOR));
        statsGrid.add(createStatCard("Open Tickets", lblOpenCount, ACCENT_COLOR));
        statsGrid.add(createStatCard("In Progress", lblInProgressCount, SECONDARY_COLOR));
        statsGrid.add(createStatCard("Resolved", lblResolvedCount, new Color(22, 163, 74)));
        statsGrid.add(createStatCard("Closed", lblClosedCount, new Color(100, 116, 139)));

        centerPanel.add(statsGrid, BorderLayout.NORTH);

        // Quick Guide Card
        JPanel guideCard = new JPanel(new BorderLayout(10, 10));
        guideCard.setBackground(Color.WHITE);
        guideCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(24, 24, 24, 24)
        ));

        JLabel lblGuideTitle = new JLabel("How to Raise & Track Support Tickets");
        lblGuideTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblGuideTitle.setForeground(PRIMARY_COLOR);
        guideCard.add(lblGuideTitle, BorderLayout.NORTH);

        JTextArea txtGuide = new JTextArea(
                "1. Click 'Create New Ticket' to report Hardware, Software, Network, Printer, Email, or Account issues.\n"
                + "2. Every ticket receives a unique ID (e.g., HD-2026-0001) and starts with status OPEN.\n"
                + "3. Once the Administrator assigns an active specialist, status changes to ASSIGNED -> IN_PROGRESS.\n"
                + "4. Use 'Track Ticket' to view real-time visual progress and technician resolution notes.\n"
                + "5. When your issue is marked RESOLVED, confirm resolution in 'My Tickets' to mark it CLOSED."
        );
        txtGuide.setEditable(false);
        txtGuide.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtGuide.setForeground(TEXT_COLOR);
        txtGuide.setBackground(Color.WHITE);
        guideCard.add(txtGuide, BorderLayout.CENTER);

        centerPanel.add(guideCard, BorderLayout.CENTER);
        mainContent.add(centerPanel, BorderLayout.CENTER);

        add(mainContent, BorderLayout.CENTER);
    }

    private JButton createNavButton(String label) {
        JButton btn = new JButton(label);
        btn.setBackground(SECONDARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }

    private JPanel createStatCard(String title, JLabel valueLabel, Color accentBarColor) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(18, 16, 18, 16)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTitle.setForeground(new Color(100, 116, 139));

        valueLabel.setFont(new Font("Monospaced", Font.BOLD, 28));
        valueLabel.setForeground(accentBarColor);

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    public final void refreshDashboardStats() {
        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        List<Ticket> myTickets = ticketDAO.getTicketsByUserId(user.getUserId());
        int total = myTickets.size();
        int open = 0;
        int inProgress = 0;
        int resolved = 0;
        int closed = 0;

        for (Ticket t : myTickets) {
            String st = t.getStatus();
            if ("OPEN".equalsIgnoreCase(st)) open++;
            else if ("ASSIGNED".equalsIgnoreCase(st) || "IN_PROGRESS".equalsIgnoreCase(st)) inProgress++;
            else if ("RESOLVED".equalsIgnoreCase(st)) resolved++;
            else if ("CLOSED".equalsIgnoreCase(st)) closed++;
        }

        lblTotalCount.setText(String.valueOf(total));
        lblOpenCount.setText(String.valueOf(open));
        lblInProgressCount.setText(String.valueOf(inProgress));
        lblResolvedCount.setText(String.valueOf(resolved));
        lblClosedCount.setText(String.valueOf(closed));
    }

    private void showProfileDialog() {
        User u = SessionManager.getCurrentUser();
        if (u == null) return;
        String profileInfo = String.format(
                "User ID: %d\nName: %s\nUsername: %s\nEmail: %s\nPhone: %s\nDepartment: %s\nRole: %s\nStatus: %s",
                u.getUserId(), u.getName(), u.getUsername(), u.getEmail(),
                u.getPhone(), u.getDepartment(), u.getRole(), u.getStatus()
        );
        JOptionPane.showMessageDialog(this, profileInfo, "My User Profile", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Confirm Logout",
                JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}
