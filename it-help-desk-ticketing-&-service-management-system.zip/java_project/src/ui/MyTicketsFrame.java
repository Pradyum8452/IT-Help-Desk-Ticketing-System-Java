package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Ticket;
import model.User;
import utils.SessionManager;

/**
 * MyTicketsFrame displays all tickets submitted by the currently logged-in User
 * in a JTable and allows opening TicketDetailsFrame, TicketHistoryFrame, or confirming resolution.
 */
public class MyTicketsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private DefaultTableModel tableModel;
    private JTable table;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public MyTicketsFrame() {
        setTitle("My Support Tickets — IT Help Desk System");
        setSize(960, 540);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadUserTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("My Submitted Support Tickets");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);

        JButton btnRefresh = new JButton("Refresh List");
        btnRefresh.setBackground(ACCENT_COLOR);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.addActionListener(e -> loadUserTickets());
        headerPanel.add(btnRefresh, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        // Table
        String[] cols = {
                "Ticket ID", "Subject", "Category", "Priority",
                "Assigned Technician", "Status", "Created Date", "Updated Date"
        };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));

        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setBackground(BG_COLOR);
        tableContainer.setBorder(new EmptyBorder(12, 16, 12, 16));
        tableContainer.add(new JScrollPane(table), BorderLayout.CENTER);
        add(tableContainer, BorderLayout.CENTER);

        // Bottom Action Buttons
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        footerPanel.setBackground(BG_COLOR);

        JButton btnViewDetails = new JButton("View Details & Status Tracker");
        btnViewDetails.setBackground(PRIMARY_COLOR);
        btnViewDetails.setForeground(Color.WHITE);
        btnViewDetails.setFocusPainted(false);
        btnViewDetails.addActionListener(e -> openSelectedTicketDetails());

        JButton btnHistory = new JButton("View Ticket History");
        btnHistory.setBackground(SECONDARY_COLOR);
        btnHistory.setForeground(Color.WHITE);
        btnHistory.setFocusPainted(false);
        btnHistory.addActionListener(e -> openSelectedTicketHistory());

        JButton btnConfirmResolution = new JButton("Confirm Resolution (Close Ticket)");
        btnConfirmResolution.setBackground(new Color(22, 163, 74));
        btnConfirmResolution.setForeground(Color.WHITE);
        btnConfirmResolution.setFocusPainted(false);
        btnConfirmResolution.addActionListener(e -> confirmSelectedResolution());

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());

        footerPanel.add(btnViewDetails);
        footerPanel.add(btnHistory);
        footerPanel.add(btnConfirmResolution);
        footerPanel.add(btnClose);
        add(footerPanel, BorderLayout.SOUTH);
    }

    public final void loadUserTickets() {
        tableModel.setRowCount(0);
        User currentUser = SessionManager.getCurrentUser();
        if (currentUser == null) return;

        List<Ticket> tickets = ticketDAO.getTicketsByUserId(currentUser.getUserId());
        for (Ticket t : tickets) {
            tableModel.addRow(new Object[]{
                    t.getTicketId(),
                    t.getSubject(),
                    t.getCategory(),
                    t.getPriority(),
                    t.getTechnicianName(),
                    t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-",
                    t.getUpdatedAt() != null ? t.getUpdatedAt().format(FMT) : "-"
            });
        }
    }

    private String getSelectedTicketId() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this,
                    "Please select a ticket row from the table first.",
                    "Selection Required",
                    JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return (String) tableModel.getValueAt(row, 0);
    }

    private void openSelectedTicketDetails() {
        String ticketId = getSelectedTicketId();
        if (ticketId != null) {
            new TicketDetailsFrame(ticketId).setVisible(true);
        }
    }

    private void openSelectedTicketHistory() {
        String ticketId = getSelectedTicketId();
        if (ticketId != null) {
            new TicketHistoryFrame(ticketId).setVisible(true);
        }
    }

    private void confirmSelectedResolution() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a RESOLVED ticket first.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String ticketId = (String) tableModel.getValueAt(row, 0);
        String status = (String) tableModel.getValueAt(row, 5);
        String priority = (String) tableModel.getValueAt(row, 3);

        if (!"RESOLVED".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this,
                    "Only tickets with status RESOLVED can be confirmed and closed by the user.\nCurrent status: " + status,
                    "Action Not Allowed",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        int choice = JOptionPane.showConfirmDialog(this,
                "Confirm resolution for Ticket " + ticketId + " and mark as CLOSED?",
                "Confirm Resolution",
                JOptionPane.YES_NO_OPTION);

        if (choice == JOptionPane.YES_OPTION) {
            if (ticketDAO.updateStatusAndPriority(ticketId, "CLOSED", priority, user.getUserId(), "User confirmed resolution and closed ticket.")) {
                JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " marked as CLOSED.");
                loadUserTickets();
            }
        }
    }
}
