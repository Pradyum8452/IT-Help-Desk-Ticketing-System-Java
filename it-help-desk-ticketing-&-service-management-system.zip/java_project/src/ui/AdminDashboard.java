package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import dao.UserDAO;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import utils.SessionManager;

/**
 * AdminDashboard is the primary control console for ADMIN users.
 * Displays 7 live metrics, a 9-item navigation menu, SQL aggregate Reports
 * (by Category, Priority, and Technician), and CSV Export.
 */
public class AdminDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final UserDAO userDAO = new UserDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final TicketDAO ticketDAO = new TicketDAO();

    private JLabel lblTotalUsers;
    private JLabel lblTotalTechs;
    private JLabel lblTotalTickets;
    private JLabel lblOpenTickets;
    private JLabel lblAssignedTickets;
    private JLabel lblInProgressTickets;
    private JLabel lblResolvedTickets;
    private JLabel lblClosedTickets;

    private JTextArea txtReportSummary;

    public AdminDashboard() {
        if (!SessionManager.isLoggedIn() || !SessionManager.isAdmin()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }
        setTitle("Admin Dashboard — IT Help Desk Ticketing & Service Management System");
        setSize(1160, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        refreshAllMetricsAndReports();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Left Sidebar with 9 Admin Menu Items
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(new EmptyBorder(18, 14, 18, 14));

        JPanel menuPanel = new JPanel(new GridLayout(10, 1, 0, 8));
        menuPanel.setOpaque(false);

        JLabel lblBrand = new JLabel("ADMIN CONTROL PANEL");
        lblBrand.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblBrand.setForeground(ACCENT_COLOR);
        menuPanel.add(lblBrand);

        JButton btnDashboard = createMenuButton("1. Dashboard Refresh");
        btnDashboard.addActionListener(e -> refreshAllMetricsAndReports());

        JButton btnManageUsers = createMenuButton("2. Manage Users");
        btnManageUsers.addActionListener(e -> new ManageUsersFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnManageTechs = createMenuButton("3. Manage Technicians");
        btnManageTechs.addActionListener(e -> new ManageTechniciansFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnAllTickets = createMenuButton("4. All Tickets");
        btnAllTickets.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnAssignTech = createMenuButton("5. Assign Technician");
        btnAssignTech.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnUpdateTicket = createMenuButton("6. Update Ticket");
        btnUpdateTicket.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnTicketHistory = createMenuButton("7. Ticket History");
        btnTicketHistory.addActionListener(e -> new TicketHistoryFrame("").setVisible(true));

        JButton btnReports = createMenuButton("8. Export Reports (CSV)");
        btnReports.addActionListener(e -> exportReportToCSV());

        menuPanel.add(btnDashboard);
        menuPanel.add(btnManageUsers);
        menuPanel.add(btnManageTechs);
        menuPanel.add(btnAllTickets);
        menuPanel.add(btnAssignTech);
        menuPanel.add(btnUpdateTicket);
        menuPanel.add(btnTicketHistory);
        menuPanel.add(btnReports);

        sidebar.add(menuPanel, BorderLayout.NORTH);

        JButton btnLogout = new JButton("9. Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnLogout.addActionListener(e -> {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        });
        sidebar.add(btnLogout, BorderLayout.SOUTH);

        add(sidebar, BorderLayout.WEST);

        // Main Workspace
        JPanel mainWorkspace = new JPanel(new BorderLayout(16, 16));
        mainWorkspace.setBackground(BG_COLOR);
        mainWorkspace.setBorder(new EmptyBorder(20, 24, 20, 24));

        // Top Metric Cards Grid (2 rows x 4 columns)
        JPanel metricsGrid = new JPanel(new GridLayout(2, 4, 14, 14));
        metricsGrid.setBackground(BG_COLOR);

        lblTotalUsers = new JLabel("0");
        lblTotalTechs = new JLabel("0");
        lblTotalTickets = new JLabel("0");
        lblOpenTickets = new JLabel("0");
        lblAssignedTickets = new JLabel("0");
        lblInProgressTickets = new JLabel("0");
        lblResolvedTickets = new JLabel("0");
        lblClosedTickets = new JLabel("0");

        metricsGrid.add(createMetricCard("Total Users", lblTotalUsers, PRIMARY_COLOR));
        metricsGrid.add(createMetricCard("Total Technicians", lblTotalTechs, SECONDARY_COLOR));
        metricsGrid.add(createMetricCard("Total Tickets", lblTotalTickets, PRIMARY_COLOR));
        metricsGrid.add(createMetricCard("Open Tickets", lblOpenTickets, ACCENT_COLOR));
        metricsGrid.add(createMetricCard("Assigned Tickets", lblAssignedTickets, SECONDARY_COLOR));
        metricsGrid.add(createMetricCard("In Progress Tickets", lblInProgressTickets, new Color(217, 119, 6)));
        metricsGrid.add(createMetricCard("Resolved Tickets", lblResolvedTickets, new Color(22, 163, 74)));
        metricsGrid.add(createMetricCard("Closed Tickets", lblClosedTickets, new Color(100, 116, 139)));

        mainWorkspace.add(metricsGrid, BorderLayout.NORTH);

        // SQL Aggregate Reports Panel
        JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
        reportPanel.setBackground(Color.WHITE);
        reportPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(16, 18, 16, 18)
        ));

        JPanel reportHeader = new JPanel(new BorderLayout());
        reportHeader.setBackground(Color.WHITE);
        JLabel lblReportHeading = new JLabel("SQL Aggregate System Reports (Category, Priority & Technician Workload)");
        lblReportHeading.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblReportHeading.setForeground(PRIMARY_COLOR);
        reportHeader.add(lblReportHeading, BorderLayout.WEST);

        JButton btnExportCsv = new JButton("Export Tickets Report to CSV");
        btnExportCsv.setBackground(ACCENT_COLOR);
        btnExportCsv.setForeground(Color.WHITE);
        btnExportCsv.setFocusPainted(false);
        btnExportCsv.addActionListener(e -> exportReportToCSV());
        reportHeader.add(btnExportCsv, BorderLayout.EAST);

        reportPanel.add(reportHeader, BorderLayout.NORTH);

        txtReportSummary = new JTextArea();
        txtReportSummary.setEditable(false);
        txtReportSummary.setFont(new Font("Monospaced", Font.PLAIN, 13));
        txtReportSummary.setBackground(new Color(248, 250, 252));
        txtReportSummary.setBorder(new EmptyBorder(12, 12, 12, 12));
        reportPanel.add(new JScrollPane(txtReportSummary), BorderLayout.CENTER);

        mainWorkspace.add(reportPanel, BorderLayout.CENTER);
        add(mainWorkspace, BorderLayout.CENTER);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(SECONDARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }

    private JPanel createMetricCard(String title, JLabel valLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(14, 16, 14, 16)
        ));
        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        lbl.setForeground(new Color(100, 116, 139));
        valLabel.setFont(new Font("Monospaced", Font.BOLD, 26));
        valLabel.setForeground(color);
        card.add(lbl, BorderLayout.NORTH);
        card.add(valLabel, BorderLayout.CENTER);
        return card;
    }

    public final void refreshAllMetricsAndReports() {
        int usersCount = userDAO.getTotalUserCount();
        int techsCount = technicianDAO.getTotalTechnicianCount();
        int totalTickets = ticketDAO.getTicketCountByStatus("ALL");
        int openTickets = ticketDAO.getTicketCountByStatus("OPEN");
        int assignedTickets = ticketDAO.getTicketCountByStatus("ASSIGNED");
        int inProgTickets = ticketDAO.getTicketCountByStatus("IN_PROGRESS");
        int resolvedTickets = ticketDAO.getTicketCountByStatus("RESOLVED");
        int closedTickets = ticketDAO.getTicketCountByStatus("CLOSED");

        lblTotalUsers.setText(String.valueOf(usersCount));
        lblTotalTechs.setText(String.valueOf(techsCount));
        lblTotalTickets.setText(String.valueOf(totalTickets));
        lblOpenTickets.setText(String.valueOf(openTickets));
        lblAssignedTickets.setText(String.valueOf(assignedTickets));
        lblInProgressTickets.setText(String.valueOf(inProgTickets));
        lblResolvedTickets.setText(String.valueOf(resolvedTickets));
        lblClosedTickets.setText(String.valueOf(closedTickets));

        // Build Aggregate Report Text
        StringBuilder sb = new StringBuilder();
        sb.append("========================================================================\n");
        sb.append("  IT HELP DESK ANALYTICS REPORT (SQL GROUP BY AGGREGATIONS)\n");
        sb.append("========================================================================\n\n");

        sb.append("1. TICKETS BY CATEGORY:\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByCategory().entrySet()) {
            sb.append(String.format("   - %-20s : %d\n", e.getKey(), e.getValue()));
        }

        sb.append("\n2. TICKETS BY PRIORITY:\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByPriority().entrySet()) {
            sb.append(String.format("   - %-20s : %d\n", e.getKey(), e.getValue()));
        }

        sb.append("\n3. TICKETS HANDLED BY TECHNICIAN:\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByTechnician().entrySet()) {
            sb.append(String.format("   - %-24s : %d tickets\n", e.getKey(), e.getValue()));
        }

        txtReportSummary.setText(sb.toString());
    }

    private void exportReportToCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("helpdesk_tickets_report.csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            List<Ticket> allTickets = ticketDAO.getAllTickets();
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Ticket ID,Subject,Category,Priority,Status,User,Technician,Created At\n");
                for (Ticket t : allTickets) {
                    writer.write(String.format("\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\",\"%s\"\n",
                            t.getTicketId(),
                            t.getSubject().replace("\"", "\"\""),
                            t.getCategory(),
                            t.getPriority(),
                            t.getStatus(),
                            t.getUserName(),
                            t.getTechnicianName(),
                            t.getCreatedAt() != null ? t.getCreatedAt().toString() : ""
                    ));
                }
                JOptionPane.showMessageDialog(this,
                        "CSV Report exported successfully to:\n" + file.getAbsolutePath(),
                        "Export Complete",
                        JOptionPane.INFORMATION_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this,
                        "Error writing CSV file: " + ex.getMessage(),
                        "File Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
