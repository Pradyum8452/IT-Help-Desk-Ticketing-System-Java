package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import model.Ticket;
import model.User;
import utils.SessionManager;

/**
 * ManageTicketsFrame provides Admin Ticket Management:
 * - JTable of all tickets with Search, Filter by Status, Priority, Category, Refresh, View Details
 * - Assign Technician to OPEN tickets (prevents assigning INACTIVE technicians)
 * - Change Priority & Update Ticket Status
 */
public class ManageTicketsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final Runnable onChangeCallback;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private JTextField txtSearch;
    private JComboBox<String> cmbFilterStatus;
    private JComboBox<String> cmbFilterPriority;
    private JComboBox<String> cmbFilterCategory;

    private DefaultTableModel tableModel;
    private JTable table;

    private JComboBox<Technician> cmbActiveTechnicians;
    private JComboBox<String> cmbNewStatus;
    private JComboBox<String> cmbNewPriority;

    public ManageTicketsFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        if (!SessionManager.isAdmin()) {
            JOptionPane.showMessageDialog(null, "Access Denied: Admin privileges required.", "Security", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }
        setTitle("All Tickets Management & Technician Assignment — IT Help Desk Admin");
        setSize(1140, 660);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("All Tickets Management, Technician Assignment & Status Updates");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel mainBody = new JPanel(new BorderLayout(10, 10));
        mainBody.setBackground(BG_COLOR);
        mainBody.setBorder(new EmptyBorder(8, 14, 8, 14));

        // Filter Bar
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        filterPanel.setBackground(Color.WHITE);

        filterPanel.add(new JLabel("Search:"));
        txtSearch = new JTextField(16);
        filterPanel.add(txtSearch);

        filterPanel.add(new JLabel("Status:"));
        cmbFilterStatus = new JComboBox<>(new String[]{
                "ALL", "OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"
        });
        filterPanel.add(cmbFilterStatus);

        filterPanel.add(new JLabel("Priority:"));
        cmbFilterPriority = new JComboBox<>(new String[]{"ALL", "Low", "Medium", "High", "Critical"});
        filterPanel.add(cmbFilterPriority);

        filterPanel.add(new JLabel("Category:"));
        cmbFilterCategory = new JComboBox<>(new String[]{
                "ALL", "Hardware", "Software", "Network", "Printer", "Email", "Account/Login", "Other"
        });
        filterPanel.add(cmbFilterCategory);

        JButton btnFilter = new JButton("Apply Filters");
        btnFilter.setBackground(PRIMARY_COLOR);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.addActionListener(e -> loadTickets());
        filterPanel.add(btnFilter);

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(ACCENT_COLOR);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cmbFilterStatus.setSelectedIndex(0);
            cmbFilterPriority.setSelectedIndex(0);
            cmbFilterCategory.setSelectedIndex(0);
            loadActiveTechniciansDropdown();
            loadTickets();
        });
        filterPanel.add(btnRefresh);

        mainBody.add(filterPanel, BorderLayout.NORTH);

        // JTable
        String[] cols = {
                "Ticket ID", "Subject", "Category", "Priority",
                "User", "Technician", "Status", "Created Date", "Updated Date"
        };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(27);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                int r = table.getSelectedRow();
                cmbNewPriority.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 3)));
                cmbNewStatus.setSelectedItem(String.valueOf(tableModel.getValueAt(r, 6)));
            }
        });

        mainBody.add(new JScrollPane(table), BorderLayout.CENTER);

        // Bottom Admin Control Strip: Assign Technician + Update Ticket + View Details
        JPanel actionStrip = new JPanel(new GridLayout(1, 2, 12, 0));
        actionStrip.setBackground(BG_COLOR);

        // Panel A: Assign Technician
        JPanel assignPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        assignPanel.setBackground(Color.WHITE);
        assignPanel.setBorder(BorderFactory.createTitledBorder("Assign Active Technician to Selected Ticket"));

        cmbActiveTechnicians = new JComboBox<>();
        loadActiveTechniciansDropdown();
        assignPanel.add(cmbActiveTechnicians);

        JButton btnAssign = new JButton("Assign Technician");
        btnAssign.setBackground(PRIMARY_COLOR);
        btnAssign.setForeground(Color.WHITE);
        btnAssign.addActionListener(e -> handleAssignTechnician());
        assignPanel.add(btnAssign);

        // Panel B: Update Priority & Status + Details/History
        JPanel updatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        updatePanel.setBackground(Color.WHITE);
        updatePanel.setBorder(BorderFactory.createTitledBorder("Update Ticket Status / Priority & Inspect"));

        updatePanel.add(new JLabel("Priority:"));
        cmbNewPriority = new JComboBox<>(new String[]{"Low", "Medium", "High", "Critical"});
        updatePanel.add(cmbNewPriority);

        updatePanel.add(new JLabel("Status:"));
        cmbNewStatus = new JComboBox<>(new String[]{"OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"});
        updatePanel.add(cmbNewStatus);

        JButton btnUpdate = new JButton("Update Ticket");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateStatusAndPriority());
        updatePanel.add(btnUpdate);

        JButton btnDetails = new JButton("View Details");
        btnDetails.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) new TicketDetailsFrame((String) tableModel.getValueAt(r, 0)).setVisible(true);
        });
        updatePanel.add(btnDetails);

        actionStrip.add(assignPanel);
        actionStrip.add(updatePanel);
        mainBody.add(actionStrip, BorderLayout.SOUTH);

        add(mainBody, BorderLayout.CENTER);
    }

    private void loadActiveTechniciansDropdown() {
        cmbActiveTechnicians.removeAllItems();
        List<Technician> activeTechs = technicianDAO.getActiveTechnicians();
        for (Technician t : activeTechs) {
            cmbActiveTechnicians.addItem(t);
        }
    }

    public final void loadTickets() {
        tableModel.setRowCount(0);
        List<Ticket> list = ticketDAO.searchAndFilterTickets(
                txtSearch.getText(),
                (String) cmbFilterStatus.getSelectedItem(),
                (String) cmbFilterPriority.getSelectedItem(),
                (String) cmbFilterCategory.getSelectedItem()
        );

        for (Ticket t : list) {
            tableModel.addRow(new Object[]{
                    t.getTicketId(),
                    t.getSubject(),
                    t.getCategory(),
                    t.getPriority(),
                    t.getUserName(),
                    t.getTechnicianName(),
                    t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-",
                    t.getUpdatedAt() != null ? t.getUpdatedAt().format(FMT) : "-"
            });
        }
    }

    private void handleAssignTechnician() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select an OPEN ticket from the table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String ticketId = (String) tableModel.getValueAt(row, 0);
        Technician selectedTech = (Technician) cmbActiveTechnicians.getSelectedItem();

        if (selectedTech == null || !selectedTech.isActive()) {
            JOptionPane.showMessageDialog(this, "No active technician selected. Inactive technicians cannot be assigned.", "Validation", JOptionPane.ERROR_MESSAGE);
            return;
        }

        User admin = SessionManager.getCurrentUser();
        if (admin == null) return;

        if (ticketDAO.assignTechnician(ticketId, selectedTech.getTechnicianId(), admin.getUserId())) {
            JOptionPane.showMessageDialog(this,
                    "Ticket " + ticketId + " assigned to " + selectedTech.getName() + ".\nStatus changed to ASSIGNED.",
                    "Technician Assigned",
                    JOptionPane.INFORMATION_MESSAGE);
            loadTickets();
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateStatusAndPriority() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "Please select a ticket from the table first.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String ticketId = (String) tableModel.getValueAt(row, 0);
        String newPriority = (String) cmbNewPriority.getSelectedItem();
        String newStatus = (String) cmbNewStatus.getSelectedItem();

        User admin = SessionManager.getCurrentUser();
        if (admin == null) return;

        if (ticketDAO.updateStatusAndPriority(ticketId, newStatus, newPriority, admin.getUserId(),
                "Admin updated status to " + newStatus + " and priority to " + newPriority + ".")) {
            JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " updated successfully.");
            loadTickets();
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }
}
