package ui;

import dao.TicketHistoryDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.TicketHistory;

/**
 * TicketHistoryFrame displays chronological status and assignment changes
 * stored in the ticket_history MySQL table.
 */
public class TicketHistoryFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketHistoryDAO historyDAO = new TicketHistoryDAO();
    private JTextField txtTicketIdFilter;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public TicketHistoryFrame(String initialTicketId) {
        setTitle("Ticket Audit History — IT Help Desk System");
        setSize(940, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents(initialTicketId);
        loadHistory(initialTicketId);
    }

    private void initComponents(String initialTicketId) {
        setLayout(new BorderLayout(10, 10));

        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Chronological Ticket Status History");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Filter Bar
        JPanel centerContainer = new JPanel(new BorderLayout(10, 10));
        centerContainer.setBackground(BG_COLOR);
        centerContainer.setBorder(new EmptyBorder(10, 16, 14, 16));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        filterPanel.setBackground(Color.WHITE);
        filterPanel.add(new JLabel("Filter by Ticket ID:"));

        txtTicketIdFilter = new JTextField(initialTicketId != null ? initialTicketId : "", 16);
        txtTicketIdFilter.setFont(new Font("Monospaced", Font.PLAIN, 13));
        filterPanel.add(txtTicketIdFilter);

        JButton btnSearch = new JButton("Filter History");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.addActionListener(e -> loadHistory(txtTicketIdFilter.getText().trim()));
        filterPanel.add(btnSearch);

        JButton btnShowAll = new JButton("Show All Tickets");
        btnShowAll.setBackground(SECONDARY_COLOR);
        btnShowAll.setForeground(Color.WHITE);
        btnShowAll.setFocusPainted(false);
        btnShowAll.addActionListener(e -> {
            txtTicketIdFilter.setText("");
            loadHistory("");
        });
        filterPanel.add(btnShowAll);

        centerContainer.add(filterPanel, BorderLayout.NORTH);

        // JTable
        String[] cols = {
                "History ID", "Ticket ID", "Previous Status", "New Status",
                "Changed By", "Change Description", "Changed At"
        };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        JTable table = new JTable(tableModel);
        table.setRowHeight(28);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 12));
        table.setFont(new Font("SansSerif", Font.PLAIN, 12));

        centerContainer.add(new JScrollPane(table), BorderLayout.CENTER);
        add(centerContainer, BorderLayout.CENTER);
    }

    private void loadHistory(String ticketId) {
        tableModel.setRowCount(0);
        List<TicketHistory> list = (ticketId == null || ticketId.isBlank())
                ? historyDAO.getAllHistory()
                : historyDAO.getHistoryByTicketId(ticketId);

        for (TicketHistory h : list) {
            tableModel.addRow(new Object[]{
                    h.getHistoryId(),
                    h.getTicketId(),
                    h.getPreviousStatus() != null ? h.getPreviousStatus() : "NONE",
                    h.getNewStatus(),
                    h.getChangedByName(),
                    h.getChangeDescription(),
                    h.getChangedAt() != null ? h.getChangedAt().format(FMT) : ""
            });
        }
    }
}
