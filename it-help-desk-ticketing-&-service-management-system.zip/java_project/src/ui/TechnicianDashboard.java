package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import model.Ticket;
import model.User;
import utils.SessionManager;

/**
 * TechnicianDashboard is the workspace for TECHNICIAN users.
 * Displays Assigned Tickets, In Progress, Resolved, High Priority, and Critical counts.
 * Allows technicians to Accept assigned tickets, Start work (IN_PROGRESS),
 * Add resolution details (RESOLVED), and Close resolved tickets (CLOSED)
 * strictly for tickets assigned to them.
 */
public class TechnicianDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private Technician currentTech;

    private JLabel lblAssigned;
    private JLabel lblInProgress;
    private JLabel lblResolved;
    private JLabel lblHighPriority;
    private JLabel lblCritical;

    private DefaultTableModel tableModel;
    private JTable table;

    // Resolution Form Fields
    private JTextField txtResTicketId;
    private JTextField txtResTechnician;
    private JTextField txtResDate;
    private JTextField txtResStatus;
    private JTextArea txtProblemDesc;
    private JTextArea txtResolutionDetails;

    public TechnicianDashboard() {
        if (!SessionManager.isLoggedIn() || !SessionManager.isTechnician()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }
        User user = SessionManager.getCurrentUser();
        this.currentTech = SessionManager.getCurrentTechnician();
        if (this.currentTech == null && user != null) {
            this.currentTech = technicianDAO.getTechnicianByUser(user.getUserId(), user.getEmail());
        }

        setTitle("Technician Dashboard & Resolution Console — IT Help Desk System");
        setSize(1120, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadAssignedTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Top Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 22, 14, 22));

        String techTitle = currentTech != null
                ? "Technician Portal: " + currentTech.getName() + " [" + currentTech.getSpecialization() + "]"
                : "Technician Portal";
        JLabel lblTitle = new JLabel(techTitle);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.addActionListener(e -> {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        });
        headerPanel.add(btnLogout, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel mainContainer = new JPanel(new BorderLayout(12, 12));
        mainContainer.setBackground(BG_COLOR);
        mainContainer.setBorder(new EmptyBorder(10, 18, 14, 18));

        // 5 Stat Cards: Assigned Tickets, In Progress, Resolved, High Priority, Critical Tickets
        JPanel statsGrid = new JPanel(new GridLayout(1, 5, 12, 0));
        statsGrid.setBackground(BG_COLOR);

        lblAssigned = new JLabel("0");
        lblInProgress = new JLabel("0");
        lblResolved = new JLabel("0");
        lblHighPriority = new JLabel("0");
        lblCritical = new JLabel("0");

        statsGrid.add(createStatCard("Assigned Tickets", lblAssigned, PRIMARY_COLOR));
        statsGrid.add(createStatCard("In Progress", lblInProgress, ACCENT_COLOR));
        statsGrid.add(createStatCard("Resolved", lblResolved, new Color(22, 163, 74)));
        statsGrid.add(createStatCard("High Priority", lblHighPriority, new Color(217, 119, 6)));
        statsGrid.add(createStatCard("Critical Tickets", lblCritical, new Color(220, 38, 38)));

        mainContainer.add(statsGrid, BorderLayout.NORTH);

        // Center Split: Assigned Tickets Table (Top) + Ticket Resolution Form (Bottom)
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(270);
        splitPane.setResizeWeight(0.5);

        // Top: Assigned Tickets Table + Action Buttons
        JPanel tableSection = new JPanel(new BorderLayout(6, 6));
        tableSection.setBackground(Color.WHITE);
        tableSection.setBorder(BorderFactory.createTitledBorder("Tickets Assigned to Me"));

        String[] cols = {"Ticket ID", "Subject", "Category", "Priority", "Raised By", "Status", "Created Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                populateResolutionForm((String) tableModel.getValueAt(table.getSelectedRow(), 0));
            }
        });

        tableSection.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        actionRow.setBackground(Color.WHITE);

        JButton btnAcceptStart = new JButton("Accept & Start Work (IN_PROGRESS)");
        btnAcceptStart.setBackground(PRIMARY_COLOR);
        btnAcceptStart.setForeground(Color.WHITE);
        btnAcceptStart.addActionListener(e -> handleQuickStatusChange("IN_PROGRESS", "Technician accepted ticket and started diagnostic work."));

        JButton btnCloseResolved = new JButton("Close Resolved Ticket (CLOSED)");
        btnCloseResolved.setBackground(SECONDARY_COLOR);
        btnCloseResolved.setForeground(Color.WHITE);
        btnCloseResolved.addActionListener(e -> handleQuickStatusChange("CLOSED", "Technician verified resolution and closed the ticket."));

        JButton btnViewDetails = new JButton("View Ticket Details");
        btnViewDetails.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) new TicketDetailsFrame((String) tableModel.getValueAt(r, 0)).setVisible(true);
        });

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.addActionListener(e -> loadAssignedTickets());

        actionRow.add(btnAcceptStart);
        actionRow.add(btnCloseResolved);
        actionRow.add(btnViewDetails);
        actionRow.add(btnRefresh);
        tableSection.add(actionRow, BorderLayout.SOUTH);

        // Bottom: Ticket Resolution Form (Section 14)
        JPanel resolutionForm = new JPanel(new BorderLayout(10, 10));
        resolutionForm.setBackground(Color.WHITE);
        resolutionForm.setBorder(BorderFactory.createTitledBorder("Ticket Resolution Form (Store Resolution & Mark RESOLVED)"));

        JPanel metaRow = new JPanel(new GridLayout(1, 4, 10, 0));
        metaRow.setBackground(Color.WHITE);
        metaRow.setBorder(new EmptyBorder(6, 10, 6, 10));

        txtResTicketId = createReadOnlyField(metaRow, "Ticket ID:");
        txtResTechnician = createReadOnlyField(metaRow, "Technician:");
        txtResDate = createReadOnlyField(metaRow, "Resolution Date:");
        txtResStatus = createReadOnlyField(metaRow, "Current Status:");

        resolutionForm.add(metaRow, BorderLayout.NORTH);

        JPanel textSplit = new JPanel(new GridLayout(1, 2, 12, 0));
        textSplit.setBackground(Color.WHITE);
        textSplit.setBorder(new EmptyBorder(4, 10, 4, 10));

        txtProblemDesc = new JTextArea(4, 25);
        txtProblemDesc.setEditable(false);
        txtProblemDesc.setLineWrap(true);
        txtProblemDesc.setWrapStyleWord(true);
        JScrollPane pScroll = new JScrollPane(txtProblemDesc);
        pScroll.setBorder(BorderFactory.createTitledBorder("Problem Description"));

        txtResolutionDetails = new JTextArea(4, 25);
        txtResolutionDetails.setLineWrap(true);
        txtResolutionDetails.setWrapStyleWord(true);
        JScrollPane rScroll = new JScrollPane(txtResolutionDetails);
        rScroll.setBorder(BorderFactory.createTitledBorder("Resolution Details * (Enter fix steps)"));

        textSplit.add(pScroll);
        textSplit.add(rScroll);
        resolutionForm.add(textSplit, BorderLayout.CENTER);

        JPanel resFooter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        resFooter.setBackground(Color.WHITE);
        JButton btnResolve = new JButton("Submit Resolution & Mark Ticket as RESOLVED");
        btnResolve.setBackground(new Color(22, 163, 74));
        btnResolve.setForeground(Color.WHITE);
        btnResolve.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnResolve.addActionListener(e -> handleSubmitResolution());
        resFooter.add(btnResolve);

        resolutionForm.add(resFooter, BorderLayout.SOUTH);

        splitPane.setTopComponent(tableSection);
        splitPane.setBottomComponent(resolutionForm);

        mainContainer.add(splitPane, BorderLayout.CENTER);
        add(mainContainer, BorderLayout.CENTER);
    }

    private JTextField createReadOnlyField(JPanel parent, String label) {
        JPanel p = new JPanel(new BorderLayout(4, 2));
        p.setBackground(Color.WHITE);
        p.add(new JLabel(label), BorderLayout.NORTH);
        JTextField tf = new JTextField();
        tf.setEditable(false);
        tf.setBackground(new Color(238, 242, 246));
        p.add(tf, BorderLayout.CENTER);
        parent.add(p);
        return tf;
    }

    private JPanel createStatCard(String title, JLabel valLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 4));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(12, 14, 12, 14)
        ));
        JLabel t = new JLabel(title);
        t.setFont(new Font("SansSerif", Font.BOLD, 12));
        t.setForeground(new Color(100, 116, 139));
        valLabel.setFont(new Font("Monospaced", Font.BOLD, 24));
        valLabel.setForeground(color);
        card.add(t, BorderLayout.NORTH);
        card.add(valLabel, BorderLayout.CENTER);
        return card;
    }

    public final void loadAssignedTickets() {
        tableModel.setRowCount(0);
        if (currentTech == null) return;

        List<Ticket> list = ticketDAO.getTicketsByTechnicianId(currentTech.getTechnicianId());
        int assigned = list.size();
        int inProg = 0, resolved = 0, high = 0, critical = 0;

        for (Ticket t : list) {
            if ("IN_PROGRESS".equalsIgnoreCase(t.getStatus())) inProg++;
            if ("RESOLVED".equalsIgnoreCase(t.getStatus())) resolved++;
            if ("High".equalsIgnoreCase(t.getPriority())) high++;
            if ("Critical".equalsIgnoreCase(t.getPriority())) critical++;

            tableModel.addRow(new Object[]{
                    t.getTicketId(), t.getSubject(), t.getCategory(),
                    t.getPriority(), t.getUserName(), t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-"
            });
        }

        lblAssigned.setText(String.valueOf(assigned));
        lblInProgress.setText(String.valueOf(inProg));
        lblResolved.setText(String.valueOf(resolved));
        lblHighPriority.setText(String.valueOf(high));
        lblCritical.setText(String.valueOf(critical));
    }

    private void populateResolutionForm(String ticketId) {
        Ticket t = ticketDAO.getTicketById(ticketId);
        if (t == null) return;
        txtResTicketId.setText(t.getTicketId());
        txtResTechnician.setText(currentTech != null ? currentTech.getName() : "Technician");
        txtResDate.setText(LocalDateTime.now().format(FMT));
        txtResStatus.setText(t.getStatus());
        txtProblemDesc.setText(t.getDescription());
        txtResolutionDetails.setText(t.getResolutionDetails() != null ? t.getResolutionDetails() : "");
    }

    private void handleQuickStatusChange(String targetStatus, String note) {
        int r = table.getSelectedRow();
        if (r < 0) {
            JOptionPane.showMessageDialog(this, "Select an assigned ticket from the table first.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String ticketId = (String) tableModel.getValueAt(r, 0);
        String priority = (String) tableModel.getValueAt(r, 3);
        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        if (ticketDAO.updateStatusAndPriority(ticketId, targetStatus, priority, user.getUserId(), note)) {
            JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " status updated to " + targetStatus + ".");
            loadAssignedTickets();
            populateResolutionForm(ticketId);
        }
    }

    private void handleSubmitResolution() {
        String ticketId = txtResTicketId.getText().trim();
        String resDetails = txtResolutionDetails.getText().trim();

        if (ticketId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a ticket from your Assigned Tickets table.", "Selection Required", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (resDetails.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Resolution Details before marking as RESOLVED.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        if (ticketDAO.resolveTicket(ticketId, resDetails, user.getUserId())) {
            JOptionPane.showMessageDialog(this,
                    "Ticket " + ticketId + " marked as RESOLVED!\nResolution details and timestamp stored in MySQL.",
                    "Ticket Resolved",
                    JOptionPane.INFORMATION_MESSAGE);
            loadAssignedTickets();
            populateResolutionForm(ticketId);
        }
    }
}
