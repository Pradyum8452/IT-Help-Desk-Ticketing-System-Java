package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;

/**
 * TicketDetailsFrame provides ticket search by Ticket ID, displays full ticket metadata,
 * renders a visual workflow tracker (OPEN -> ASSIGNED -> IN_PROGRESS -> RESOLVED -> CLOSED),
 * and allows Users to confirm resolution (RESOLVED -> CLOSED).
 */
public class TicketDetailsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private static final String[] WORKFLOW_STEPS = {
            "OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"
    };

    private final TicketDAO ticketDAO = new TicketDAO();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private JTextField txtSearchTicketId;
    private final JLabel[] stepLabels = new JLabel[WORKFLOW_STEPS.length];

    private JLabel valTicketId;
    private JLabel valSubject;
    private JLabel valCategory;
    private JLabel valPriority;
    private JLabel valTechnician;
    private JLabel valStatus;
    private JLabel valCreatedDate;
    private JLabel valUpdatedDate;
    private JTextArea txtDescription;
    private JTextArea txtResolution;
    private JButton btnConfirmClose;
    private JButton btnViewHistory;

    private Ticket currentTicket;

    public TicketDetailsFrame(String initialTicketId) {
        setTitle("Track Ticket & Details — IT Help Desk System");
        setSize(820, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents(initialTicketId);
        if (initialTicketId != null && !initialTicketId.isBlank()) {
            searchAndDisplayTicket(initialTicketId.trim());
        }
    }

    private void initComponents(String initialTicketId) {
        setLayout(new BorderLayout(10, 10));

        // Top Header + Search Bar
        JPanel topContainer = new JPanel(new BorderLayout());
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Track Support Ticket Status & Resolution Details");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        topContainer.add(headerPanel, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Enter Ticket ID (e.g., HD-2026-0001):"));
        txtSearchTicketId = new JTextField(initialTicketId != null ? initialTicketId : "HD-2026-0001", 16);
        txtSearchTicketId.setFont(new Font("Monospaced", Font.BOLD, 13));
        searchBar.add(txtSearchTicketId);

        JButton btnTrack = new JButton("Search & Track Ticket");
        btnTrack.setBackground(PRIMARY_COLOR);
        btnTrack.setForeground(Color.WHITE);
        btnTrack.setFocusPainted(false);
        btnTrack.addActionListener(e -> searchAndDisplayTicket(txtSearchTicketId.getText().trim()));
        searchBar.add(btnTrack);

        topContainer.add(searchBar, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        // Main Content Panel
        JPanel mainPanel = new JPanel(new BorderLayout(12, 12));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(new EmptyBorder(10, 18, 10, 18));

        // Visual Status Tracker: OPEN -> ASSIGNED -> IN_PROGRESS -> RESOLVED -> CLOSED
        JPanel trackerPanel = new JPanel(new GridLayout(1, WORKFLOW_STEPS.length, 8, 0));
        trackerPanel.setBackground(Color.WHITE);
        trackerPanel.setBorder(BorderFactory.createTitledBorder("Visual Status Tracker"));
        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            JLabel lbl = new JLabel(WORKFLOW_STEPS[i].replace('_', ' '), SwingConstants.CENTER);
            lbl.setOpaque(true);
            lbl.setFont(new Font("Monospaced", Font.BOLD, 12));
            lbl.setBorder(new EmptyBorder(10, 6, 10, 6));
            lbl.setBackground(new Color(229, 231, 235));
            lbl.setForeground(Color.DARK_GRAY);
            stepLabels[i] = lbl;
            trackerPanel.add(lbl);
        }
        mainPanel.add(trackerPanel, BorderLayout.NORTH);

        // Details Grid + Description/Resolution
        JPanel centerBody = new JPanel(new BorderLayout(10, 10));
        centerBody.setBackground(BG_COLOR);

        JPanel metaGrid = new JPanel(new GridLayout(4, 2, 12, 8));
        metaGrid.setBackground(Color.WHITE);
        metaGrid.setBorder(new EmptyBorder(14, 16, 14, 16));

        valTicketId = createFieldRow(metaGrid, "Ticket ID:");
        valStatus = createFieldRow(metaGrid, "Current Status:");
        valSubject = createFieldRow(metaGrid, "Subject:");
        valCategory = createFieldRow(metaGrid, "Category:");
        valPriority = createFieldRow(metaGrid, "Priority:");
        valTechnician = createFieldRow(metaGrid, "Assigned Technician:");
        valCreatedDate = createFieldRow(metaGrid, "Created Date:");
        valUpdatedDate = createFieldRow(metaGrid, "Last Updated:");

        centerBody.add(metaGrid, BorderLayout.NORTH);

        JPanel textAreasPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        textAreasPanel.setBackground(BG_COLOR);

        txtDescription = new JTextArea(3, 40);
        txtDescription.setEditable(false);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(txtDescription);
        descScroll.setBorder(BorderFactory.createTitledBorder("Problem Description"));

        txtResolution = new JTextArea(3, 40);
        txtResolution.setEditable(false);
        txtResolution.setLineWrap(true);
        txtResolution.setWrapStyleWord(true);
        JScrollPane resScroll = new JScrollPane(txtResolution);
        resScroll.setBorder(BorderFactory.createTitledBorder("Resolution Details"));

        textAreasPanel.add(descScroll);
        textAreasPanel.add(resScroll);

        centerBody.add(textAreasPanel, BorderLayout.CENTER);
        mainPanel.add(centerBody, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);

        // Footer Actions
        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        footerPanel.setBackground(BG_COLOR);

        btnViewHistory = new JButton("View Ticket History");
        btnViewHistory.setBackground(SECONDARY_COLOR);
        btnViewHistory.setForeground(Color.WHITE);
        btnViewHistory.setFocusPainted(false);
        btnViewHistory.setEnabled(false);
        btnViewHistory.addActionListener(e -> {
            if (currentTicket != null) {
                new TicketHistoryFrame(currentTicket.getTicketId()).setVisible(true);
            }
        });

        btnConfirmClose = new JButton("Confirm Resolution & Close Ticket");
        btnConfirmClose.setBackground(new Color(22, 163, 74));
        btnConfirmClose.setForeground(Color.WHITE);
        btnConfirmClose.setFocusPainted(false);
        btnConfirmClose.setEnabled(false);
        btnConfirmClose.addActionListener(e -> handleConfirmResolution());

        JButton btnClose = new JButton("Close Window");
        btnClose.addActionListener(e -> dispose());

        footerPanel.add(btnViewHistory);
        footerPanel.add(btnConfirmClose);
        footerPanel.add(btnClose);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private JLabel createFieldRow(JPanel parent, String labelText) {
        JPanel p = new JPanel(new BorderLayout(6, 0));
        p.setBackground(Color.WHITE);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        JLabel val = new JLabel("-");
        val.setFont(new Font("SansSerif", Font.PLAIN, 12));
        p.add(lbl, BorderLayout.WEST);
        p.add(val, BorderLayout.CENTER);
        parent.add(p);
        return val;
    }

    private void searchAndDisplayTicket(String ticketId) {
        if (ticketId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a Ticket ID to track.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Ticket ticket = ticketDAO.getTicketById(ticketId);
        if (ticket == null) {
            JOptionPane.showMessageDialog(this,
                    "No ticket found with ID: " + ticketId,
                    "Ticket Not Found",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Security check: Regular USER can only track their own tickets
        User user = SessionManager.getCurrentUser();
        if (user != null && user.isRegularUser() && ticket.getUserId() != user.getUserId()) {
            JOptionPane.showMessageDialog(this,
                    "Access Denied: You can only view tickets created under your account.",
                    "Role Security",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        this.currentTicket = ticket;
        valTicketId.setText(ticket.getTicketId());
        valStatus.setText(ticket.getStatus());
        valSubject.setText(ticket.getSubject());
        valCategory.setText(ticket.getCategory());
        valPriority.setText(ticket.getPriority());
        valTechnician.setText(ticket.getTechnicianName());
        valCreatedDate.setText(ticket.getCreatedAt() != null ? ticket.getCreatedAt().format(FMT) : "-");
        valUpdatedDate.setText(ticket.getUpdatedAt() != null ? ticket.getUpdatedAt().format(FMT) : "-");
        txtDescription.setText(ticket.getDescription());
        txtResolution.setText(ticket.getResolutionDetails() != null
                ? ticket.getResolutionDetails()
                : "Pending resolution by assigned technician.");

        updateVisualTracker(ticket.getStatus());
        btnViewHistory.setEnabled(true);
        btnConfirmClose.setEnabled("RESOLVED".equalsIgnoreCase(ticket.getStatus()));
    }

    private void updateVisualTracker(String currentStatus) {
        int currentIndex = -1;
        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            if (WORKFLOW_STEPS[i].equalsIgnoreCase(currentStatus)) {
                currentIndex = i;
                break;
            }
        }

        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            if (i == currentIndex) {
                stepLabels[i].setBackground(ACCENT_COLOR);
                stepLabels[i].setForeground(Color.WHITE);
                stepLabels[i].setBorder(new LineBorder(PRIMARY_COLOR, 2));
            } else if (i < currentIndex) {
                stepLabels[i].setBackground(PRIMARY_COLOR);
                stepLabels[i].setForeground(Color.WHITE);
                stepLabels[i].setBorder(new EmptyBorder(10, 6, 10, 6));
            } else {
                stepLabels[i].setBackground(new Color(229, 231, 235));
                stepLabels[i].setForeground(Color.DARK_GRAY);
                stepLabels[i].setBorder(new EmptyBorder(10, 6, 10, 6));
            }
        }
    }

    private void handleConfirmResolution() {
        if (currentTicket == null) return;
        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you satisfied with the resolution for ticket " + currentTicket.getTicketId() + "?\n"
                + "This will mark the ticket as CLOSED.",
                "Confirm Ticket Closure",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean updated = ticketDAO.updateStatusAndPriority(
                    currentTicket.getTicketId(),
                    "CLOSED",
                    currentTicket.getPriority(),
                    user.getUserId(),
                    "User confirmed resolution and closed the ticket."
            );
            if (updated) {
                JOptionPane.showMessageDialog(this,
                        "Ticket " + currentTicket.getTicketId() + " is now CLOSED.",
                        "Ticket Closed",
                        JOptionPane.INFORMATION_MESSAGE);
                searchAndDisplayTicket(currentTicket.getTicketId());
            }
        }
    }
}
