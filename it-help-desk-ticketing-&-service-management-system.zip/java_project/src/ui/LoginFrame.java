package ui;

import dao.TechnicianDAO;
import dao.UserDAO;
import database.DBConnection;
import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Technician;
import model.User;
import utils.SessionManager;

/**
 * LoginFrame provides the authentication screen for ADMIN, TECHNICIAN, and USER roles.
 * Performs SHA-256 authentication against MySQL and automatically routes to the
 * role-specific dashboard (AdminDashboard, TechnicianDashboard, or UserDashboard).
 * Note: AdminDashboard and TechnicianDashboard are completed in Phase 4.
 */
public class LoginFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final UserDAO userDAO = new UserDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();

    private JTextField txtUsernameOrEmail;
    private JPasswordField txtPassword;

    public LoginFrame() {
        setTitle("Login — IT Help Desk Ticketing & Service Management System");
        setSize(520, 440);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Top Branding Header
        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(20, 28, 20, 28));

        JLabel lblTitle = new JLabel("IT Help Desk Management System");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubtitle = new JLabel("Role-Based Ticketing & Service Portal (Admin / Technician / User)");
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSubtitle.setForeground(new Color(203, 213, 225));

        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);
        add(headerPanel, BorderLayout.NORTH);

        // Center Login Card
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(BG_COLOR);
        centerWrapper.setBorder(new EmptyBorder(20, 32, 20, 32));

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(203, 213, 225), 1),
                new EmptyBorder(24, 28, 24, 28)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lblUser = new JLabel("Email or Username:");
        lblUser.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblUser.setForeground(TEXT_COLOR);
        formCard.add(lblUser, gbc);

        gbc.gridy = 1;
        txtUsernameOrEmail = new JTextField(22);
        txtUsernameOrEmail.setFont(new Font("SansSerif", Font.PLAIN, 14));
        formCard.add(txtUsernameOrEmail, gbc);

        gbc.gridy = 2;
        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblPass.setForeground(TEXT_COLOR);
        formCard.add(lblPass, gbc);

        gbc.gridy = 3;
        txtPassword = new JPasswordField(22);
        txtPassword.setFont(new Font("SansSerif", Font.PLAIN, 14));
        formCard.add(txtPassword, gbc);

        // Buttons Row: Login, Clear, Exit
        gbc.gridy = 4;
        gbc.insets = new Insets(18, 8, 4, 8);
        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonRow.setBackground(Color.WHITE);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBackground(PRIMARY_COLOR);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnLogin.setPreferredSize(new Dimension(110, 36));
        btnLogin.addActionListener(e -> performLogin());

        JButton btnClear = new JButton("Clear");
        btnClear.setBackground(SECONDARY_COLOR);
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnClear.setPreferredSize(new Dimension(95, 36));
        btnClear.addActionListener(e -> {
            txtUsernameOrEmail.setText("");
            txtPassword.setText("");
            txtUsernameOrEmail.requestFocusInWindow();
        });

        JButton btnExit = new JButton("Exit");
        btnExit.setBackground(new Color(220, 38, 38));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnExit.setPreferredSize(new Dimension(85, 36));
        btnExit.addActionListener(e -> System.exit(0));

        buttonRow.add(btnLogin);
        buttonRow.add(btnClear);
        buttonRow.add(btnExit);
        formCard.add(buttonRow, gbc);

        GridBagConstraints wrapperGbc = new GridBagConstraints();
        wrapperGbc.fill = GridBagConstraints.BOTH;
        wrapperGbc.weightx = 1.0;
        wrapperGbc.weighty = 1.0;
        centerWrapper.add(formCard, wrapperGbc);

        add(centerWrapper, BorderLayout.CENTER);
        getRootPane().setDefaultButton(btnLogin);
    }

    private void performLogin() {
        String identifier = txtUsernameOrEmail.getText().trim();
        String password = new String(txtPassword.getPassword());

        // 1. Validate empty fields
        if (identifier.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both Email/Username and Password.",
                    "Empty Fields",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // 2. Check MySQL connection availability
        if (!DBConnection.testConnection()) {
            JOptionPane.showMessageDialog(this,
                    "Database Connection Failure!\n"
                    + "Unable to connect to MySQL database 'helpdesk_db'.\n"
                    + "Please verify MySQL Server is running and credentials in DBConnection.java are correct.",
                    "Database Unavailable",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            // 3. Check if username/email exists
            User foundUser = userDAO.findByEmailOrUsername(identifier);
            if (foundUser == null) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Username or Email Address.\nNo account found matching: " + identifier,
                        "Invalid Username",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 4. Verify SHA-256 hashed password
            User authenticatedUser = userDAO.authenticate(identifier, password);
            if (authenticatedUser == null) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Password! Please check your password and try again.",
                        "Invalid Password",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 5. Check account active status
            if (!authenticatedUser.isActive()) {
                JOptionPane.showMessageDialog(this,
                        "Your account is currently INACTIVE.\nPlease contact the System Administrator.",
                        "Account Inactive",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 6. Load Technician profile if role == TECHNICIAN
            Technician linkedTech = null;
            if (authenticatedUser.isTechnician()) {
                linkedTech = technicianDAO.getTechnicianByUser(authenticatedUser.getUserId(), authenticatedUser.getEmail());
            }

            SessionManager.login(authenticatedUser, linkedTech);
            dispose();

            // 7. Route to Role-Specific Dashboard
            if (authenticatedUser.isAdmin()) {
                new AdminDashboard().setVisible(true);
            } else if (authenticatedUser.isTechnician()) {
                new TechnicianDashboard().setVisible(true);
            } else {
                new UserDashboard().setVisible(true);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Database error during authentication:\n" + ex.getMessage(),
                    "SQL Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
