package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;
import utils.TicketIDGenerator;

/**
 * CreateTicketFrame allows a logged-in User to raise a new technical support ticket.
 * Automatically generates a unique Ticket ID (e.g., HD-2026-0001) and stores it in MySQL.
 */
public class CreateTicketFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final Runnable onTicketCreatedCallback;

    private JTextField txtTicketId;
    private JTextField txtUser;
    private JTextField txtDateTime;
    private JTextField txtSubject;
    private JComboBox<String> cmbCategory;
    private JComboBox<String> cmbPriority;
    private JTextArea txtDescription;

    public CreateTicketFrame(Runnable onTicketCreatedCallback) {
        this.onTicketCreatedCallback = onTicketCreatedCallback;
        setTitle("Create New Support Ticket — IT Help Desk System");
        setSize(680, 580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Header Banner
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel lblTitle = new JLabel("Create New Technical Support Ticket");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new EmptyBorder(20, 28, 20, 28));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        User currentUser = SessionManager.getCurrentUser();
        String userNameDisplay = currentUser != null
                ? currentUser.getName() + " (" + currentUser.getDepartment() + ")"
                : "Guest User";

        String generatedId = TicketIDGenerator.generateNextTicketId();
        String currentTimestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        // Row 0: Ticket ID & Date/Time
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.25;
        formPanel.add(createLabel("Ticket ID (Auto):"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        txtTicketId = new JTextField(generatedId);
        txtTicketId.setEditable(false);
        txtTicketId.setFont(new Font("Monospaced", Font.BOLD, 13));
        txtTicketId.setBackground(new Color(238, 242, 246));
        formPanel.add(txtTicketId, gbc);

        // Row 1: User
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.25;
        formPanel.add(createLabel("Raised By User:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        txtUser = new JTextField(userNameDisplay);
        txtUser.setEditable(false);
        txtUser.setBackground(new Color(238, 242, 246));
        formPanel.add(txtUser, gbc);

        // Row 2: Date/Time
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.25;
        formPanel.add(createLabel("Date / Time:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        txtDateTime = new JTextField(currentTimestamp);
        txtDateTime.setEditable(false);
        txtDateTime.setBackground(new Color(238, 242, 246));
        formPanel.add(txtDateTime, gbc);

        // Row 3: Subject
        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.25;
        formPanel.add(createLabel("Subject *:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        txtSubject = new JTextField();
        txtSubject.setFont(new Font("SansSerif", Font.PLAIN, 13));
        formPanel.add(txtSubject, gbc);

        // Row 4: Category
        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0.25;
        formPanel.add(createLabel("Category *:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        cmbCategory = new JComboBox<>(new String[]{
                "Hardware", "Software", "Network", "Printer", "Email", "Account/Login", "Other"
        });
        formPanel.add(cmbCategory, gbc);

        // Row 5: Priority
        gbc.gridx = 0; gbc.gridy = 5; gbc.weightx = 0.25;
        formPanel.add(createLabel("Priority *:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        cmbPriority = new JComboBox<>(new String[]{"Low", "Medium", "High", "Critical"});
        cmbPriority.setSelectedItem("Medium");
        formPanel.add(cmbPriority, gbc);

        // Row 6: Description
        gbc.gridx = 0; gbc.gridy = 6; gbc.weightx = 0.25;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        formPanel.add(createLabel("Problem Description *:"), gbc);

        gbc.gridx = 1; gbc.weightx = 0.75;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        txtDescription = new JTextArea(5, 30);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        txtDescription.setFont(new Font("SansSerif", Font.PLAIN, 13));
        JScrollPane scrollDesc = new JScrollPane(txtDescription);
        formPanel.add(scrollDesc, gbc);

        add(formPanel, BorderLayout.CENTER);

        // Footer Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        buttonPanel.setBackground(BG_COLOR);

        JButton btnSubmit = new JButton("Submit Ticket");
        btnSubmit.setBackground(PRIMARY_COLOR);
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setFocusPainted(false);
        btnSubmit.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnSubmit.addActionListener(e -> handleSubmitTicket());

        JButton btnClear = new JButton("Clear");
        btnClear.setBackground(SECONDARY_COLOR);
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.addActionListener(e -> {
            txtSubject.setText("");
            txtDescription.setText("");
            cmbCategory.setSelectedIndex(0);
            cmbPriority.setSelectedItem("Medium");
        });

        JButton btnClose = new JButton("Cancel");
        btnClose.addActionListener(e -> dispose());

        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnClose);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        lbl.setForeground(TEXT_COLOR);
        return lbl;
    }

    private void handleSubmitTicket() {
        String subject = txtSubject.getText().trim();
        String description = txtDescription.getText().trim();
        String category = (String) cmbCategory.getSelectedItem();
        String priority = (String) cmbPriority.getSelectedItem();

        if (subject.isEmpty() || description.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please fill in both the Subject and Problem Description.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (subject.length() < 5) {
            JOptionPane.showMessageDialog(this,
                    "Subject must be at least 5 characters long.",
                    "Validation Error",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        User currentUser = SessionManager.getCurrentUser();
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this,
                    "Session expired. Please log in again.",
                    "Session Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        String ticketId = TicketIDGenerator.generateNextTicketId();
        Ticket newTicket = new Ticket(
                ticketId,
                subject,
                description,
                category,
                priority,
                currentUser.getUserId()
        );

        boolean success = ticketDAO.createTicket(newTicket);
        if (success) {
            JOptionPane.showMessageDialog(this,
                    "Support Ticket Created Successfully!\n\n"
                    + "Generated Ticket ID: " + ticketId + "\n"
                    + "Initial Status: OPEN\n"
                    + "Priority: " + priority,
                    "Ticket Submitted",
                    JOptionPane.INFORMATION_MESSAGE);

            if (onTicketCreatedCallback != null) {
                onTicketCreatedCallback.run();
            }
            dispose();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Failed to save ticket to MySQL database. Please verify database connection.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
