package dao;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.User;
import utils.PasswordUtil;

/**
 * UserDAO performs all JDBC CRUD and authentication operations on the users table.
 */
public class UserDAO {

    /**
     * Authenticates a user by email or username and plain-text password.
     *
     * @param identifier email or username
     * @param plainPassword plain-text password entered on LoginFrame
     * @return authenticated User object, or null if credentials are invalid
     * @throws SQLException if database connection fails
     */
    public User authenticate(String identifier, String plainPassword) throws SQLException {
        String sql = "SELECT * FROM users WHERE (email = ? OR username = ?) LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, identifier.trim());
            pstmt.setString(2, identifier.trim());

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password");
                    if (PasswordUtil.verifyPassword(plainPassword, storedHash)) {
                        return mapResultSetToUser(rs);
                    }
                }
            }
        }
        return null;
    }

    /**
     * Checks if a username or email exists in the database (used to distinguish
     * invalid username vs invalid password on LoginFrame).
     */
    public User findByEmailOrUsername(String identifier) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, identifier.trim());
            pstmt.setString(2, identifier.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        }
        return null;
    }

    /**
     * Retrieves all users ordered by user_id.
     */
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY user_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToUser(rs));
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error fetching users: " + e.getMessage());
        }
        return list;
    }

    /**
     * Searches users by name, email, username, or department.
     */
    public List<User> searchUsers(String keyword) {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE name LIKE ? OR email LIKE ? OR username LIKE ? OR department LIKE ? ORDER BY user_id ASC";
        String pattern = "%" + keyword.trim() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            pstmt.setString(4, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToUser(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error searching users: " + e.getMessage());
        }
        return list;
    }

    /**
     * Checks if an email is already registered (excluding a specific userId when updating).
     */
    public boolean isEmailTaken(String email, int excludeUserId) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email.trim());
            pstmt.setInt(2, excludeUserId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Email check error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Checks if a username is already registered (excluding a specific userId when updating).
     */
    public boolean isUsernameTaken(String username, int excludeUserId) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username.trim());
            pstmt.setInt(2, excludeUserId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Username check error: " + e.getMessage());
        }
        return false;
    }

    /**
     * Inserts a new User into the MySQL users table.
     * Automatically hashes the password using SHA-256 before storing.
     */
    public boolean addUser(User user) {
        String sql = "INSERT INTO users (name, email, phone, department, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getName().trim());
            pstmt.setString(2, user.getEmail().trim());
            pstmt.setString(3, user.getPhone().trim());
            pstmt.setString(4, user.getDepartment().trim());
            pstmt.setString(5, user.getUsername().trim());
            // Hash plain password if it isn't already a 64-char SHA-256 hex string
            String pwd = user.getPassword();
            if (pwd != null && pwd.length() != 64) {
                pwd = PasswordUtil.hashPassword(pwd);
            }
            pstmt.setString(6, pwd);
            pstmt.setString(7, user.getRole());
            pstmt.setString(8, user.getStatus());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error adding user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates an existing user's profile details (and optionally password if non-empty).
     */
    public boolean updateUser(User user, String newPlainPassword) {
        boolean updatePassword = newPlainPassword != null && !newPlainPassword.isBlank();
        String sql = updatePassword
                ? "UPDATE users SET name = ?, email = ?, phone = ?, department = ?, username = ?, password = ?, role = ?, status = ? WHERE user_id = ?"
                : "UPDATE users SET name = ?, email = ?, phone = ?, department = ?, username = ?, role = ?, status = ? WHERE user_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, user.getName().trim());
            pstmt.setString(2, user.getEmail().trim());
            pstmt.setString(3, user.getPhone().trim());
            pstmt.setString(4, user.getDepartment().trim());
            pstmt.setString(5, user.getUsername().trim());

            if (updatePassword) {
                pstmt.setString(6, PasswordUtil.hashPassword(newPlainPassword.trim()));
                pstmt.setString(7, user.getRole());
                pstmt.setString(8, user.getStatus());
                pstmt.setInt(9, user.getUserId());
            } else {
                pstmt.setString(6, user.getRole());
                pstmt.setString(7, user.getStatus());
                pstmt.setInt(8, user.getUserId());
            }
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error updating user: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a user by user_id.
     */
    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Cannot delete user (may have linked tickets): " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns total number of users in the database.
     */
    public int getTotalUserCount() {
        String sql = "SELECT COUNT(*) FROM users";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error counting users: " + e.getMessage());
        }
        return 0;
    }

    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime createdAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new User(
                rs.getInt("user_id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getString("department"),
                rs.getString("username"),
                rs.getString("password"),
                rs.getString("role"),
                rs.getString("status"),
                createdAt
        );
    }
}
