package dao;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import model.Technician;
import model.Ticket;
import model.TicketHistory;

/**
 * TicketDAO handles all JDBC CRUD, workflow status transitions, technician assignment,
 * resolution updates, and SQL aggregate report queries for the tickets table.
 */
public class TicketDAO {

    private final TicketHistoryDAO historyDAO = new TicketHistoryDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();

    private static final String BASE_SELECT_JOIN =
            "SELECT t.*, u.name AS user_name, u.email AS user_email, "
            + "tech.name AS tech_name, tech.specialization AS tech_spec "
            + "FROM tickets t "
            + "INNER JOIN users u ON t.user_id = u.user_id "
            + "LEFT JOIN technicians tech ON t.technician_id = tech.technician_id ";

    /**
     * Creates a new support ticket with initial status OPEN and logs a creation record in ticket_history.
     */
    public boolean createTicket(Ticket ticket) {
        String sql = "INSERT INTO tickets (ticket_id, subject, description, category, priority, status, user_id) "
                + "VALUES (?, ?, ?, ?, ?, 'OPEN', ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ticket.getTicketId());
            pstmt.setString(2, ticket.getSubject().trim());
            pstmt.setString(3, ticket.getDescription().trim());
            pstmt.setString(4, ticket.getCategory());
            pstmt.setString(5, ticket.getPriority());
            pstmt.setInt(6, ticket.getUserId());

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticket.getTicketId(),
                        null,
                        "OPEN",
                        ticket.getUserId(),
                        "Ticket created with priority " + ticket.getPriority() + " under category " + ticket.getCategory() + "."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error creating ticket: " + e.getMessage());
        }
        return false;
    }

    /**
     * Retrieves a single ticket by its Ticket ID (e.g., HD-2026-0001).
     */
    public Ticket getTicketById(String ticketId) {
        String sql = BASE_SELECT_JOIN + "WHERE t.ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ticketId.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTicket(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching ticket by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Retrieves all tickets ordered by creation date descending.
     */
    public List<Ticket> getAllTickets() {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToTicket(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching all tickets: " + e.getMessage());
        }
        return list;
    }

    /**
     * Searches and filters tickets by keyword, status, priority, and category.
     */
    public List<Ticket> searchAndFilterTickets(String keyword, String status, String priority, String category) {
        List<Ticket> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(BASE_SELECT_JOIN + "WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append("AND (t.ticket_id LIKE ? OR t.subject LIKE ? OR u.name LIKE ?) ");
            String pattern = "%" + keyword.trim() + "%";
            params.add(pattern);
            params.add(pattern);
            params.add(pattern);
        }
        if (status != null && !status.equalsIgnoreCase("ALL")) {
            sql.append("AND t.status = ? ");
            params.add(status);
        }
        if (priority != null && !priority.equalsIgnoreCase("ALL")) {
            sql.append("AND t.priority = ? ");
            params.add(priority);
        }
        if (category != null && !category.equalsIgnoreCase("ALL")) {
            sql.append("AND t.category = ? ");
            params.add(category);
        }
        sql.append("ORDER BY t.created_at DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {

            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToTicket(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error filtering tickets: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves all tickets created by a specific user.
     */
    public List<Ticket> getTicketsByUserId(int userId) {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "WHERE t.user_id = ? ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToTicket(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching user tickets: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves all tickets assigned to a specific technician.
     */
    public List<Ticket> getTicketsByTechnicianId(int technicianId) {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "WHERE t.technician_id = ? ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, technicianId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToTicket(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching technician tickets: " + e.getMessage());
        }
        return list;
    }

    /**
     * Assigns an active technician to a ticket, sets status = ASSIGNED, and records history.
     * Prevents assigning inactive technicians.
     */
    public boolean assignTechnician(String ticketId, int technicianId, int adminUserId) {
        Technician tech = technicianDAO.getTechnicianById(technicianId);
        if (tech == null || !tech.isActive()) {
            System.err.println("[TicketDAO] Cannot assign inactive or missing technician.");
            return false;
        }

        Ticket existing = getTicketById(ticketId);
        if (existing == null) {
            return false;
        }

        String sql = "UPDATE tickets SET technician_id = ?, status = 'ASSIGNED', updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, technicianId);
            pstmt.setString(2, ticketId);

            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId,
                        existing.getStatus(),
                        "ASSIGNED",
                        adminUserId,
                        "Ticket assigned to Technician " + tech.getName() + " (" + tech.getSpecialization() + ")."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error assigning technician: " + e.getMessage());
        }
        return false;
    }

    /**
     * Updates ticket status and priority, and records a ticket_history audit log.
     */
    public boolean updateStatusAndPriority(String ticketId, String newStatus, String newPriority, int changedByUserId, String note) {
        Ticket existing = getTicketById(ticketId);
        if (existing == null) {
            return false;
        }

        String sql = "UPDATE tickets SET status = ?, priority = ?, updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newStatus);
            pstmt.setString(2, newPriority);
            pstmt.setString(3, ticketId);

            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId,
                        existing.getStatus(),
                        newStatus,
                        changedByUserId,
                        note != null && !note.isBlank() ? note : "Status updated to " + newStatus + " (Priority: " + newPriority + ")."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error updating status/priority: " + e.getMessage());
        }
        return false;
    }

    /**
     * Stores resolution details, sets status = RESOLVED, sets resolved_at timestamp, and logs history.
     */
    public boolean resolveTicket(String ticketId, String resolutionDetails, int changedByUserId) {
        Ticket existing = getTicketById(ticketId);
        if (existing == null) {
            return false;
        }

        String sql = "UPDATE tickets SET resolution_details = ?, status = 'RESOLVED', "
                + "resolved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, resolutionDetails.trim());
            pstmt.setString(2, ticketId);

            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId,
                        existing.getStatus(),
                        "RESOLVED",
                        changedByUserId,
                        "Resolved: " + resolutionDetails.trim()
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error resolving ticket: " + e.getMessage());
        }
        return false;
    }

    /**
     * SQL Aggregate Query: Counts tickets by status (or ALL if status is null).
     */
    public int getTicketCountByStatus(String status) {
        String sql = (status == null || status.equalsIgnoreCase("ALL"))
                ? "SELECT COUNT(*) FROM tickets"
                : "SELECT COUNT(*) FROM tickets WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            if (status != null && !status.equalsIgnoreCase("ALL")) {
                pstmt.setString(1, status);
            }
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error counting tickets by status: " + e.getMessage());
        }
        return 0;
    }

    /**
     * SQL Aggregate Query for Reports: Returns ticket count grouped by Category.
     */
    public Map<String, Integer> getTicketCountsByCategory() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT category, COUNT(*) AS total FROM tickets GROUP BY category ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                map.put(rs.getString("category"), rs.getInt("total"));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by category: " + e.getMessage());
        }
        return map;
    }

    /**
     * SQL Aggregate Query for Reports: Returns ticket count grouped by Priority.
     */
    public Map<String, Integer> getTicketCountsByPriority() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT priority, COUNT(*) AS total FROM tickets GROUP BY priority ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                map.put(rs.getString("priority"), rs.getInt("total"));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by priority: " + e.getMessage());
        }
        return map;
    }

    /**
     * SQL Aggregate Query for Reports: Returns ticket count handled by each Technician.
     */
    public Map<String, Integer> getTicketCountsByTechnician() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT tech.name AS tech_name, COUNT(t.ticket_id) AS total "
                + "FROM technicians tech "
                + "LEFT JOIN tickets t ON tech.technician_id = t.technician_id "
                + "GROUP BY tech.technician_id, tech.name "
                + "ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                map.put(rs.getString("tech_name"), rs.getInt("total"));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by technician: " + e.getMessage());
        }
        return map;
    }

    private Ticket mapResultSetToTicket(ResultSet rs) throws SQLException {
        int rawTechId = rs.getInt("technician_id");
        Integer techId = rs.wasNull() ? null : rawTechId;

        Timestamp createdTs = rs.getTimestamp("created_at");
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        Timestamp resolvedTs = rs.getTimestamp("resolved_at");

        Ticket ticket = new Ticket(
                rs.getString("ticket_id"),
                rs.getString("subject"),
                rs.getString("description"),
                rs.getString("category"),
                rs.getString("priority"),
                rs.getString("status"),
                rs.getInt("user_id"),
                techId,
                rs.getString("resolution_details"),
                createdTs != null ? createdTs.toLocalDateTime() : LocalDateTime.now(),
                updatedTs != null ? updatedTs.toLocalDateTime() : LocalDateTime.now(),
                resolvedTs != null ? resolvedTs.toLocalDateTime() : null
        );
        ticket.setUserName(rs.getString("user_name"));
        ticket.setUserEmail(rs.getString("user_email"));
        ticket.setTechnicianName(rs.getString("tech_name"));
        ticket.setTechnicianSpecialization(rs.getString("tech_spec"));
        return ticket;
    }
}
