package dao;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Technician;

/**
 * TechnicianDAO handles all JDBC CRUD operations on the technicians table.
 */
public class TechnicianDAO {

    /**
     * Retrieves all technicians ordered by technician_id.
     */
    public List<Technician> getAllTechnicians() {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians ORDER BY technician_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToTechnician(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error fetching technicians: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves only ACTIVE technicians for ticket assignment.
     */
    public List<Technician> getActiveTechnicians() {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians WHERE status = 'ACTIVE' ORDER BY name ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToTechnician(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error fetching active technicians: " + e.getMessage());
        }
        return list;
    }

    /**
     * Finds a Technician profile linked to a specific user_id or email.
     */
    public Technician getTechnicianByUser(int userId, String email) {
        String sql = "SELECT * FROM technicians WHERE user_id = ? OR email = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, userId);
            pstmt.setString(2, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTechnician(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error finding technician by user: " + e.getMessage());
        }
        return null;
    }

    /**
     * Finds a Technician by technician_id.
     */
    public Technician getTechnicianById(int technicianId) {
        String sql = "SELECT * FROM technicians WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, technicianId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToTechnician(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error finding technician by ID: " + e.getMessage());
        }
        return null;
    }

    /**
     * Searches technicians by name, email, or specialization.
     */
    public List<Technician> searchTechnicians(String keyword) {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians WHERE name LIKE ? OR email LIKE ? OR specialization LIKE ? ORDER BY technician_id ASC";
        String pattern = "%" + keyword.trim() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToTechnician(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error searching technicians: " + e.getMessage());
        }
        return list;
    }

    /**
     * Adds a new technician record.
     */
    public boolean addTechnician(Technician tech) {
        String sql = "INSERT INTO technicians (user_id, name, email, phone, specialization, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            if (tech.getUserId() != null && tech.getUserId() > 0) {
                pstmt.setInt(1, tech.getUserId());
            } else {
                pstmt.setNull(1, Types.INTEGER);
            }
            pstmt.setString(2, tech.getName().trim());
            pstmt.setString(3, tech.getEmail().trim());
            pstmt.setString(4, tech.getPhone().trim());
            pstmt.setString(5, tech.getSpecialization());
            pstmt.setString(6, tech.getStatus());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error adding technician: " + e.getMessage());
            return false;
        }
    }

    /**
     * Updates an existing technician's details.
     */
    public boolean updateTechnician(Technician tech) {
        String sql = "UPDATE technicians SET name = ?, email = ?, phone = ?, specialization = ?, status = ? WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, tech.getName().trim());
            pstmt.setString(2, tech.getEmail().trim());
            pstmt.setString(3, tech.getPhone().trim());
            pstmt.setString(4, tech.getSpecialization());
            pstmt.setString(5, tech.getStatus());
            pstmt.setInt(6, tech.getTechnicianId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error updating technician: " + e.getMessage());
            return false;
        }
    }

    /**
     * Toggles or updates a technician's ACTIVE / INACTIVE status.
     */
    public boolean updateTechnicianStatus(int technicianId, String newStatus) {
        String sql = "UPDATE technicians SET status = ? WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, newStatus);
            pstmt.setInt(2, technicianId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error updating technician status: " + e.getMessage());
            return false;
        }
    }

    /**
     * Deletes a technician by technician_id.
     */
    public boolean deleteTechnician(int technicianId) {
        String sql = "DELETE FROM technicians WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, technicianId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error deleting technician: " + e.getMessage());
            return false;
        }
    }

    /**
     * Returns total number of technicians.
     */
    public int getTotalTechnicianCount() {
        String sql = "SELECT COUNT(*) FROM technicians";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error counting technicians: " + e.getMessage());
        }
        return 0;
    }

    private Technician mapResultSetToTechnician(ResultSet rs) throws SQLException {
        int rawUserId = rs.getInt("user_id");
        Integer userId = rs.wasNull() ? null : rawUserId;
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime createdAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();

        return new Technician(
                rs.getInt("technician_id"),
                userId,
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getString("specialization"),
                rs.getString("status"),
                createdAt
        );
    }
}
