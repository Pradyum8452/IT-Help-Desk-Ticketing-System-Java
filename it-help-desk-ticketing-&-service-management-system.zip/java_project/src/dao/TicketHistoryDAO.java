package dao;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.TicketHistory;

/**
 * TicketHistoryDAO manages chronological audit records in the ticket_history table.
 */
public class TicketHistoryDAO {

    /**
     * Inserts a new status transition or update log into ticket_history.
     */
    public boolean addHistory(TicketHistory history) {
        String sql = "INSERT INTO ticket_history (ticket_id, previous_status, new_status, changed_by, change_description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, history.getTicketId());
            if (history.getPreviousStatus() != null && !history.getPreviousStatus().isBlank()) {
                pstmt.setString(2, history.getPreviousStatus());
            } else {
                pstmt.setNull(2, Types.VARCHAR);
            }
            pstmt.setString(3, history.getNewStatus());
            pstmt.setInt(4, history.getChangedBy());
            pstmt.setString(5, history.getChangeDescription());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error adding history record: " + e.getMessage());
            return false;
        }
    }

    /**
     * Retrieves all history records in chronological order, joined with users table.
     */
    public List<TicketHistory> getAllHistory() {
        List<TicketHistory> list = new ArrayList<>();
        String sql = "SELECT th.*, u.name AS changed_by_name, u.role AS changed_by_role "
                + "FROM ticket_history th "
                + "LEFT JOIN users u ON th.changed_by = u.user_id "
                + "ORDER BY th.changed_at ASC, th.history_id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToHistory(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error fetching all history: " + e.getMessage());
        }
        return list;
    }

    /**
     * Retrieves chronological history for a specific Ticket ID.
     */
    public List<TicketHistory> getHistoryByTicketId(String ticketId) {
        List<TicketHistory> list = new ArrayList<>();
        String sql = "SELECT th.*, u.name AS changed_by_name, u.role AS changed_by_role "
                + "FROM ticket_history th "
                + "LEFT JOIN users u ON th.changed_by = u.user_id "
                + "WHERE th.ticket_id = ? "
                + "ORDER BY th.changed_at ASC, th.history_id ASC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, ticketId.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToHistory(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error fetching history for ticket: " + e.getMessage());
        }
        return list;
    }

    private TicketHistory mapResultSetToHistory(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("changed_at");
        LocalDateTime changedAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();

        TicketHistory item = new TicketHistory(
                rs.getInt("history_id"),
                rs.getString("ticket_id"),
                rs.getString("previous_status"),
                rs.getString("new_status"),
                rs.getInt("changed_by"),
                rs.getString("change_description"),
                changedAt
        );
        item.setChangedByName(rs.getString("changed_by_name"));
        item.setChangedByRole(rs.getString("changed_by_role"));
        return item;
    }
}
