package model;

import java.time.LocalDateTime;

/**
 * User model class representing a system user (ADMIN, TECHNICIAN, or USER).
 * Demonstrates Encapsulation, Constructor Overloading, and Method Overriding.
 */
public class User {

    private int userId;
    private String name;
    private String email;
    private String phone;
    private String department;
    private String username;
    private String password; // Stores SHA-256 hashed password
    private String role;     // ADMIN, TECHNICIAN, USER
    private String status;   // ACTIVE, INACTIVE
    private LocalDateTime createdAt;

    /**
     * Default no-argument constructor.
     */
    public User() {
        this.role = "USER";
        this.status = "ACTIVE";
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Parameterized constructor for creating a new User before database insertion (no userId yet).
     */
    public User(String name, String email, String phone, String department,
                String username, String password, String role, String status) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.username = username;
        this.password = password;
        this.role = role;
        this.status = status;
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Full parameterized constructor for loading an existing User from MySQL ResultSet.
     */
    public User(int userId, String name, String email, String phone, String department,
                String username, String password, String role, String status, LocalDateTime createdAt) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.username = username;
        this.password = password;
        this.role = role;
        this.status = status;
        this.createdAt = createdAt;
    }

    // ==================== GETTERS AND SETTERS ====================

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // ==================== HELPER METHODS ====================

    public boolean isAdmin() {
        return "ADMIN".equalsIgnoreCase(this.role);
    }

    public boolean isTechnician() {
        return "TECHNICIAN".equalsIgnoreCase(this.role);
    }

    public boolean isRegularUser() {
        return "USER".equalsIgnoreCase(this.role);
    }

    public boolean isActive() {
        return "ACTIVE".equalsIgnoreCase(this.status);
    }

    @Override
    public String toString() {
        return String.format("%s (%s - %s)", name, username, role);
    }
}
