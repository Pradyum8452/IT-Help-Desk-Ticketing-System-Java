package model;

import java.time.LocalDateTime;

/**
 * TicketHistory model class representing an audit log entry in the ticket_history table.
 * Tracks every status transition, assignment, and resolution update.
 */
public class TicketHistory {

    private int historyId;
    private String ticketId;
    private String previousStatus;
    private String newStatus;
    private int changedBy;          // Foreign key to users(user_id)
    private String changeDescription;
    private LocalDateTime changedAt;

    // Joined display fields from users table
    private String changedByName;
    private String changedByRole;

    /**
     * Default no-argument constructor.
     */
    public TicketHistory() {
        this.changedAt = LocalDateTime.now();
    }

    /**
     * Constructor for creating a new TicketHistory entry before inserting into MySQL.
     */
    public TicketHistory(String ticketId, String previousStatus, String newStatus,
                         int changedBy, String changeDescription) {
        this.ticketId = ticketId;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.changedBy = changedBy;
        this.changeDescription = changeDescription;
        this.changedAt = LocalDateTime.now();
    }

    /**
     * Full parameterized constructor for loading TicketHistory from MySQL ResultSet.
     */
    public TicketHistory(int historyId, String ticketId, String previousStatus,
                         String newStatus, int changedBy, String changeDescription,
                         LocalDateTime changedAt) {
        this.historyId = historyId;
        this.ticketId = ticketId;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.changedBy = changedBy;
        this.changeDescription = changeDescription;
        this.changedAt = changedAt;
    }

    // ==================== GETTERS AND SETTERS ====================

    public int getHistoryId() {
        return historyId;
    }

    public void setHistoryId(int historyId) {
        this.historyId = historyId;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getPreviousStatus() {
        return previousStatus;
    }

    public void setPreviousStatus(String previousStatus) {
        this.previousStatus = previousStatus;
    }

    public String getNewStatus() {
        return newStatus;
    }

    public void setNewStatus(String newStatus) {
        this.newStatus = newStatus;
    }

    public int getChangedBy() {
        return changedBy;
    }

    public void setChangedBy(int changedBy) {
        this.changedBy = changedBy;
    }

    public String getChangeDescription() {
        return changeDescription;
    }

    public void setChangeDescription(String changeDescription) {
        this.changeDescription = changeDescription;
    }

    public LocalDateTime getChangedAt() {
        return changedAt;
    }

    public void setChangedAt(LocalDateTime changedAt) {
        this.changedAt = changedAt;
    }

    public String getChangedByName() {
        return (changedByName != null && !changedByName.isBlank()) ? changedByName : "User #" + changedBy;
    }

    public void setChangedByName(String changedByName) {
        this.changedByName = changedByName;
    }

    public String getChangedByRole() {
        return changedByRole != null ? changedByRole : "";
    }

    public void setChangedByRole(String changedByRole) {
        this.changedByRole = changedByRole;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s -> %s by %s: %s",
                ticketId,
                previousStatus != null ? previousStatus : "NONE",
                newStatus,
                getChangedByName(),
                changeDescription);
    }
}
