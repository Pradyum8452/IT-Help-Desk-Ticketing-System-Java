package model;

import java.time.LocalDateTime;

/**
 * Technician model class representing an IT support specialist.
 * Specializations: Hardware, Software, Network, Database, General Support.
 */
public class Technician {

    private int technicianId;
    private Integer userId; // Nullable foreign key to users.user_id
    private String name;
    private String email;
    private String phone;
    private String specialization; // Hardware, Software, Network, Database, General Support
    private String status;         // ACTIVE, INACTIVE
    private LocalDateTime createdAt;

    /**
     * Default no-argument constructor.
     */
    public Technician() {
        this.specialization = "General Support";
        this.status = "ACTIVE";
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Parameterized constructor for adding a new Technician.
     */
    public Technician(Integer userId, String name, String email, String phone,
                      String specialization, String status) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.specialization = specialization;
        this.status = status;
        this.createdAt = LocalDateTime.now();
    }

    /**
     * Full parameterized constructor for loading a Technician from MySQL ResultSet.
     */
    public Technician(int technicianId, Integer userId, String name, String email,
                      String phone, String specialization, String status, LocalDateTime createdAt) {
        this.technicianId = technicianId;
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.specialization = specialization;
        this.status = status;
        this.createdAt = createdAt;
    }

    // ==================== GETTERS AND SETTERS ====================

    public int getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(int technicianId) {
        this.technicianId = technicianId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public boolean isActive() {
        return "ACTIVE".equalsIgnoreCase(this.status);
    }

    /**
     * Overridden toString() used directly by JComboBox when selecting a Technician for assignment.
     */
    @Override
    public String toString() {
        return String.format("Tech #%d - %s [%s] (%s)", technicianId, name, specialization, status);
    }
}
