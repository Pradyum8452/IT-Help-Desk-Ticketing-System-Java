package model;

import java.time.LocalDateTime;

/**
 * Ticket model class representing a technical support request.
 * Workflow: OPEN -> ASSIGNED -> IN_PROGRESS -> RESOLVED -> CLOSED
 */
public class Ticket {

    private String ticketId;       // Format: HD-2026-0001
    private String subject;
    private String description;
    private String category;       // Hardware, Software, Network, Printer, Email, Account/Login, Other
    private String priority;       // Low, Medium, High, Critical
    private String status;         // OPEN, ASSIGNED, IN_PROGRESS, RESOLVED, CLOSED
    private int userId;            // Foreign key to users(user_id)
    private Integer technicianId;  // Nullable Foreign key to technicians(technician_id)
    private String resolutionDetails;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime resolvedAt;

    // Joined display fields populated by SQL JOIN queries for JTable views
    private String userName;
    private String userEmail;
    private String technicianName;
    private String technicianSpecialization;

    /**
     * Default no-argument constructor.
     */
    public Ticket() {
        this.status = "OPEN";
        this.priority = "Medium";
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Constructor for creating a new Ticket from CreateTicketFrame.
     */
    public Ticket(String ticketId, String subject, String description,
                  String category, String priority, int userId) {
        this.ticketId = ticketId;
        this.subject = subject;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = "OPEN";
        this.userId = userId;
        this.technicianId = null;
        this.resolutionDetails = null;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.resolvedAt = null;
    }

    /**
     * Full constructor for loading a Ticket from MySQL ResultSet.
     */
    public Ticket(String ticketId, String subject, String description, String category,
                  String priority, String status, int userId, Integer technicianId,
                  String resolutionDetails, LocalDateTime createdAt,
                  LocalDateTime updatedAt, LocalDateTime resolvedAt) {
        this.ticketId = ticketId;
        this.subject = subject;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = status;
        this.userId = userId;
        this.technicianId = technicianId;
        this.resolutionDetails = resolutionDetails;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.resolvedAt = resolvedAt;
    }

    // ==================== GETTERS AND SETTERS ====================

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Integer getTechnicianId() {
        return technicianId;
    }

    public void setTechnicianId(Integer technicianId) {
        this.technicianId = technicianId;
    }

    public String getResolutionDetails() {
        return resolutionDetails;
    }

    public void setResolutionDetails(String resolutionDetails) {
        this.resolutionDetails = resolutionDetails;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public LocalDateTime getResolvedAt() {
        return resolvedAt;
    }

    public void setResolvedAt(LocalDateTime resolvedAt) {
        this.resolvedAt = resolvedAt;
    }

    public String getUserName() {
        return userName != null ? userName : "User #" + userId;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getTechnicianName() {
        return (technicianName != null && !technicianName.isBlank()) ? technicianName : "Unassigned";
    }

    public void setTechnicianName(String technicianName) {
        this.technicianName = technicianName;
    }

    public String getTechnicianSpecialization() {
        return technicianSpecialization;
    }

    public void setTechnicianSpecialization(String technicianSpecialization) {
        this.technicianSpecialization = technicianSpecialization;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s - %s)", ticketId, subject, priority, status);
    }
}
