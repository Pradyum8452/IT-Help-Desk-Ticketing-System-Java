# IT Help Desk Ticketing and Service Management System Using Java

**Course:** TY EXTC — Java Programming Micro Project (Academic Year 2026–2027)  
**Technology Stack:** Java 22 · Java Swing · MySQL 8+ · JDBC (`mysql-connector-j`)

---

## 1. Project Description
The **IT Help Desk Ticketing and Service Management System** is a role-based desktop application built using **Java 22**, **Java Swing**, **JDBC**, and **MySQL 8+**. It enables employees (`USER`) to log technical support issues, administrators (`ADMIN`) to manage users, technicians, ticket assignments, and analytical reports, and support engineers (`TECHNICIAN`) to diagnose, resolve, and close assigned tickets with a full chronological audit trail.

---

## 2. Key Features
- **Role-Based Authentication**: Multi-role login (`ADMIN`, `TECHNICIAN`, `USER`) using **SHA-256** password hashing and MySQL verification.
- **Automatic Ticket ID Generation**: Generates sequential ticket numbers in the format `HD-2026-0001`.
- **5-Stage Ticket Lifecycle**: `OPEN` $\rightarrow$ `ASSIGNED` $\rightarrow$ `IN_PROGRESS` $\rightarrow$ `RESOLVED` $\rightarrow$ `CLOSED`.
- **Visual Ticket Status Tracker**: Interactive status pipeline for users to track ticket progress and resolution details.
- **Chronological Audit Trail**: Every status transition and assignment is recorded in the `ticket_history` table.
- **Admin Management & Reports**: Full CRUD for Users and Technicians, active technician enforcement, SQL `GROUP BY` aggregate reports, and **CSV Export**.

---

## 3. Technologies Used
| Layer | Technology |
| :--- | :--- |
| Programming Language | Java 22 (Standard Edition) |
| Graphical User Interface | Java Swing (`javax.swing`, `java.awt`) |
| Relational Database | MySQL 8.0+ (`helpdesk_db`) |
| Database Connectivity | JDBC (`PreparedStatement`, `ResultSet`, `DriverManager`) |
| Security | `java.security.MessageDigest` (SHA-256 Hashing) |
| IDE Compatibility | VS Code, IntelliJ IDEA, Eclipse |

---

## 4. System Requirements
- **JDK**: Java Development Kit 22
- **Database**: MySQL Server 8.0+ & MySQL Workbench
- **JDBC Driver**: `mysql-connector-j-8.4.0.jar`

---

## 5. Database Setup
1. Start your local MySQL 8+ server.
2. Open MySQL Workbench or the MySQL command-line client and execute:
   ```sql
   SOURCE database/helpdesk.sql;
   ```
3. Verify that the database `helpdesk_db` and tables (`users`, `technicians`, `tickets`, `ticket_history`) are created.

---

## 6. JDBC Setup & How to Run
1. Download `mysql-connector-j-8.4.0.jar` and place it inside the `lib/` folder.
2. Update your MySQL username/password in `src/database/DBConnection.java` (or set `DB_USER` and `DB_PASSWORD` environment variables).
3. **Compile and Run via Terminal**:
   ```bash
   # Compile all packages
   javac -cp "lib/mysql-connector-j-8.4.0.jar" -d out \
     src/database/*.java src/model/*.java src/utils/*.java src/dao/*.java src/ui/*.java src/Main.java

   # Run the application (Linux/macOS use ':', Windows use ';')
   java -cp "out:lib/mysql-connector-j-8.4.0.jar" Main
   ```

---

## 7. Sample Login Credentials
| Role | Email | Username | Password |
| :--- | :--- | :--- | :--- |
| **ADMIN** | `admin@helpdesk.com` | `admin` | `Admin@123` |
| **TECHNICIAN** | `technician@helpdesk.com` | `technician` | `Tech@123` |
| **USER** | `user@helpdesk.com` | `user` | `User@123` |

---

## 8. Project Structure
```text
src/
├── Main.java
├── database/
│   └── DBConnection.java
├── model/
│   ├── User.java
│   ├── Technician.java
│   ├── Ticket.java
│   └── TicketHistory.java
├── dao/
│   ├── UserDAO.java
│   ├── TechnicianDAO.java
│   ├── TicketDAO.java
│   └── TicketHistoryDAO.java
├── ui/
│   ├── LoginFrame.java
│   ├── UserDashboard.java
│   ├── AdminDashboard.java
│   ├── TechnicianDashboard.java
│   ├── CreateTicketFrame.java
│   ├── MyTicketsFrame.java
│   ├── ManageUsersFrame.java
│   ├── ManageTechniciansFrame.java
│   ├── ManageTicketsFrame.java
│   ├── TicketDetailsFrame.java
│   └── TicketHistoryFrame.java
└── utils/
    ├── PasswordUtil.java
    ├── TicketIDGenerator.java
    └── SessionManager.java
```

---

## 9. Future Scope
- Automated email/SMS notifications via JavaMail API on ticket assignment and resolution.
- SLA (Service Level Agreement) escalation timers for `Critical` priority tickets.
- File attachment support for uploading error screenshots into MySQL `LONGBLOB` or network storage.
