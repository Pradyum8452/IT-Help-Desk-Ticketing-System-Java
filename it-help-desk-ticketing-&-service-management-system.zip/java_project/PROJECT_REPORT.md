# TY EXTC JAVA PROGRAMMING MICROPROJECT REPORT (A.Y. 2026–2027)

## 1. Title
**IT Help Desk Ticketing and Service Management System Using Java**

## 2. Abstract
Modern academic institutions and corporate enterprises rely heavily on IT infrastructure including workstations, laboratory networks, licensed engineering software, and printers. When technical faults occur, tracking issues via phone calls or informal emails leads to delayed resolutions and zero accountability. This microproject presents an **IT Help Desk Ticketing and Service Management System** developed using **Java 22**, **Java Swing**, **JDBC**, and **MySQL 8+**. The system implements three distinct roles (`ADMIN`, `TECHNICIAN`, and `USER`), SHA-256 cryptographic password hashing, automated ticket ID generation (`HD-2026-XXXX`), a five-stage workflow (`OPEN` $\rightarrow$ `ASSIGNED` $\rightarrow$ `IN_PROGRESS` $\rightarrow$ `RESOLVED` $\rightarrow$ `CLOSED`), a visual status tracker, chronological audit logging (`ticket_history`), and SQL aggregate reporting with CSV export.

## 3. Introduction
An IT Help Desk serves as the single point of contact between end-users and the technical support team. Built strictly with standard Object-Oriented Java 22 and the Swing GUI toolkit, this desktop application demonstrates clean 3-Tier architecture separating Presentation (`ui`), Business/Utilities (`utils`), Data Access Objects (`dao`), Entity Models (`model`), and Relational Persistence (`database`).

## 4. Problem Statement
In traditional college laboratories and office departments, technical complaints are logged in paper registers or reported verbally. This causes:
1. Lost or forgotten support requests.
2. Inability for users to track whether their issue is being worked on.
3. Unbalanced workload across hardware, software, and network technicians.
4. Lack of historical audit trails and performance reports.

## 5. Objectives
- To design a role-based Java Swing desktop application for `ADMIN`, `TECHNICIAN`, and `USER` accounts.
- To implement secure MySQL authentication using SHA-256 password hashing and parameterized `PreparedStatement` queries.
- To automate unique Ticket ID generation (`HD-2026-0001`) and track ticket lifecycle transitions.
- To maintain an immutable chronological history of every ticket change in MySQL.
- To generate real-time SQL aggregate reports and export records to CSV.

## 6. Scope
The system covers internal organizational IT support across seven core categories (`Hardware`, `Software`, `Network`, `Printer`, `Email`, `Account/Login`, `Other`) and four priority levels (`Low`, `Medium`, `High`, `Critical`). It supports multi-user LAN deployment connected to a central MySQL 8+ database server.

## 7. Existing System
- Relies on manual register entries, phone calls, or unorganized spreadsheets.
- No automated ticket numbering or priority classification.
- No restriction preventing assignment of tickets to unavailable/inactive technicians.
- Zero visibility for end-users after reporting a fault.

## 8. Proposed System
- Centralized MySQL 8+ database (`helpdesk_db`) accessed via JDBC.
- Role-specific Swing dashboards launched automatically after login.
- Enforces active-technician validation during ticket assignment.
- Provides a visual 5-step status tracker (`OPEN → ASSIGNED → IN PROGRESS → RESOLVED → CLOSED`) and CSV report export.

## 9. Hardware Requirements
- **Processor**: Intel Core i3 / AMD Ryzen 3 or higher (2.0 GHz+)
- **RAM**: Minimum 4 GB (8 GB recommended)
- **Disk Space**: 500 MB free space for JDK 22 and MySQL 8+
- **Display**: 1366 × 768 or 1920 × 1080 resolution

## 10. Software Requirements
- **Operating System**: Windows 10/11, Ubuntu Linux, or macOS
- **Programming Language**: Java 22 (JDK 22)
- **GUI Framework**: Java Swing (`javax.swing`, `java.awt`)
- **Database**: MySQL Server 8.0+
- **JDBC Driver**: MySQL Connector/J (`mysql-connector-j-8.4.0.jar`)
- **IDE**: VS Code / IntelliJ IDEA / Eclipse

## 11. System Architecture
The application follows a **3-Tier Layered Architecture**:
1. **Presentation Tier (`package ui`)**: 11 Swing `JFrame` classes handling user interaction, input validation, and table rendering.
2. **Application & DAO Tier (`package utils`, `package dao`, `package model`)**: Encapsulates business logic, SHA-256 security, session state, POJO entities, and JDBC operations.
3. **Database Tier (`helpdesk_db`)**: MySQL 8+ relational tables with foreign key constraints.

## 12. Modules
1. **Authentication & Session Module**: `LoginFrame`, `PasswordUtil`, `SessionManager`.
2. **User Portal Module**: `UserDashboard`, `CreateTicketFrame`, `MyTicketsFrame`, `TicketDetailsFrame`.
3. **Admin Control Module**: `AdminDashboard`, `ManageUsersFrame`, `ManageTechniciansFrame`, `ManageTicketsFrame`.
4. **Technician Resolution Module**: `TechnicianDashboard` (Accept ticket, Start work, Resolution form, Close ticket).
5. **Audit & Reporting Module**: `TicketHistoryFrame`, SQL `GROUP BY` analytics, and CSV exporter.

## 13. Database Design
The `helpdesk_db` schema consists of four normalized InnoDB tables:
- **`users`**: `user_id (PK)`, `name`, `email (UNIQUE)`, `phone`, `department`, `username (UNIQUE)`, `password (SHA-256)`, `role`, `status`, `created_at`.
- **`technicians`**: `technician_id (PK)`, `user_id (FK UNIQUE)`, `name`, `email (UNIQUE)`, `phone`, `specialization`, `status`, `created_at`.
- **`tickets`**: `ticket_id (PK)`, `subject`, `description`, `category`, `priority`, `status`, `user_id (FK)`, `technician_id (FK)`, `resolution_details`, `created_at`, `updated_at`, `resolved_at`.
- **`ticket_history`**: `history_id (PK)`, `ticket_id (FK)`, `previous_status`, `new_status`, `changed_by (FK)`, `change_description`, `changed_at`.

## 14. ER Diagram Description
- **Entities**: `User`, `Technician`, `Ticket`, `TicketHistory`.
- **Relationships**:
  - `User` **raises** `Ticket` ($1 : N$ relationship via `tickets.user_id`).
  - `Technician` **handles** `Ticket` ($1 : N$ relationship via `tickets.technician_id`).
  - `Ticket` **records** `TicketHistory` ($1 : N$ identifying relationship via `ticket_history.ticket_id` with `ON DELETE CASCADE`).

## 15. DFD Level 0 (Context Diagram) Description
The central process **0.0 IT Help Desk System** interacts with three external entities:
- **User**: Sends login credentials and ticket details; receives generated Ticket ID, visual status tracker, and resolution updates.
- **Admin**: Sends user/technician CRUD commands and ticket assignments; receives system-wide statistics and CSV reports.
- **Technician**: Sends status updates (`IN_PROGRESS`, `RESOLVED`) and resolution notes; receives assigned ticket queue.

## 16. DFD Level 1 Description
Breaks the system into 5 sub-processes connected to the 4 data stores (`D1: users`, `D2: technicians`, `D3: tickets`, `D4: ticket_history`):
- **1.0 Authenticate User**: Verifies SHA-256 password hash against `D1: users`.
- **2.0 Create & Track Ticket**: Generates `HD-2026-XXXX`, writes to `D3: tickets` and `D4: ticket_history`.
- **3.0 Manage Users & Technicians**: Performs CRUD on `D1: users` and `D2: technicians`.
- **4.0 Assign & Resolve Ticket**: Validates active technician in `D2`, updates `D3: tickets`, appends log to `D4: ticket_history`.
- **5.0 Generate Reports**: Executes SQL aggregate queries on `D3` and `D2`.

## 17. UML Use Case Description
- **Actor: User**: Login, Create Support Ticket, View My Tickets, Track Ticket Status, Confirm Resolution & Close Ticket, View Profile.
- **Actor: Technician**: Login, View Assigned Tickets, Accept & Start Work, Submit Resolution Details, Close Resolved Ticket.
- **Actor: Admin**: Login, Manage Users (CRUD), Manage Technicians (CRUD + Activate/Deactivate), View/Filter All Tickets, Assign Active Technician, Update Priority/Status, View Ticket History, Export Reports to CSV.

## 18. Class Diagram Description
- **Model Classes**: `User`, `Technician`, `Ticket`, `TicketHistory` (encapsulated private fields, overloaded constructors, getters/setters, overridden `toString()`).
- **DAO Classes**: `UserDAO`, `TechnicianDAO`, `TicketDAO`, `TicketHistoryDAO` (depend on `DBConnection` and Model classes).
- **Utility Classes**: `DBConnection`, `PasswordUtil`, `TicketIDGenerator`, `SessionManager`.
- **UI Classes**: 11 classes extending `javax.swing.JFrame` composed of Swing controls and associated with DAO classes.

## 19. Flowchart Description
1. **Start** $\rightarrow$ Launch `Main.java` $\rightarrow$ Open `LoginFrame`.
2. User enters Username/Email & Password $\rightarrow$ Validate non-empty & test MySQL connection.
3. Hash password with SHA-256 $\rightarrow$ Match against `users` table.
4. If invalid $\rightarrow$ Display `JOptionPane` error $\rightarrow$ Return to `LoginFrame`.
5. If valid $\rightarrow$ Check `role`:
   - `ADMIN` $\rightarrow$ Open `AdminDashboard` (Manage Users/Techs, Assign Tickets, Reports).
   - `TECHNICIAN` $\rightarrow$ Open `TechnicianDashboard` (Accept Ticket $\rightarrow$ Add Resolution $\rightarrow$ Mark `RESOLVED`).
   - `USER` $\rightarrow$ Open `UserDashboard` (Create Ticket $\rightarrow$ Track Ticket $\rightarrow$ Confirm Closure).
6. **Logout / Exit** $\rightarrow$ Clear `SessionManager` $\rightarrow$ **Stop**.

## 20. Testing
| Test Case ID | Test Scenario | Input | Expected Output | Status |
| :--- | :--- | :--- | :--- | :--- |
| **TC-01** | Admin Login | `admin@helpdesk.com` / `Admin@123` | Opens `AdminDashboard` | PASS |
| **TC-02** | Invalid Password | `admin@helpdesk.com` / `WrongPass` | `JOptionPane`: Invalid Password | PASS |
| **TC-03** | Create Ticket | Subject, Category: `Network`, Priority: `High` | Generates `HD-2026-0007`, Status = `OPEN` | PASS |
| **TC-04** | Inactive Tech Assignment | Select `INACTIVE` Technician Suresh Nair | Blocked / Excluded from active dropdown | PASS |
| **TC-05** | Technician Resolution | Enter resolution text & click Resolve | Status = `RESOLVED`, history row added | PASS |
| **TC-06** | User Confirm Resolution | Click Confirm & Close on `RESOLVED` ticket | Status = `CLOSED`, history row added | PASS |

## 21. Advantages
- Prevents unauthorized access via SHA-256 hashing and role-based session guards.
- Eliminates SQL injection vulnerabilities using `PreparedStatement`.
- Complete transparency through the visual workflow tracker and `ticket_history` audit table.
- Clean, student-friendly Object-Oriented Java 22 codebase without heavy external frameworks.

## 22. Limitations
- Requires a local or LAN-accessible MySQL 8+ server connection.
- Does not currently send automated external emails or SMS alerts when tickets are updated.

## 23. Future Scope
- Integration with JavaMail API for automated email alerts.
- Addition of SLA breach timers and PDF report generation.
- Support for file/screenshot attachments on tickets.

## 24. Conclusion
The **IT Help Desk Ticketing and Service Management System Using Java** successfully fulfills all objectives of the TY EXTC Java Programming Microproject (A.Y. 2026–2027). It demonstrates practical mastery of Object-Oriented Programming in **Java 22**, event-driven GUI development using **Java Swing**, relational database design in **MySQL 8+**, and secure **JDBC** persistence.
