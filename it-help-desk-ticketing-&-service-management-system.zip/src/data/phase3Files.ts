import { CodeFileEntry } from './phase1Files';

export const PHASE_3_FILES: CodeFileEntry[] = [
  {
    id: 'login_frame',
    path: 'src/ui/LoginFrame.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'Java Swing Login screen with MySQL SHA-256 authentication, input validation, and role-based dashboard routing.',
    content: `package ui;

import dao.TechnicianDAO;
import dao.UserDAO;
import database.DBConnection;
import java.awt.*;
import java.sql.SQLException;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Technician;
import model.User;
import utils.SessionManager;

public class LoginFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final UserDAO userDAO = new UserDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();

    private JTextField txtUsernameOrEmail;
    private JPasswordField txtPassword;

    public LoginFrame() {
        setTitle("Login — IT Help Desk Ticketing & Service Management System");
        setSize(520, 440);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel(new GridLayout(2, 1, 0, 4));
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(20, 28, 20, 28));

        JLabel lblTitle = new JLabel("IT Help Desk Management System");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSubtitle = new JLabel("Role-Based Ticketing & Service Portal (Admin / Technician / User)");
        lblSubtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSubtitle.setForeground(new Color(203, 213, 225));

        headerPanel.add(lblTitle);
        headerPanel.add(lblSubtitle);
        add(headerPanel, BorderLayout.NORTH);

        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setBackground(BG_COLOR);
        centerWrapper.setBorder(new EmptyBorder(20, 32, 20, 32));

        JPanel formCard = new JPanel(new GridBagLayout());
        formCard.setBackground(Color.WHITE);
        formCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(203, 213, 225), 1),
                new EmptyBorder(24, 28, 24, 28)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        gbc.gridx = 0; gbc.gridy = 0;
        JLabel lblUser = new JLabel("Email or Username:");
        lblUser.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblUser.setForeground(TEXT_COLOR);
        formCard.add(lblUser, gbc);

        gbc.gridy = 1;
        txtUsernameOrEmail = new JTextField(22);
        txtUsernameOrEmail.setFont(new Font("SansSerif", Font.PLAIN, 14));
        formCard.add(txtUsernameOrEmail, gbc);

        gbc.gridy = 2;
        JLabel lblPass = new JLabel("Password:");
        lblPass.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblPass.setForeground(TEXT_COLOR);
        formCard.add(lblPass, gbc);

        gbc.gridy = 3;
        txtPassword = new JPasswordField(22);
        txtPassword.setFont(new Font("SansSerif", Font.PLAIN, 14));
        formCard.add(txtPassword, gbc);

        gbc.gridy = 4;
        gbc.insets = new Insets(18, 8, 4, 8);
        JPanel buttonRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        buttonRow.setBackground(Color.WHITE);

        JButton btnLogin = new JButton("Login");
        btnLogin.setBackground(PRIMARY_COLOR);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnLogin.setPreferredSize(new Dimension(110, 36));
        btnLogin.addActionListener(e -> performLogin());

        JButton btnClear = new JButton("Clear");
        btnClear.setBackground(SECONDARY_COLOR);
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnClear.setPreferredSize(new Dimension(95, 36));
        btnClear.addActionListener(e -> {
            txtUsernameOrEmail.setText("");
            txtPassword.setText("");
            txtUsernameOrEmail.requestFocusInWindow();
        });

        JButton btnExit = new JButton("Exit");
        btnExit.setBackground(new Color(220, 38, 38));
        btnExit.setForeground(Color.WHITE);
        btnExit.setFocusPainted(false);
        btnExit.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnExit.setPreferredSize(new Dimension(85, 36));
        btnExit.addActionListener(e -> System.exit(0));

        buttonRow.add(btnLogin);
        buttonRow.add(btnClear);
        buttonRow.add(btnExit);
        formCard.add(buttonRow, gbc);

        GridBagConstraints wrapperGbc = new GridBagConstraints();
        wrapperGbc.fill = GridBagConstraints.BOTH;
        wrapperGbc.weightx = 1.0;
        wrapperGbc.weighty = 1.0;
        centerWrapper.add(formCard, wrapperGbc);

        add(centerWrapper, BorderLayout.CENTER);
        getRootPane().setDefaultButton(btnLogin);
    }

    private void performLogin() {
        String identifier = txtUsernameOrEmail.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (identifier.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter both Email/Username and Password.",
                    "Empty Fields", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (!DBConnection.testConnection()) {
            JOptionPane.showMessageDialog(this,
                    "Database Connection Failure! Verify MySQL Server is running.",
                    "Database Unavailable", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            User foundUser = userDAO.findByEmailOrUsername(identifier);
            if (foundUser == null) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Username or Email Address.",
                        "Invalid Username", JOptionPane.ERROR_MESSAGE);
                return;
            }

            User authenticatedUser = userDAO.authenticate(identifier, password);
            if (authenticatedUser == null) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Password! Please check your password and try again.",
                        "Invalid Password", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!authenticatedUser.isActive()) {
                JOptionPane.showMessageDialog(this,
                        "Your account is currently INACTIVE.",
                        "Account Inactive", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Technician linkedTech = null;
            if (authenticatedUser.isTechnician()) {
                linkedTech = technicianDAO.getTechnicianByUser(authenticatedUser.getUserId(), authenticatedUser.getEmail());
            }

            SessionManager.login(authenticatedUser, linkedTech);
            dispose();

            if (authenticatedUser.isAdmin()) {
                new AdminDashboard().setVisible(true);
            } else if (authenticatedUser.isTechnician()) {
                new TechnicianDashboard().setVisible(true);
            } else {
                new UserDashboard().setVisible(true);
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this,
                    "Database error during authentication: " + ex.getMessage(),
                    "SQL Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}`,
  },
  {
    id: 'user_dashboard',
    path: 'src/ui/UserDashboard.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'User Dashboard displaying ticket statistics (Total, Open, In Progress, Resolved, Closed) and navigation.',
    content: `package ui;

import dao.TicketDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;

public class UserDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final TicketDAO ticketDAO = new TicketDAO();

    private JLabel lblTotalCount;
    private JLabel lblOpenCount;
    private JLabel lblInProgressCount;
    private JLabel lblResolvedCount;
    private JLabel lblClosedCount;

    public UserDashboard() {
        if (!SessionManager.isLoggedIn()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }
        setTitle("User Dashboard — IT Help Desk Ticketing System");
        setSize(1020, 620);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        refreshDashboardStats();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        User user = SessionManager.getCurrentUser();
        String welcomeText = user != null
                ? "Welcome, " + user.getName() + "  |  Department: " + user.getDepartment()
                : "Welcome, User";

        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(240, 0));
        sidebar.setBorder(new EmptyBorder(20, 16, 20, 16));

        JPanel navButtonsPanel = new JPanel(new GridLayout(6, 1, 0, 10));
        navButtonsPanel.setOpaque(false);

        JLabel brandLabel = new JLabel("USER HELP DESK");
        brandLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        brandLabel.setForeground(ACCENT_COLOR);
        navButtonsPanel.add(brandLabel);

        JButton btnCreateTicket = createNavButton("Create New Ticket");
        btnCreateTicket.addActionListener(e -> new CreateTicketFrame(this::refreshDashboardStats).setVisible(true));

        JButton btnMyTickets = createNavButton("My Tickets");
        btnMyTickets.addActionListener(e -> new MyTicketsFrame().setVisible(true));

        JButton btnTrackTicket = createNavButton("Track Ticket");
        btnTrackTicket.addActionListener(e -> new TicketDetailsFrame("").setVisible(true));

        JButton btnProfile = createNavButton("My Profile");
        btnProfile.addActionListener(e -> showProfileDialog());

        JButton btnRefresh = createNavButton("Refresh Statistics");
        btnRefresh.addActionListener(e -> refreshDashboardStats());

        navButtonsPanel.add(btnCreateTicket);
        navButtonsPanel.add(btnMyTickets);
        navButtonsPanel.add(btnTrackTicket);
        navButtonsPanel.add(btnProfile);
        navButtonsPanel.add(btnRefresh);

        sidebar.add(navButtonsPanel, BorderLayout.NORTH);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setFont(new Font("SansSerif", Font.BOLD, 13));
        btnLogout.addActionListener(e -> handleLogout());
        sidebar.add(btnLogout, BorderLayout.SOUTH);

        add(sidebar, BorderLayout.WEST);

        JPanel mainContent = new JPanel(new BorderLayout(16, 16));
        mainContent.setBackground(BG_COLOR);
        mainContent.setBorder(new EmptyBorder(24, 28, 24, 28));

        JPanel welcomeBanner = new JPanel(new BorderLayout());
        welcomeBanner.setBackground(Color.WHITE);
        welcomeBanner.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(18, 22, 18, 22)
        ));

        JLabel lblWelcome = new JLabel(welcomeText);
        lblWelcome.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblWelcome.setForeground(PRIMARY_COLOR);
        welcomeBanner.add(lblWelcome, BorderLayout.WEST);
        mainContent.add(welcomeBanner, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout(0, 20));
        centerPanel.setBackground(BG_COLOR);

        JPanel statsGrid = new JPanel(new GridLayout(1, 5, 14, 0));
        statsGrid.setBackground(BG_COLOR);

        lblTotalCount = new JLabel("0");
        lblOpenCount = new JLabel("0");
        lblInProgressCount = new JLabel("0");
        lblResolvedCount = new JLabel("0");
        lblClosedCount = new JLabel("0");

        statsGrid.add(createStatCard("Total Tickets", lblTotalCount, PRIMARY_COLOR));
        statsGrid.add(createStatCard("Open Tickets", lblOpenCount, ACCENT_COLOR));
        statsGrid.add(createStatCard("In Progress", lblInProgressCount, SECONDARY_COLOR));
        statsGrid.add(createStatCard("Resolved", lblResolvedCount, new Color(22, 163, 74)));
        statsGrid.add(createStatCard("Closed", lblClosedCount, new Color(100, 116, 139)));

        centerPanel.add(statsGrid, BorderLayout.NORTH);

        JPanel guideCard = new JPanel(new BorderLayout(10, 10));
        guideCard.setBackground(Color.WHITE);
        guideCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(24, 24, 24, 24)
        ));

        JLabel lblGuideTitle = new JLabel("How to Raise & Track Support Tickets");
        lblGuideTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
        lblGuideTitle.setForeground(PRIMARY_COLOR);
        guideCard.add(lblGuideTitle, BorderLayout.NORTH);

        JTextArea txtGuide = new JTextArea(
                "1. Click 'Create New Ticket' to report Hardware, Software, Network, Printer, Email, or Account issues.\\n"
                + "2. Every ticket receives a unique ID (e.g., HD-2026-0001) and starts with status OPEN.\\n"
                + "3. Once the Administrator assigns an active specialist, status changes to ASSIGNED -> IN_PROGRESS.\\n"
                + "4. Use 'Track Ticket' to view real-time visual progress and technician resolution notes.\\n"
                + "5. When your issue is marked RESOLVED, confirm resolution in 'My Tickets' to mark it CLOSED."
        );
        txtGuide.setEditable(false);
        txtGuide.setFont(new Font("SansSerif", Font.PLAIN, 14));
        txtGuide.setForeground(TEXT_COLOR);
        txtGuide.setBackground(Color.WHITE);
        guideCard.add(txtGuide, BorderLayout.CENTER);

        centerPanel.add(guideCard, BorderLayout.CENTER);
        mainContent.add(centerPanel, BorderLayout.CENTER);
        add(mainContent, BorderLayout.CENTER);
    }

    private JButton createNavButton(String label) {
        JButton btn = new JButton(label);
        btn.setBackground(SECONDARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 13));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }

    private JPanel createStatCard(String title, JLabel valueLabel, Color accentBarColor) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(18, 16, 18, 16)
        ));

        JLabel lblTitle = new JLabel(title);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblTitle.setForeground(new Color(100, 116, 139));

        valueLabel.setFont(new Font("Monospaced", Font.BOLD, 28));
        valueLabel.setForeground(accentBarColor);

        card.add(lblTitle, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    public final void refreshDashboardStats() {
        User user = SessionManager.getCurrentUser();
        if (user == null) return;

        List<Ticket> myTickets = ticketDAO.getTicketsByUserId(user.getUserId());
        int total = myTickets.size();
        int open = 0, inProgress = 0, resolved = 0, closed = 0;

        for (Ticket t : myTickets) {
            String st = t.getStatus();
            if ("OPEN".equalsIgnoreCase(st)) open++;
            else if ("ASSIGNED".equalsIgnoreCase(st) || "IN_PROGRESS".equalsIgnoreCase(st)) inProgress++;
            else if ("RESOLVED".equalsIgnoreCase(st)) resolved++;
            else if ("CLOSED".equalsIgnoreCase(st)) closed++;
        }

        lblTotalCount.setText(String.valueOf(total));
        lblOpenCount.setText(String.valueOf(open));
        lblInProgressCount.setText(String.valueOf(inProgress));
        lblResolvedCount.setText(String.valueOf(resolved));
        lblClosedCount.setText(String.valueOf(closed));
    }

    private void showProfileDialog() {
        User u = SessionManager.getCurrentUser();
        if (u == null) return;
        String profileInfo = String.format(
                "User ID: %d\\nName: %s\\nUsername: %s\\nEmail: %s\\nPhone: %s\\nDepartment: %s\\nRole: %s\\nStatus: %s",
                u.getUserId(), u.getName(), u.getUsername(), u.getEmail(),
                u.getPhone(), u.getDepartment(), u.getRole(), u.getStatus()
        );
        JOptionPane.showMessageDialog(this, profileInfo, "My User Profile", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleLogout() {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        }
    }
}`,
  },
  {
    id: 'create_ticket_frame',
    path: 'src/ui/CreateTicketFrame.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'Ticket submission form with auto-generated Ticket ID (HD-2026-XXXX), category/priority dropdowns, and validation.',
    content: `package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;
import utils.TicketIDGenerator;

public class CreateTicketFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");
    private static final Color TEXT_COLOR = Color.decode("#1F2937");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final Runnable onTicketCreatedCallback;

    private JTextField txtTicketId;
    private JTextField txtUser;
    private JTextField txtDateTime;
    private JTextField txtSubject;
    private JComboBox<String> cmbCategory;
    private JComboBox<String> cmbPriority;
    private JTextArea txtDescription;

    public CreateTicketFrame(Runnable onTicketCreatedCallback) {
        this.onTicketCreatedCallback = onTicketCreatedCallback;
        setTitle("Create New Support Ticket — IT Help Desk System");
        setSize(680, 580);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(16, 24, 16, 24));
        JLabel lblTitle = new JLabel("Create New Technical Support Ticket");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setBorder(new EmptyBorder(20, 28, 20, 28));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        User currentUser = SessionManager.getCurrentUser();
        String userNameDisplay = currentUser != null
                ? currentUser.getName() + " (" + currentUser.getDepartment() + ")"
                : "Guest User";

        String generatedId = TicketIDGenerator.generateNextTicketId();
        String currentTimestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.25;
        formPanel.add(createLabel("Ticket ID (Auto):"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        txtTicketId = new JTextField(generatedId);
        txtTicketId.setEditable(false);
        txtTicketId.setFont(new Font("Monospaced", Font.BOLD, 13));
        txtTicketId.setBackground(new Color(238, 242, 246));
        formPanel.add(txtTicketId, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.25;
        formPanel.add(createLabel("Raised By User:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        txtUser = new JTextField(userNameDisplay);
        txtUser.setEditable(false);
        txtUser.setBackground(new Color(238, 242, 246));
        formPanel.add(txtUser, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.25;
        formPanel.add(createLabel("Date / Time:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        txtDateTime = new JTextField(currentTimestamp);
        txtDateTime.setEditable(false);
        txtDateTime.setBackground(new Color(238, 242, 246));
        formPanel.add(txtDateTime, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.weightx = 0.25;
        formPanel.add(createLabel("Subject *:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        txtSubject = new JTextField();
        formPanel.add(txtSubject, gbc);

        gbc.gridx = 0; gbc.gridy = 4; gbc.weightx = 0.25;
        formPanel.add(createLabel("Category *:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        cmbCategory = new JComboBox<>(new String[]{
                "Hardware", "Software", "Network", "Printer", "Email", "Account/Login", "Other"
        });
        formPanel.add(cmbCategory, gbc);

        gbc.gridx = 0; gbc.gridy = 5; gbc.weightx = 0.25;
        formPanel.add(createLabel("Priority *:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        cmbPriority = new JComboBox<>(new String[]{"Low", "Medium", "High", "Critical"});
        cmbPriority.setSelectedItem("Medium");
        formPanel.add(cmbPriority, gbc);

        gbc.gridx = 0; gbc.gridy = 6; gbc.weightx = 0.25;
        gbc.anchor = GridBagConstraints.NORTHWEST;
        formPanel.add(createLabel("Problem Description *:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.75;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1.0;
        txtDescription = new JTextArea(5, 30);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        formPanel.add(new JScrollPane(txtDescription), gbc);

        add(formPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        buttonPanel.setBackground(BG_COLOR);

        JButton btnSubmit = new JButton("Submit Ticket");
        btnSubmit.setBackground(PRIMARY_COLOR);
        btnSubmit.setForeground(Color.WHITE);
        btnSubmit.setFocusPainted(false);
        btnSubmit.addActionListener(e -> handleSubmitTicket());

        JButton btnClear = new JButton("Clear");
        btnClear.setBackground(SECONDARY_COLOR);
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.addActionListener(e -> {
            txtSubject.setText("");
            txtDescription.setText("");
            cmbCategory.setSelectedIndex(0);
            cmbPriority.setSelectedItem("Medium");
        });

        JButton btnClose = new JButton("Cancel");
        btnClose.addActionListener(e -> dispose());

        buttonPanel.add(btnSubmit);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnClose);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    private JLabel createLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        lbl.setForeground(TEXT_COLOR);
        return lbl;
    }

    private void handleSubmitTicket() {
        String subject = txtSubject.getText().trim();
        String description = txtDescription.getText().trim();
        String category = (String) cmbCategory.getSelectedItem();
        String priority = (String) cmbPriority.getSelectedItem();

        if (subject.isEmpty() || description.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both Subject and Description.",
                    "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        User currentUser = SessionManager.getCurrentUser();
        if (currentUser == null) return;

        String ticketId = TicketIDGenerator.generateNextTicketId();
        Ticket newTicket = new Ticket(ticketId, subject, description, category, priority, currentUser.getUserId());

        if (ticketDAO.createTicket(newTicket)) {
            JOptionPane.showMessageDialog(this,
                    "Support Ticket Created Successfully!\\nGenerated Ticket ID: " + ticketId + "\\nInitial Status: OPEN",
                    "Ticket Submitted", JOptionPane.INFORMATION_MESSAGE);
            if (onTicketCreatedCallback != null) onTicketCreatedCallback.run();
            dispose();
        }
    }
}`,
  },
  {
    id: 'my_tickets_frame',
    path: 'src/ui/MyTicketsFrame.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'JTable view of the logged-in user’s tickets with details viewer, history log, and resolution confirmation.',
    content: `package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Ticket;
import model.User;
import utils.SessionManager;

public class MyTicketsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private DefaultTableModel tableModel;
    private JTable table;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public MyTicketsFrame() {
        setTitle("My Support Tickets — IT Help Desk System");
        setSize(960, 540);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadUserTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("My Submitted Support Tickets");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);

        JButton btnRefresh = new JButton("Refresh List");
        btnRefresh.setBackground(ACCENT_COLOR);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.addActionListener(e -> loadUserTickets());
        headerPanel.add(btnRefresh, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        String[] cols = {
                "Ticket ID", "Subject", "Category", "Priority",
                "Assigned Technician", "Status", "Created Date", "Updated Date"
        };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(tableModel);
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        JPanel tableContainer = new JPanel(new BorderLayout());
        tableContainer.setBackground(BG_COLOR);
        tableContainer.setBorder(new EmptyBorder(12, 16, 12, 16));
        tableContainer.add(new JScrollPane(table), BorderLayout.CENTER);
        add(tableContainer, BorderLayout.CENTER);

        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        footerPanel.setBackground(BG_COLOR);

        JButton btnViewDetails = new JButton("View Details & Status Tracker");
        btnViewDetails.setBackground(PRIMARY_COLOR);
        btnViewDetails.setForeground(Color.WHITE);
        btnViewDetails.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) new TicketDetailsFrame((String) tableModel.getValueAt(row, 0)).setVisible(true);
        });

        JButton btnHistory = new JButton("View Ticket History");
        btnHistory.setBackground(SECONDARY_COLOR);
        btnHistory.setForeground(Color.WHITE);
        btnHistory.addActionListener(e -> {
            int row = table.getSelectedRow();
            if (row >= 0) new TicketHistoryFrame((String) tableModel.getValueAt(row, 0)).setVisible(true);
        });

        JButton btnConfirmResolution = new JButton("Confirm Resolution (Close Ticket)");
        btnConfirmResolution.setBackground(new Color(22, 163, 74));
        btnConfirmResolution.setForeground(Color.WHITE);
        btnConfirmResolution.addActionListener(e -> confirmSelectedResolution());

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());

        footerPanel.add(btnViewDetails);
        footerPanel.add(btnHistory);
        footerPanel.add(btnConfirmResolution);
        footerPanel.add(btnClose);
        add(footerPanel, BorderLayout.SOUTH);
    }

    public final void loadUserTickets() {
        tableModel.setRowCount(0);
        User currentUser = SessionManager.getCurrentUser();
        if (currentUser == null) return;
        List<Ticket> tickets = ticketDAO.getTicketsByUserId(currentUser.getUserId());
        for (Ticket t : tickets) {
            tableModel.addRow(new Object[]{
                    t.getTicketId(), t.getSubject(), t.getCategory(), t.getPriority(),
                    t.getTechnicianName(), t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-",
                    t.getUpdatedAt() != null ? t.getUpdatedAt().format(FMT) : "-"
            });
        }
    }

    private void confirmSelectedResolution() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String ticketId = (String) tableModel.getValueAt(row, 0);
        String status = (String) tableModel.getValueAt(row, 5);
        String priority = (String) tableModel.getValueAt(row, 3);

        if (!"RESOLVED".equalsIgnoreCase(status)) {
            JOptionPane.showMessageDialog(this, "Only RESOLVED tickets can be confirmed and closed.");
            return;
        }
        User user = SessionManager.getCurrentUser();
        if (user != null && ticketDAO.updateStatusAndPriority(ticketId, "CLOSED", priority, user.getUserId(), "User confirmed resolution and closed ticket.")) {
            JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " marked as CLOSED.");
            loadUserTickets();
        }
    }
}`,
  },
  {
    id: 'ticket_details_frame',
    path: 'src/ui/TicketDetailsFrame.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'User Ticket Tracking frame with Ticket ID search and visual status pipeline (OPEN -> ASSIGNED -> IN_PROGRESS -> RESOLVED -> CLOSED).',
    content: `package ui;

import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import model.User;
import utils.SessionManager;

public class TicketDetailsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private static final String[] WORKFLOW_STEPS = {
            "OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"
    };

    private final TicketDAO ticketDAO = new TicketDAO();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private JTextField txtSearchTicketId;
    private final JLabel[] stepLabels = new JLabel[WORKFLOW_STEPS.length];

    private JLabel valTicketId, valSubject, valCategory, valPriority, valTechnician, valStatus, valCreatedDate, valUpdatedDate;
    private JTextArea txtDescription, txtResolution;
    private JButton btnConfirmClose, btnViewHistory;
    private Ticket currentTicket;

    public TicketDetailsFrame(String initialTicketId) {
        setTitle("Track Ticket & Details — IT Help Desk System");
        setSize(820, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents(initialTicketId);
        if (initialTicketId != null && !initialTicketId.isBlank()) {
            searchAndDisplayTicket(initialTicketId.trim());
        }
    }

    private void initComponents(String initialTicketId) {
        setLayout(new BorderLayout(10, 10));

        JPanel topContainer = new JPanel(new BorderLayout());
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Track Support Ticket Status & Resolution Details");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        topContainer.add(headerPanel, BorderLayout.NORTH);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 10));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Enter Ticket ID:"));
        txtSearchTicketId = new JTextField(initialTicketId != null ? initialTicketId : "HD-2026-0001", 16);
        searchBar.add(txtSearchTicketId);

        JButton btnTrack = new JButton("Search & Track Ticket");
        btnTrack.setBackground(PRIMARY_COLOR);
        btnTrack.setForeground(Color.WHITE);
        btnTrack.addActionListener(e -> searchAndDisplayTicket(txtSearchTicketId.getText().trim()));
        searchBar.add(btnTrack);

        topContainer.add(searchBar, BorderLayout.SOUTH);
        add(topContainer, BorderLayout.NORTH);

        JPanel mainPanel = new JPanel(new BorderLayout(12, 12));
        mainPanel.setBackground(BG_COLOR);
        mainPanel.setBorder(new EmptyBorder(10, 18, 10, 18));

        JPanel trackerPanel = new JPanel(new GridLayout(1, WORKFLOW_STEPS.length, 8, 0));
        trackerPanel.setBackground(Color.WHITE);
        trackerPanel.setBorder(BorderFactory.createTitledBorder("Visual Status Tracker"));
        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            JLabel lbl = new JLabel(WORKFLOW_STEPS[i].replace('_', ' '), SwingConstants.CENTER);
            lbl.setOpaque(true);
            lbl.setFont(new Font("Monospaced", Font.BOLD, 12));
            lbl.setBorder(new EmptyBorder(10, 6, 10, 6));
            stepLabels[i] = lbl;
            trackerPanel.add(lbl);
        }
        mainPanel.add(trackerPanel, BorderLayout.NORTH);

        JPanel centerBody = new JPanel(new BorderLayout(10, 10));
        centerBody.setBackground(BG_COLOR);

        JPanel metaGrid = new JPanel(new GridLayout(4, 2, 12, 8));
        metaGrid.setBackground(Color.WHITE);
        metaGrid.setBorder(new EmptyBorder(14, 16, 14, 16));

        valTicketId = createFieldRow(metaGrid, "Ticket ID:");
        valStatus = createFieldRow(metaGrid, "Current Status:");
        valSubject = createFieldRow(metaGrid, "Subject:");
        valCategory = createFieldRow(metaGrid, "Category:");
        valPriority = createFieldRow(metaGrid, "Priority:");
        valTechnician = createFieldRow(metaGrid, "Assigned Technician:");
        valCreatedDate = createFieldRow(metaGrid, "Created Date:");
        valUpdatedDate = createFieldRow(metaGrid, "Last Updated:");

        centerBody.add(metaGrid, BorderLayout.NORTH);

        JPanel textAreasPanel = new JPanel(new GridLayout(2, 1, 10, 10));
        txtDescription = new JTextArea(3, 40);
        txtDescription.setEditable(false);
        JScrollPane descScroll = new JScrollPane(txtDescription);
        descScroll.setBorder(BorderFactory.createTitledBorder("Problem Description"));

        txtResolution = new JTextArea(3, 40);
        txtResolution.setEditable(false);
        JScrollPane resScroll = new JScrollPane(txtResolution);
        resScroll.setBorder(BorderFactory.createTitledBorder("Resolution Details"));

        textAreasPanel.add(descScroll);
        textAreasPanel.add(resScroll);
        centerBody.add(textAreasPanel, BorderLayout.CENTER);
        mainPanel.add(centerBody, BorderLayout.CENTER);
        add(mainPanel, BorderLayout.CENTER);

        JPanel footerPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 10));
        footerPanel.setBackground(BG_COLOR);

        btnViewHistory = new JButton("View Ticket History");
        btnViewHistory.setBackground(SECONDARY_COLOR);
        btnViewHistory.setForeground(Color.WHITE);
        btnViewHistory.setEnabled(false);
        btnViewHistory.addActionListener(e -> {
            if (currentTicket != null) new TicketHistoryFrame(currentTicket.getTicketId()).setVisible(true);
        });

        btnConfirmClose = new JButton("Confirm Resolution & Close Ticket");
        btnConfirmClose.setBackground(new Color(22, 163, 74));
        btnConfirmClose.setForeground(Color.WHITE);
        btnConfirmClose.setEnabled(false);
        btnConfirmClose.addActionListener(e -> handleConfirmResolution());

        JButton btnClose = new JButton("Close Window");
        btnClose.addActionListener(e -> dispose());

        footerPanel.add(btnViewHistory);
        footerPanel.add(btnConfirmClose);
        footerPanel.add(btnClose);
        add(footerPanel, BorderLayout.SOUTH);
    }

    private JLabel createFieldRow(JPanel parent, String labelText) {
        JPanel p = new JPanel(new BorderLayout(6, 0));
        p.setBackground(Color.WHITE);
        JLabel lbl = new JLabel(labelText);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        JLabel val = new JLabel("-");
        p.add(lbl, BorderLayout.WEST);
        p.add(val, BorderLayout.CENTER);
        parent.add(p);
        return val;
    }

    private void searchAndDisplayTicket(String ticketId) {
        Ticket ticket = ticketDAO.getTicketById(ticketId);
        if (ticket == null) {
            JOptionPane.showMessageDialog(this, "No ticket found with ID: " + ticketId);
            return;
        }
        this.currentTicket = ticket;
        valTicketId.setText(ticket.getTicketId());
        valStatus.setText(ticket.getStatus());
        valSubject.setText(ticket.getSubject());
        valCategory.setText(ticket.getCategory());
        valPriority.setText(ticket.getPriority());
        valTechnician.setText(ticket.getTechnicianName());
        valCreatedDate.setText(ticket.getCreatedAt() != null ? ticket.getCreatedAt().format(FMT) : "-");
        valUpdatedDate.setText(ticket.getUpdatedAt() != null ? ticket.getUpdatedAt().format(FMT) : "-");
        txtDescription.setText(ticket.getDescription());
        txtResolution.setText(ticket.getResolutionDetails() != null ? ticket.getResolutionDetails() : "Pending resolution.");

        updateVisualTracker(ticket.getStatus());
        btnViewHistory.setEnabled(true);
        btnConfirmClose.setEnabled("RESOLVED".equalsIgnoreCase(ticket.getStatus()));
    }

    private void updateVisualTracker(String currentStatus) {
        int currentIndex = -1;
        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            if (WORKFLOW_STEPS[i].equalsIgnoreCase(currentStatus)) {
                currentIndex = i;
                break;
            }
        }
        for (int i = 0; i < WORKFLOW_STEPS.length; i++) {
            if (i == currentIndex) {
                stepLabels[i].setBackground(ACCENT_COLOR);
                stepLabels[i].setForeground(Color.WHITE);
                stepLabels[i].setBorder(new LineBorder(PRIMARY_COLOR, 2));
            } else if (i < currentIndex) {
                stepLabels[i].setBackground(PRIMARY_COLOR);
                stepLabels[i].setForeground(Color.WHITE);
            } else {
                stepLabels[i].setBackground(new Color(229, 231, 235));
                stepLabels[i].setForeground(Color.DARK_GRAY);
            }
        }
    }

    private void handleConfirmResolution() {
        if (currentTicket == null) return;
        User user = SessionManager.getCurrentUser();
        if (user != null && ticketDAO.updateStatusAndPriority(currentTicket.getTicketId(), "CLOSED", currentTicket.getPriority(), user.getUserId(), "User confirmed resolution.")) {
            searchAndDisplayTicket(currentTicket.getTicketId());
        }
    }
}`,
  },
  {
    id: 'ticket_history_frame',
    path: 'src/ui/TicketHistoryFrame.java',
    phase: 'Phase 3',
    language: 'java',
    description: 'Chronological audit viewer for the ticket_history table with Ticket ID filter.',
    content: `package ui;

import dao.TicketHistoryDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.TicketHistory;

public class TicketHistoryFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketHistoryDAO historyDAO = new TicketHistoryDAO();
    private JTextField txtTicketIdFilter;
    private DefaultTableModel tableModel;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public TicketHistoryFrame(String initialTicketId) {
        setTitle("Ticket Audit History — IT Help Desk System");
        setSize(940, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents(initialTicketId);
        loadHistory(initialTicketId);
    }

    private void initComponents(String initialTicketId) {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Chronological Ticket Status History");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel centerContainer = new JPanel(new BorderLayout(10, 10));
        centerContainer.setBackground(BG_COLOR);
        centerContainer.setBorder(new EmptyBorder(10, 16, 14, 16));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        filterPanel.setBackground(Color.WHITE);
        filterPanel.add(new JLabel("Filter by Ticket ID:"));

        txtTicketIdFilter = new JTextField(initialTicketId != null ? initialTicketId : "", 16);
        filterPanel.add(txtTicketIdFilter);

        JButton btnSearch = new JButton("Filter History");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> loadHistory(txtTicketIdFilter.getText().trim()));
        filterPanel.add(btnSearch);

        JButton btnShowAll = new JButton("Show All Tickets");
        btnShowAll.setBackground(SECONDARY_COLOR);
        btnShowAll.setForeground(Color.WHITE);
        btnShowAll.addActionListener(e -> {
            txtTicketIdFilter.setText("");
            loadHistory("");
        });
        filterPanel.add(btnShowAll);

        centerContainer.add(filterPanel, BorderLayout.NORTH);

        String[] cols = {
                "History ID", "Ticket ID", "Previous Status", "New Status",
                "Changed By", "Change Description", "Changed At"
        };
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };

        JTable table = new JTable(tableModel);
        table.setRowHeight(28);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        centerContainer.add(new JScrollPane(table), BorderLayout.CENTER);
        add(centerContainer, BorderLayout.CENTER);
    }

    private void loadHistory(String ticketId) {
        tableModel.setRowCount(0);
        List<TicketHistory> list = (ticketId == null || ticketId.isBlank())
                ? historyDAO.getAllHistory()
                : historyDAO.getHistoryByTicketId(ticketId);

        for (TicketHistory h : list) {
            tableModel.addRow(new Object[]{
                    h.getHistoryId(),
                    h.getTicketId(),
                    h.getPreviousStatus() != null ? h.getPreviousStatus() : "NONE",
                    h.getNewStatus(),
                    h.getChangedByName(),
                    h.getChangeDescription(),
                    h.getChangedAt() != null ? h.getChangedAt().format(FMT) : ""
            });
        }
    }
}`,
  },
];
