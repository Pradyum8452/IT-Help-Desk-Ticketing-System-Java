export interface CodeFileEntry {
  id: string;
  path: string;
  phase: string;
  language: 'sql' | 'java' | 'text';
  description: string;
  content: string;
}

export const PHASE_1_FILES: CodeFileEntry[] = [
  {
    id: 'helpdesk_sql',
    path: 'database/helpdesk.sql',
    phase: 'Phase 1',
    language: 'sql',
    description: 'Complete MySQL 8+ schema, foreign key relationships, SHA-256 hashed credentials, and sample records.',
    content: `-- =====================================================================
-- PROJECT: IT Help Desk Ticketing and Service Management System
-- COURSE : TY EXTC Java Programming Micro Project (A.Y. 2026-2027)
-- DBMS   : MySQL 8.0+
-- FILE   : database/helpdesk.sql
-- =====================================================================

DROP DATABASE IF EXISTS helpdesk_db;
CREATE DATABASE helpdesk_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE helpdesk_db;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    department VARCHAR(80) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(64) NOT NULL,
    role ENUM('ADMIN', 'TECHNICIAN', 'USER') NOT NULL DEFAULT 'USER',
    status ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE technicians (
    technician_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    specialization ENUM('Hardware', 'Software', 'Network', 'Database', 'General Support') NOT NULL,
    status ENUM('ACTIVE', 'INACTIVE') NOT NULL DEFAULT 'ACTIVE',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_technician_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE tickets (
    ticket_id VARCHAR(20) PRIMARY KEY,
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category ENUM('Hardware', 'Software', 'Network', 'Printer', 'Email', 'Account/Login', 'Other') NOT NULL,
    priority ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
    status ENUM('OPEN', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED') NOT NULL DEFAULT 'OPEN',
    user_id INT NOT NULL,
    technician_id INT NULL,
    resolution_details TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at DATETIME NULL,
    CONSTRAINT fk_ticket_user
        FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    CONSTRAINT fk_ticket_technician
        FOREIGN KEY (technician_id) REFERENCES technicians(technician_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE ticket_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id VARCHAR(20) NOT NULL,
    previous_status VARCHAR(30) NULL,
    new_status ENUM('OPEN', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED') NOT NULL,
    changed_by INT NOT NULL,
    change_description TEXT NOT NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_history_ticket
        FOREIGN KEY (ticket_id) REFERENCES tickets(ticket_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT fk_history_user
        FOREIGN KEY (changed_by) REFERENCES users(user_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- SHA-256 Hashes:
-- Admin@123 -> e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7
-- Tech@123  -> ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99
-- User@123  -> 3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72

INSERT INTO users (user_id, name, email, phone, department, username, password, role, status, created_at) VALUES
(1, 'System Administrator', 'admin@helpdesk.com', '9876543210', 'IT Administration', 'admin',
    'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7', 'ADMIN', 'ACTIVE', '2026-09-01 09:00:00'),
(2, 'Rohan Deshmukh', 'technician@helpdesk.com', '9876543211', 'IT Infrastructure', 'technician',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-01 09:15:00'),
(3, 'Ananya Kulkarni', 'ananya.tech@helpdesk.com', '9876543212', 'IT Software Support', 'ananya_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-02 10:00:00'),
(4, 'Vikram Joshi', 'vikram.tech@helpdesk.com', '9876543213', 'Hardware & Peripherals', 'vikram_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'ACTIVE', '2026-09-02 11:00:00'),
(5, 'Suresh Nair', 'suresh.tech@helpdesk.com', '9876543214', 'Database Operations', 'suresh_tech',
    'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99', 'TECHNICIAN', 'INACTIVE', '2026-09-03 10:00:00'),
(6, 'Aarav Sharma', 'user@helpdesk.com', '9820112233', 'EXTC Engineering Lab', 'user',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-05 09:30:00'),
(7, 'Priya Patil', 'priya.patil@helpdesk.com', '9820112244', 'Accounts & Finance', 'priya_p',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-06 10:15:00'),
(8, 'Karan Mehta', 'karan.mehta@helpdesk.com', '9820112255', 'Human Resources', 'karan_m',
    '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72', 'USER', 'ACTIVE', '2026-09-07 14:20:00');

INSERT INTO technicians (technician_id, user_id, name, email, phone, specialization, status, created_at) VALUES
(1, 2, 'Rohan Deshmukh', 'technician@helpdesk.com', '9876543211', 'Network', 'ACTIVE', '2026-09-01 09:15:00'),
(2, 3, 'Ananya Kulkarni', 'ananya.tech@helpdesk.com', '9876543212', 'Software', 'ACTIVE', '2026-09-02 10:00:00'),
(3, 4, 'Vikram Joshi', 'vikram.tech@helpdesk.com', '9876543213', 'Hardware', 'ACTIVE', '2026-09-02 11:00:00'),
(4, 5, 'Suresh Nair', 'suresh.tech@helpdesk.com', '9876543214', 'Database', 'INACTIVE', '2026-09-03 10:00:00');

INSERT INTO tickets (ticket_id, subject, description, category, priority, status, user_id, technician_id, resolution_details, created_at, updated_at, resolved_at) VALUES
('HD-2026-0001', 'Lab Switch Port VLAN Connectivity Drop',
 'Workstations in EXTC Lab 3 cannot reach the internal license server on subnet 10.20.4.0/24 since morning reboot.',
 'Network', 'Critical', 'IN_PROGRESS', 6, 1, NULL, '2026-10-01 09:15:00', '2026-10-01 10:45:00', NULL),
('HD-2026-0002', 'MATLAB 2026a License Activation Error on Workstation 12',
 'Launching MATLAB displays Error -96: License Manager daemon unreachable after Windows security update.',
 'Software', 'High', 'ASSIGNED', 6, 2, NULL, '2026-10-02 11:20:00', '2026-10-02 12:00:00', NULL),
('HD-2026-0003', 'HP LaserJet Pro M404 Paper Jam & Toner Sensor Fault',
 'Department network printer shows persistent paper jam message even after clearing the rear duplex tray.',
 'Printer', 'Medium', 'OPEN', 7, NULL, NULL, '2026-10-03 14:10:00', '2026-10-03 14:10:00', NULL),
('HD-2026-0004', 'Outlook IMAP Sync Freezing on Large Attachments',
 'Corporate email client hangs whenever synchronizing attachments larger than 10 MB.',
 'Email', 'Low', 'RESOLVED', 6, 1,
 'Rebuilt local OST cache file, enabled cached Exchange mode with 6-month sync window, and verified TLS 1.3 port 993 settings.',
 '2026-09-28 10:00:00', '2026-09-29 16:30:00', '2026-09-29 16:30:00'),
('HD-2026-0005', 'SSD Boot Failure on Accounts Desktop PC-04',
 'System halts at BIOS splash screen with SMART status warning on primary NVMe drive.',
 'Hardware', 'Critical', 'CLOSED', 7, 3,
 'Replaced faulty 512GB NVMe SSD under warranty, restored disk image from nightly NAS backup, and verified user data integrity.',
 '2026-09-25 08:45:00', '2026-09-26 17:15:00', '2026-09-26 15:00:00'),
('HD-2026-0006', 'SSO Portal Password Reset & 2FA Token Lockout',
 'Unable to log into the employee self-service portal after changing mobile handset.',
 'Account/Login', 'High', 'OPEN', 8, NULL, NULL, '2026-10-04 08:30:00', '2026-10-04 08:30:00', NULL);

INSERT INTO ticket_history (ticket_id, previous_status, new_status, changed_by, change_description, changed_at) VALUES
('HD-2026-0001', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: Critical).', '2026-10-01 09:15:00'),
('HD-2026-0001', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Rohan Deshmukh (Network) by Admin.', '2026-10-01 09:40:00'),
('HD-2026-0001', 'ASSIGNED', 'IN_PROGRESS', 2, 'Technician Rohan Deshmukh accepted ticket and started VLAN trunk diagnostics.', '2026-10-01 10:45:00'),
('HD-2026-0002', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: High).', '2026-10-02 11:20:00'),
('HD-2026-0002', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Ananya Kulkarni (Software) by Admin.', '2026-10-02 12:00:00'),
('HD-2026-0003', NULL, 'OPEN', 7, 'Ticket created by user Priya Patil (Priority: Medium).', '2026-10-03 14:10:00'),
('HD-2026-0004', NULL, 'OPEN', 6, 'Ticket created by user Aarav Sharma (Priority: Low).', '2026-09-28 10:00:00'),
('HD-2026-0004', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Rohan Deshmukh by Admin.', '2026-09-28 11:15:00'),
('HD-2026-0004', 'ASSIGNED', 'IN_PROGRESS', 2, 'Technician started rebuilding Outlook profile.', '2026-09-29 11:00:00'),
('HD-2026-0004', 'IN_PROGRESS', 'RESOLVED', 2, 'Resolved: Rebuilt local OST cache file and verified TLS 1.3 settings.', '2026-09-29 16:30:00'),
('HD-2026-0005', NULL, 'OPEN', 7, 'Ticket created by user Priya Patil (Priority: Critical).', '2026-09-25 08:45:00'),
('HD-2026-0005', 'OPEN', 'ASSIGNED', 1, 'Ticket assigned to Technician Vikram Joshi (Hardware) by Admin.', '2026-09-25 09:05:00'),
('HD-2026-0005', 'ASSIGNED', 'IN_PROGRESS', 4, 'Technician diagnosed faulty NVMe drive and initiated replacement.', '2026-09-25 11:30:00'),
('HD-2026-0005', 'IN_PROGRESS', 'RESOLVED', 4, 'Resolved: Replaced NVMe SSD and restored backup image.', '2026-09-26 15:00:00'),
('HD-2026-0005', 'RESOLVED', 'CLOSED', 7, 'User confirmed resolution and closed ticket.', '2026-09-26 17:15:00'),
('HD-2026-0006', NULL, 'OPEN', 8, 'Ticket created by user Karan Mehta (Priority: High).', '2026-10-04 08:30:00');`,
  },
  {
    id: 'db_connection',
    path: 'src/database/DBConnection.java',
    phase: 'Phase 1',
    language: 'java',
    description: 'Centralized JDBC Connection Manager for MySQL 8+ with connection verification and safe resource closing.',
    content: `package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * DBConnection handles JDBC connectivity to the MySQL 8+ helpdesk_db database.
 * Demonstrates Centralized Connection Management and Resource Cleanup.
 */
public class DBConnection {

    private static final String DB_HOST = System.getenv().getOrDefault("DB_HOST", "localhost");
    private static final String DB_PORT = System.getenv().getOrDefault("DB_PORT", "3306");
    private static final String DB_NAME = System.getenv().getOrDefault("DB_NAME", "helpdesk_db");
    private static final String DB_USER = System.getenv().getOrDefault("DB_USER", "root");
    private static final String DB_PASSWORD = System.getenv().getOrDefault("DB_PASSWORD", "root");

    private static final String JDBC_URL = String.format(
            "jdbc:mysql://%s:%s/%s?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC",
            DB_HOST, DB_PORT, DB_NAME
    );

    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";

    static {
        try {
            Class.forName(JDBC_DRIVER);
        } catch (ClassNotFoundException e) {
            System.err.println("[DBConnection] CRITICAL ERROR: MySQL JDBC Driver not found in classpath.");
            System.err.println("Please add mysql-connector-j-8.x.x.jar to your project libraries.");
        }
    }

    private DBConnection() {
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, DB_USER, DB_PASSWORD);
    }

    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed();
        } catch (SQLException e) {
            System.err.println("[DBConnection] Connection test failed: " + e.getMessage());
            return false;
        }
    }

    public static void closeQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing Connection: " + e.getMessage());
            }
        }
    }

    public static void closeQuietly(PreparedStatement pstmt) {
        if (pstmt != null) {
            try {
                pstmt.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing PreparedStatement: " + e.getMessage());
            }
        }
    }

    public static void closeQuietly(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                System.err.println("[DBConnection] Error closing ResultSet: " + e.getMessage());
            }
        }
    }

    public static void closeQuietly(ResultSet rs, PreparedStatement pstmt, Connection conn) {
        closeQuietly(rs);
        closeQuietly(pstmt);
        closeQuietly(conn);
    }
}`,
  },
  {
    id: 'model_user',
    path: 'src/model/User.java',
    phase: 'Phase 1',
    language: 'java',
    description: 'User entity POJO with constructor overloading, role checks, and encapsulated fields.',
    content: `package model;

import java.time.LocalDateTime;

/**
 * User model class representing a system user (ADMIN, TECHNICIAN, or USER).
 */
public class User {

    private int userId;
    private String name;
    private String email;
    private String phone;
    private String department;
    private String username;
    private String password; // Stores SHA-256 hashed password
    private String role;     // ADMIN, TECHNICIAN, USER
    private String status;   // ACTIVE, INACTIVE
    private LocalDateTime createdAt;

    public User() {
        this.role = "USER";
        this.status = "ACTIVE";
        this.createdAt = LocalDateTime.now();
    }

    public User(String name, String email, String phone, String department,
                String username, String password, String role, String status) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.username = username;
        this.password = password;
        this.role = role;
        this.status = status;
        this.createdAt = LocalDateTime.now();
    }

    public User(int userId, String name, String email, String phone, String department,
                String username, String password, String role, String status, LocalDateTime createdAt) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.username = username;
        this.password = password;
        this.role = role;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isAdmin() { return "ADMIN".equalsIgnoreCase(this.role); }
    public boolean isTechnician() { return "TECHNICIAN".equalsIgnoreCase(this.role); }
    public boolean isRegularUser() { return "USER".equalsIgnoreCase(this.role); }
    public boolean isActive() { return "ACTIVE".equalsIgnoreCase(this.status); }

    @Override
    public String toString() {
        return String.format("%s (%s - %s)", name, username, role);
    }
}`,
  },
  {
    id: 'model_technician',
    path: 'src/model/Technician.java',
    phase: 'Phase 1',
    language: 'java',
    description: 'Technician entity POJO with specialization and active status checks.',
    content: `package model;

import java.time.LocalDateTime;

/**
 * Technician model class representing an IT support specialist.
 */
public class Technician {

    private int technicianId;
    private Integer userId;
    private String name;
    private String email;
    private String phone;
    private String specialization;
    private String status;
    private LocalDateTime createdAt;

    public Technician() {
        this.specialization = "General Support";
        this.status = "ACTIVE";
        this.createdAt = LocalDateTime.now();
    }

    public Technician(Integer userId, String name, String email, String phone,
                      String specialization, String status) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.specialization = specialization;
        this.status = status;
        this.createdAt = LocalDateTime.now();
    }

    public Technician(int technicianId, Integer userId, String name, String email,
                      String phone, String specialization, String status, LocalDateTime createdAt) {
        this.technicianId = technicianId;
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.specialization = specialization;
        this.status = status;
        this.createdAt = createdAt;
    }

    public int getTechnicianId() { return technicianId; }
    public void setTechnicianId(int technicianId) { this.technicianId = technicianId; }

    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isActive() { return "ACTIVE".equalsIgnoreCase(this.status); }

    @Override
    public String toString() {
        return String.format("Tech #%d - %s [%s] (%s)", technicianId, name, specialization, status);
    }
}`,
  },
  {
    id: 'model_ticket',
    path: 'src/model/Ticket.java',
    phase: 'Phase 1',
    language: 'java',
    description: 'Ticket entity POJO representing a support ticket with workflow statuses and joined metadata.',
    content: `package model;

import java.time.LocalDateTime;

/**
 * Ticket model class representing a technical support request.
 */
public class Ticket {

    private String ticketId;
    private String subject;
    private String description;
    private String category;
    private String priority;
    private String status;
    private int userId;
    private Integer technicianId;
    private String resolutionDetails;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private LocalDateTime resolvedAt;

    private String userName;
    private String userEmail;
    private String technicianName;
    private String technicianSpecialization;

    public Ticket() {
        this.status = "OPEN";
        this.priority = "Medium";
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public Ticket(String ticketId, String subject, String description,
                  String category, String priority, int userId) {
        this.ticketId = ticketId;
        this.subject = subject;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = "OPEN";
        this.userId = userId;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public Ticket(String ticketId, String subject, String description, String category,
                  String priority, String status, int userId, Integer technicianId,
                  String resolutionDetails, LocalDateTime createdAt,
                  LocalDateTime updatedAt, LocalDateTime resolvedAt) {
        this.ticketId = ticketId;
        this.subject = subject;
        this.description = description;
        this.category = category;
        this.priority = priority;
        this.status = status;
        this.userId = userId;
        this.technicianId = technicianId;
        this.resolutionDetails = resolutionDetails;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
        this.resolvedAt = resolvedAt;
    }

    public String getTicketId() { return ticketId; }
    public void setTicketId(String ticketId) { this.ticketId = ticketId; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public Integer getTechnicianId() { return technicianId; }
    public void setTechnicianId(Integer technicianId) { this.technicianId = technicianId; }

    public String getResolutionDetails() { return resolutionDetails; }
    public void setResolutionDetails(String resolutionDetails) { this.resolutionDetails = resolutionDetails; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }

    public LocalDateTime getResolvedAt() { return resolvedAt; }
    public void setResolvedAt(LocalDateTime resolvedAt) { this.resolvedAt = resolvedAt; }

    public String getUserName() { return userName != null ? userName : "User #" + userId; }
    public void setUserName(String userName) { this.userName = userName; }

    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }

    public String getTechnicianName() {
        return (technicianName != null && !technicianName.isBlank()) ? technicianName : "Unassigned";
    }
    public void setTechnicianName(String technicianName) { this.technicianName = technicianName; }

    public String getTechnicianSpecialization() { return technicianSpecialization; }
    public void setTechnicianSpecialization(String technicianSpecialization) {
        this.technicianSpecialization = technicianSpecialization;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s (%s - %s)", ticketId, subject, priority, status);
    }
}`,
  },
  {
    id: 'model_ticket_history',
    path: 'src/model/TicketHistory.java',
    phase: 'Phase 1',
    language: 'java',
    description: 'TicketHistory entity POJO representing chronological status audit records.',
    content: `package model;

import java.time.LocalDateTime;

/**
 * TicketHistory model class representing an audit log entry in the ticket_history table.
 */
public class TicketHistory {

    private int historyId;
    private String ticketId;
    private String previousStatus;
    private String newStatus;
    private int changedBy;
    private String changeDescription;
    private LocalDateTime changedAt;

    private String changedByName;
    private String changedByRole;

    public TicketHistory() {
        this.changedAt = LocalDateTime.now();
    }

    public TicketHistory(String ticketId, String previousStatus, String newStatus,
                         int changedBy, String changeDescription) {
        this.ticketId = ticketId;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.changedBy = changedBy;
        this.changeDescription = changeDescription;
        this.changedAt = LocalDateTime.now();
    }

    public TicketHistory(int historyId, String ticketId, String previousStatus,
                         String newStatus, int changedBy, String changeDescription,
                         LocalDateTime changedAt) {
        this.historyId = historyId;
        this.ticketId = ticketId;
        this.previousStatus = previousStatus;
        this.newStatus = newStatus;
        this.changedBy = changedBy;
        this.changeDescription = changeDescription;
        this.changedAt = changedAt;
    }

    public int getHistoryId() { return historyId; }
    public void setHistoryId(int historyId) { this.historyId = historyId; }

    public String getTicketId() { return ticketId; }
    public void setTicketId(String ticketId) { this.ticketId = ticketId; }

    public String getPreviousStatus() { return previousStatus; }
    public void setPreviousStatus(String previousStatus) { this.previousStatus = previousStatus; }

    public String getNewStatus() { return newStatus; }
    public void setNewStatus(String newStatus) { this.newStatus = newStatus; }

    public int getChangedBy() { return changedBy; }
    public void setChangedBy(int changedBy) { this.changedBy = changedBy; }

    public String getChangeDescription() { return changeDescription; }
    public void setChangeDescription(String changeDescription) { this.changeDescription = changeDescription; }

    public LocalDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(LocalDateTime changedAt) { this.changedAt = changedAt; }

    public String getChangedByName() {
        return (changedByName != null && !changedByName.isBlank()) ? changedByName : "User #" + changedBy;
    }
    public void setChangedByName(String changedByName) { this.changedByName = changedByName; }

    public String getChangedByRole() { return changedByRole != null ? changedByRole : ""; }
    public void setChangedByRole(String changedByRole) { this.changedByRole = changedByRole; }

    @Override
    public String toString() {
        return String.format("[%s] %s -> %s by %s: %s",
                ticketId,
                previousStatus != null ? previousStatus : "NONE",
                newStatus,
                getChangedByName(),
                changeDescription);
    }
}`,
  },
];
