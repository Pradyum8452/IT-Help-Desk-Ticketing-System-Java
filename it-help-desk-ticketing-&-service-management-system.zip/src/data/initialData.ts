export type Role = 'ADMIN' | 'TECHNICIAN' | 'USER';
export type AccountStatus = 'ACTIVE' | 'INACTIVE';
export type TicketCategory = 'Hardware' | 'Software' | 'Network' | 'Printer' | 'Email' | 'Account/Login' | 'Other';
export type TicketPriority = 'Low' | 'Medium' | 'High' | 'Critical';
export type TicketStatus = 'OPEN' | 'ASSIGNED' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';
export type Specialization = 'Hardware' | 'Software' | 'Network' | 'Database' | 'General Support';

export interface UserModel {
  userId: number;
  name: string;
  email: string;
  phone: string;
  department: string;
  username: string;
  passwordHash: string;
  plainHint?: string;
  role: Role;
  status: AccountStatus;
  createdAt: string;
}

export interface TechnicianModel {
  technicianId: number;
  userId: number | null;
  name: string;
  email: string;
  phone: string;
  specialization: Specialization;
  status: AccountStatus;
  createdAt: string;
}

export interface TicketModel {
  ticketId: string;
  subject: string;
  description: string;
  category: TicketCategory;
  priority: TicketPriority;
  status: TicketStatus;
  userId: number;
  technicianId: number | null;
  resolutionDetails: string | null;
  createdAt: string;
  updatedAt: string;
  resolvedAt: string | null;
}

export interface TicketHistoryModel {
  historyId: number;
  ticketId: string;
  previousStatus: TicketStatus | null;
  newStatus: TicketStatus;
  changedBy: number;
  changeDescription: string;
  changedAt: string;
}

export async function sha256Hex(plain: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(plain);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map((b) => b.toString(16).padStart(2, '0')).join('');
}

export const INITIAL_USERS: UserModel[] = [
  {
    userId: 1,
    name: 'System Administrator',
    email: 'admin@helpdesk.com',
    phone: '9876543210',
    department: 'IT Administration',
    username: 'admin',
    passwordHash: 'e86f78a8a3caf0b60d8e74e5942aa6d86dc150cd3c03338aef25b7d2d7e3acc7',
    plainHint: 'Admin@123',
    role: 'ADMIN',
    status: 'ACTIVE',
    createdAt: '2026-09-01 09:00:00',
  },
  {
    userId: 2,
    name: 'Rohan Deshmukh',
    email: 'technician@helpdesk.com',
    phone: '9876543211',
    department: 'IT Infrastructure',
    username: 'technician',
    passwordHash: 'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99',
    plainHint: 'Tech@123',
    role: 'TECHNICIAN',
    status: 'ACTIVE',
    createdAt: '2026-09-01 09:15:00',
  },
  {
    userId: 3,
    name: 'Ananya Kulkarni',
    email: 'ananya.tech@helpdesk.com',
    phone: '9876543212',
    department: 'IT Software Support',
    username: 'ananya_tech',
    passwordHash: 'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99',
    plainHint: 'Tech@123',
    role: 'TECHNICIAN',
    status: 'ACTIVE',
    createdAt: '2026-09-02 10:00:00',
  },
  {
    userId: 4,
    name: 'Vikram Joshi',
    email: 'vikram.tech@helpdesk.com',
    phone: '9876543213',
    department: 'Hardware & Peripherals',
    username: 'vikram_tech',
    passwordHash: 'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99',
    plainHint: 'Tech@123',
    role: 'TECHNICIAN',
    status: 'ACTIVE',
    createdAt: '2026-09-02 11:00:00',
  },
  {
    userId: 5,
    name: 'Suresh Nair',
    email: 'suresh.tech@helpdesk.com',
    phone: '9876543214',
    department: 'Database Operations',
    username: 'suresh_tech',
    passwordHash: 'ab38322f1e4ca606045224e90fd3033f8e590bf15917adefdaddf7890ca03d99',
    plainHint: 'Tech@123',
    role: 'TECHNICIAN',
    status: 'INACTIVE',
    createdAt: '2026-09-03 10:00:00',
  },
  {
    userId: 6,
    name: 'Aarav Sharma',
    email: 'user@helpdesk.com',
    phone: '9820112233',
    department: 'EXTC Engineering Lab',
    username: 'user',
    passwordHash: '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72',
    plainHint: 'User@123',
    role: 'USER',
    status: 'ACTIVE',
    createdAt: '2026-09-05 09:30:00',
  },
  {
    userId: 7,
    name: 'Priya Patil',
    email: 'priya.patil@helpdesk.com',
    phone: '9820112244',
    department: 'Accounts & Finance',
    username: 'priya_p',
    passwordHash: '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72',
    plainHint: 'User@123',
    role: 'USER',
    status: 'ACTIVE',
    createdAt: '2026-09-06 10:15:00',
  },
  {
    userId: 8,
    name: 'Karan Mehta',
    email: 'karan.mehta@helpdesk.com',
    phone: '9820112255',
    department: 'Human Resources',
    username: 'karan_m',
    passwordHash: '3e7c19576488862816f13b512cacf3e4ba97dd97243ea0bd6a2ad1642d86ba72',
    plainHint: 'User@123',
    role: 'USER',
    status: 'ACTIVE',
    createdAt: '2026-09-07 14:20:00',
  },
];

export const INITIAL_TECHNICIANS: TechnicianModel[] = [
  {
    technicianId: 1,
    userId: 2,
    name: 'Rohan Deshmukh',
    email: 'technician@helpdesk.com',
    phone: '9876543211',
    specialization: 'Network',
    status: 'ACTIVE',
    createdAt: '2026-09-01 09:15:00',
  },
  {
    technicianId: 2,
    userId: 3,
    name: 'Ananya Kulkarni',
    email: 'ananya.tech@helpdesk.com',
    phone: '9876543212',
    specialization: 'Software',
    status: 'ACTIVE',
    createdAt: '2026-09-02 10:00:00',
  },
  {
    technicianId: 3,
    userId: 4,
    name: 'Vikram Joshi',
    email: 'vikram.tech@helpdesk.com',
    phone: '9876543213',
    specialization: 'Hardware',
    status: 'ACTIVE',
    createdAt: '2026-09-02 11:00:00',
  },
  {
    technicianId: 4,
    userId: 5,
    name: 'Suresh Nair',
    email: 'suresh.tech@helpdesk.com',
    phone: '9876543214',
    specialization: 'Database',
    status: 'INACTIVE',
    createdAt: '2026-09-03 10:00:00',
  },
];

export const INITIAL_TICKETS: TicketModel[] = [
  {
    ticketId: 'HD-2026-0001',
    subject: 'Lab Switch Port VLAN Connectivity Drop',
    description: 'Workstations in EXTC Lab 3 cannot reach the internal license server on subnet 10.20.4.0/24 since morning reboot.',
    category: 'Network',
    priority: 'Critical',
    status: 'IN_PROGRESS',
    userId: 6,
    technicianId: 1,
    resolutionDetails: null,
    createdAt: '2026-10-01 09:15:00',
    updatedAt: '2026-10-01 10:45:00',
    resolvedAt: null,
  },
  {
    ticketId: 'HD-2026-0002',
    subject: 'MATLAB 2026a License Activation Error on Workstation 12',
    description: 'Launching MATLAB displays Error -96: License Manager daemon unreachable after Windows security update.',
    category: 'Software',
    priority: 'High',
    status: 'ASSIGNED',
    userId: 6,
    technicianId: 2,
    resolutionDetails: null,
    createdAt: '2026-10-02 11:20:00',
    updatedAt: '2026-10-02 12:00:00',
    resolvedAt: null,
  },
  {
    ticketId: 'HD-2026-0003',
    subject: 'HP LaserJet Pro M404 Paper Jam & Toner Sensor Fault',
    description: 'Department network printer shows persistent paper jam message even after clearing the rear duplex tray.',
    category: 'Printer',
    priority: 'Medium',
    status: 'OPEN',
    userId: 7,
    technicianId: null,
    resolutionDetails: null,
    createdAt: '2026-10-03 14:10:00',
    updatedAt: '2026-10-03 14:10:00',
    resolvedAt: null,
  },
  {
    ticketId: 'HD-2026-0004',
    subject: 'Outlook IMAP Sync Freezing on Large Attachments',
    description: 'Corporate email client hangs whenever synchronizing attachments larger than 10 MB.',
    category: 'Email',
    priority: 'Low',
    status: 'RESOLVED',
    userId: 6,
    technicianId: 1,
    resolutionDetails: 'Rebuilt local OST cache file, enabled cached Exchange mode with 6-month sync window, and verified TLS 1.3 port 993 settings.',
    createdAt: '2026-09-28 10:00:00',
    updatedAt: '2026-09-29 16:30:00',
    resolvedAt: '2026-09-29 16:30:00',
  },
  {
    ticketId: 'HD-2026-0005',
    subject: 'SSD Boot Failure on Accounts Desktop PC-04',
    description: 'System halts at BIOS splash screen with SMART status warning on primary NVMe drive.',
    category: 'Hardware',
    priority: 'Critical',
    status: 'CLOSED',
    userId: 7,
    technicianId: 3,
    resolutionDetails: 'Replaced faulty 512GB NVMe SSD under warranty, restored disk image from nightly NAS backup, and verified user data integrity.',
    createdAt: '2026-09-25 08:45:00',
    updatedAt: '2026-09-26 17:15:00',
    resolvedAt: '2026-09-26 15:00:00',
  },
  {
    ticketId: 'HD-2026-0006',
    subject: 'SSO Portal Password Reset & 2FA Token Lockout',
    description: 'Unable to log into the employee self-service portal after changing mobile handset.',
    category: 'Account/Login',
    priority: 'High',
    status: 'OPEN',
    userId: 8,
    technicianId: null,
    resolutionDetails: null,
    createdAt: '2026-10-04 08:30:00',
    updatedAt: '2026-10-04 08:30:00',
    resolvedAt: null,
  },
];

export const INITIAL_HISTORY: TicketHistoryModel[] = [
  {
    historyId: 1,
    ticketId: 'HD-2026-0001',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 6,
    changeDescription: 'Ticket created by user Aarav Sharma (Priority: Critical).',
    changedAt: '2026-10-01 09:15:00',
  },
  {
    historyId: 2,
    ticketId: 'HD-2026-0001',
    previousStatus: 'OPEN',
    newStatus: 'ASSIGNED',
    changedBy: 1,
    changeDescription: 'Ticket assigned to Technician Rohan Deshmukh (Network) by Admin.',
    changedAt: '2026-10-01 09:40:00',
  },
  {
    historyId: 3,
    ticketId: 'HD-2026-0001',
    previousStatus: 'ASSIGNED',
    newStatus: 'IN_PROGRESS',
    changedBy: 2,
    changeDescription: 'Technician Rohan Deshmukh accepted ticket and started VLAN trunk diagnostics.',
    changedAt: '2026-10-01 10:45:00',
  },
  {
    historyId: 4,
    ticketId: 'HD-2026-0002',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 6,
    changeDescription: 'Ticket created by user Aarav Sharma (Priority: High).',
    changedAt: '2026-10-02 11:20:00',
  },
  {
    historyId: 5,
    ticketId: 'HD-2026-0002',
    previousStatus: 'OPEN',
    newStatus: 'ASSIGNED',
    changedBy: 1,
    changeDescription: 'Ticket assigned to Technician Ananya Kulkarni (Software) by Admin.',
    changedAt: '2026-10-02 12:00:00',
  },
  {
    historyId: 6,
    ticketId: 'HD-2026-0003',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 7,
    changeDescription: 'Ticket created by user Priya Patil (Priority: Medium).',
    changedAt: '2026-10-03 14:10:00',
  },
  {
    historyId: 7,
    ticketId: 'HD-2026-0004',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 6,
    changeDescription: 'Ticket created by user Aarav Sharma (Priority: Low).',
    changedAt: '2026-09-28 10:00:00',
  },
  {
    historyId: 8,
    ticketId: 'HD-2026-0004',
    previousStatus: 'OPEN',
    newStatus: 'ASSIGNED',
    changedBy: 1,
    changeDescription: 'Ticket assigned to Technician Rohan Deshmukh by Admin.',
    changedAt: '2026-09-28 11:15:00',
  },
  {
    historyId: 9,
    ticketId: 'HD-2026-0004',
    previousStatus: 'ASSIGNED',
    newStatus: 'IN_PROGRESS',
    changedBy: 2,
    changeDescription: 'Technician started rebuilding Outlook profile.',
    changedAt: '2026-09-29 11:00:00',
  },
  {
    historyId: 10,
    ticketId: 'HD-2026-0004',
    previousStatus: 'IN_PROGRESS',
    newStatus: 'RESOLVED',
    changedBy: 2,
    changeDescription: 'Resolved: Rebuilt local OST cache file and verified TLS 1.3 settings.',
    changedAt: '2026-09-29 16:30:00',
  },
  {
    historyId: 11,
    ticketId: 'HD-2026-0005',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 7,
    changeDescription: 'Ticket created by user Priya Patil (Priority: Critical).',
    changedAt: '2026-09-25 08:45:00',
  },
  {
    historyId: 12,
    ticketId: 'HD-2026-0005',
    previousStatus: 'OPEN',
    newStatus: 'ASSIGNED',
    changedBy: 1,
    changeDescription: 'Ticket assigned to Technician Vikram Joshi (Hardware) by Admin.',
    changedAt: '2026-09-25 09:05:00',
  },
  {
    historyId: 13,
    ticketId: 'HD-2026-0005',
    previousStatus: 'ASSIGNED',
    newStatus: 'IN_PROGRESS',
    changedBy: 4,
    changeDescription: 'Technician diagnosed faulty NVMe drive and initiated replacement.',
    changedAt: '2026-09-25 11:30:00',
  },
  {
    historyId: 14,
    ticketId: 'HD-2026-0005',
    previousStatus: 'IN_PROGRESS',
    newStatus: 'RESOLVED',
    changedBy: 4,
    changeDescription: 'Resolved: Replaced NVMe SSD and restored backup image.',
    changedAt: '2026-09-26 15:00:00',
  },
  {
    historyId: 15,
    ticketId: 'HD-2026-0005',
    previousStatus: 'RESOLVED',
    newStatus: 'CLOSED',
    changedBy: 7,
    changeDescription: 'User confirmed resolution and closed ticket.',
    changedAt: '2026-09-26 17:15:00',
  },
  {
    historyId: 16,
    ticketId: 'HD-2026-0006',
    previousStatus: null,
    newStatus: 'OPEN',
    changedBy: 8,
    changeDescription: 'Ticket created by user Karan Mehta (Priority: High).',
    changedAt: '2026-10-04 08:30:00',
  },
];
