import { CodeFileEntry } from './phase1Files';

export const PHASE_2_FILES: CodeFileEntry[] = [
  {
    id: 'password_util',
    path: 'src/utils/PasswordUtil.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'SHA-256 password hashing (MessageDigest), password verification, and email/phone regex validators.',
    content: `package utils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

/**
 * PasswordUtil provides SHA-256 password hashing and input validation methods
 * for emails, phone numbers, and password strength.
 */
public class PasswordUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\\\.[A-Za-z]{2,}$");

    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[0-9]{10}$");

    private PasswordUtil() {
    }

    public static String hashPassword(String plainPassword) {
        if (plainPassword == null) {
            return "";
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedHash = digest.digest(plainPassword.getBytes(StandardCharsets.UTF_8));
            StringBuilder hexString = new StringBuilder(2 * encodedHash.length);
            for (byte b : encodedHash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) {
                    hexString.append('0');
                }
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available in JVM", e);
        }
    }

    public static boolean verifyPassword(String plainPassword, String storedHash) {
        if (plainPassword == null || storedHash == null) {
            return false;
        }
        String computedHash = hashPassword(plainPassword);
        return computedHash.equalsIgnoreCase(storedHash.trim());
    }

    public static boolean isValidEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email.trim()).matches();
    }

    public static boolean isValidPhone(String phone) {
        return phone != null && PHONE_PATTERN.matcher(phone.trim()).matches();
    }

    public static boolean isValidPassword(String password) {
        return password != null && password.trim().length() >= 6;
    }
}`,
  },
  {
    id: 'ticket_id_generator',
    path: 'src/utils/TicketIDGenerator.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'Queries MySQL tickets table and generates the next sequential Ticket ID (e.g., HD-2026-0007).',
    content: `package utils;

import database.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Year;

/**
 * TicketIDGenerator automatically generates unique sequential Ticket IDs
 * in the format HD-YYYY-XXXX (e.g., HD-2026-0001).
 */
public class TicketIDGenerator {

    private static final String PREFIX = "HD";

    private TicketIDGenerator() {
    }

    public static String generateNextTicketId() {
        int currentYear = Year.now().getValue();
        String yearPrefix = String.format("%s-%d-", PREFIX, currentYear);
        String sql = "SELECT ticket_id FROM tickets WHERE ticket_id LIKE ? ORDER BY ticket_id DESC LIMIT 1";

        int nextSequence = 1;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, yearPrefix + "%");
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String lastId = rs.getString("ticket_id");
                    String[] parts = lastId.split("-");
                    if (parts.length == 3) {
                        nextSequence = Integer.parseInt(parts[2]) + 1;
                    }
                }
            }
        } catch (SQLException | NumberFormatException e) {
            System.err.println("[TicketIDGenerator] Fallback ID generation: " + e.getMessage());
            nextSequence = (int) (System.currentTimeMillis() % 9000) + 1000;
        }

        return String.format("%s-%d-%04d", PREFIX, currentYear, nextSequence);
    }
}`,
  },
  {
    id: 'session_manager',
    path: 'src/utils/SessionManager.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'Stores the currently logged-in User and Technician session for role-based Swing UI routing.',
    content: `package utils;

import model.Technician;
import model.User;

/**
 * SessionManager maintains the currently authenticated User and Technician
 * across Swing frames and enforces role-based access checks.
 */
public class SessionManager {

    private static User currentUser;
    private static Technician currentTechnician;

    private SessionManager() {
    }

    public static void login(User user, Technician technician) {
        currentUser = user;
        currentTechnician = technician;
    }

    public static void logout() {
        currentUser = null;
        currentTechnician = null;
    }

    public static User getCurrentUser() { return currentUser; }
    public static Technician getCurrentTechnician() { return currentTechnician; }
    public static boolean isLoggedIn() { return currentUser != null; }
    public static boolean isAdmin() { return currentUser != null && currentUser.isAdmin(); }
    public static boolean isTechnician() { return currentUser != null && currentUser.isTechnician(); }
    public static boolean isRegularUser() { return currentUser != null && currentUser.isRegularUser(); }
}`,
  },
  {
    id: 'user_dao',
    path: 'src/dao/UserDAO.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'JDBC DAO for user authentication, duplicate checks, search, and full CRUD on the users table.',
    content: `package dao;

import database.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.User;
import utils.PasswordUtil;

public class UserDAO {

    public User authenticate(String identifier, String plainPassword) throws SQLException {
        String sql = "SELECT * FROM users WHERE (email = ? OR username = ?) LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, identifier.trim());
            pstmt.setString(2, identifier.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String storedHash = rs.getString("password");
                    if (PasswordUtil.verifyPassword(plainPassword, storedHash)) {
                        return mapResultSetToUser(rs);
                    }
                }
            }
        }
        return null;
    }

    public User findByEmailOrUsername(String identifier) throws SQLException {
        String sql = "SELECT * FROM users WHERE email = ? OR username = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, identifier.trim());
            pstmt.setString(2, identifier.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToUser(rs);
                }
            }
        }
        return null;
    }

    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY user_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToUser(rs));
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error fetching users: " + e.getMessage());
        }
        return list;
    }

    public List<User> searchUsers(String keyword) {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users WHERE name LIKE ? OR email LIKE ? OR username LIKE ? OR department LIKE ? ORDER BY user_id ASC";
        String pattern = "%" + keyword.trim() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            pstmt.setString(4, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToUser(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error searching users: " + e.getMessage());
        }
        return list;
    }

    public boolean isEmailTaken(String email, int excludeUserId) {
        String sql = "SELECT COUNT(*) FROM users WHERE email = ? AND user_id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, email.trim());
            pstmt.setInt(2, excludeUserId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Email check error: " + e.getMessage());
        }
        return false;
    }

    public boolean isUsernameTaken(String username, int excludeUserId) {
        String sql = "SELECT COUNT(*) FROM users WHERE username = ? AND user_id != ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username.trim());
            pstmt.setInt(2, excludeUserId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] Username check error: " + e.getMessage());
        }
        return false;
    }

    public boolean addUser(User user) {
        String sql = "INSERT INTO users (name, email, phone, department, username, password, role, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getName().trim());
            pstmt.setString(2, user.getEmail().trim());
            pstmt.setString(3, user.getPhone().trim());
            pstmt.setString(4, user.getDepartment().trim());
            pstmt.setString(5, user.getUsername().trim());
            String pwd = user.getPassword();
            if (pwd != null && pwd.length() != 64) {
                pwd = PasswordUtil.hashPassword(pwd);
            }
            pstmt.setString(6, pwd);
            pstmt.setString(7, user.getRole());
            pstmt.setString(8, user.getStatus());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error adding user: " + e.getMessage());
            return false;
        }
    }

    public boolean updateUser(User user, String newPlainPassword) {
        boolean updatePassword = newPlainPassword != null && !newPlainPassword.isBlank();
        String sql = updatePassword
                ? "UPDATE users SET name = ?, email = ?, phone = ?, department = ?, username = ?, password = ?, role = ?, status = ? WHERE user_id = ?"
                : "UPDATE users SET name = ?, email = ?, phone = ?, department = ?, username = ?, role = ?, status = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, user.getName().trim());
            pstmt.setString(2, user.getEmail().trim());
            pstmt.setString(3, user.getPhone().trim());
            pstmt.setString(4, user.getDepartment().trim());
            pstmt.setString(5, user.getUsername().trim());
            if (updatePassword) {
                pstmt.setString(6, PasswordUtil.hashPassword(newPlainPassword.trim()));
                pstmt.setString(7, user.getRole());
                pstmt.setString(8, user.getStatus());
                pstmt.setInt(9, user.getUserId());
            } else {
                pstmt.setString(6, user.getRole());
                pstmt.setString(7, user.getStatus());
                pstmt.setInt(8, user.getUserId());
            }
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error updating user: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteUser(int userId) {
        String sql = "DELETE FROM users WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[UserDAO] Cannot delete user: " + e.getMessage());
            return false;
        }
    }

    public int getTotalUserCount() {
        String sql = "SELECT COUNT(*) FROM users";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[UserDAO] Error counting users: " + e.getMessage());
        }
        return 0;
    }

    private User mapResultSetToUser(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime createdAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new User(
                rs.getInt("user_id"),
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getString("department"),
                rs.getString("username"),
                rs.getString("password"),
                rs.getString("role"),
                rs.getString("status"),
                createdAt
        );
    }
}`,
  },
  {
    id: 'technician_dao',
    path: 'src/dao/TechnicianDAO.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'JDBC DAO for Technician CRUD, active technician filtering, and status activation/deactivation.',
    content: `package dao;

import database.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.Technician;

public class TechnicianDAO {

    public List<Technician> getAllTechnicians() {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians ORDER BY technician_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToTechnician(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error fetching technicians: " + e.getMessage());
        }
        return list;
    }

    public List<Technician> getActiveTechnicians() {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians WHERE status = 'ACTIVE' ORDER BY name ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToTechnician(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error fetching active technicians: " + e.getMessage());
        }
        return list;
    }

    public Technician getTechnicianByUser(int userId, String email) {
        String sql = "SELECT * FROM technicians WHERE user_id = ? OR email = ? LIMIT 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapResultSetToTechnician(rs);
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error finding technician by user: " + e.getMessage());
        }
        return null;
    }

    public Technician getTechnicianById(int technicianId) {
        String sql = "SELECT * FROM technicians WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, technicianId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapResultSetToTechnician(rs);
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error finding technician by ID: " + e.getMessage());
        }
        return null;
    }

    public List<Technician> searchTechnicians(String keyword) {
        List<Technician> list = new ArrayList<>();
        String sql = "SELECT * FROM technicians WHERE name LIKE ? OR email LIKE ? OR specialization LIKE ? ORDER BY technician_id ASC";
        String pattern = "%" + keyword.trim() + "%";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, pattern);
            pstmt.setString(2, pattern);
            pstmt.setString(3, pattern);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToTechnician(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error searching technicians: " + e.getMessage());
        }
        return list;
    }

    public boolean addTechnician(Technician tech) {
        String sql = "INSERT INTO technicians (user_id, name, email, phone, specialization, status) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (tech.getUserId() != null && tech.getUserId() > 0) {
                pstmt.setInt(1, tech.getUserId());
            } else {
                pstmt.setNull(1, Types.INTEGER);
            }
            pstmt.setString(2, tech.getName().trim());
            pstmt.setString(3, tech.getEmail().trim());
            pstmt.setString(4, tech.getPhone().trim());
            pstmt.setString(5, tech.getSpecialization());
            pstmt.setString(6, tech.getStatus());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error adding technician: " + e.getMessage());
            return false;
        }
    }

    public boolean updateTechnician(Technician tech) {
        String sql = "UPDATE technicians SET name = ?, email = ?, phone = ?, specialization = ?, status = ? WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, tech.getName().trim());
            pstmt.setString(2, tech.getEmail().trim());
            pstmt.setString(3, tech.getPhone().trim());
            pstmt.setString(4, tech.getSpecialization());
            pstmt.setString(5, tech.getStatus());
            pstmt.setInt(6, tech.getTechnicianId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error updating technician: " + e.getMessage());
            return false;
        }
    }

    public boolean updateTechnicianStatus(int technicianId, String newStatus) {
        String sql = "UPDATE technicians SET status = ? WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, technicianId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error updating status: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteTechnician(int technicianId) {
        String sql = "DELETE FROM technicians WHERE technician_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, technicianId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error deleting technician: " + e.getMessage());
            return false;
        }
    }

    public int getTotalTechnicianCount() {
        String sql = "SELECT COUNT(*) FROM technicians";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("[TechnicianDAO] Error counting technicians: " + e.getMessage());
        }
        return 0;
    }

    private Technician mapResultSetToTechnician(ResultSet rs) throws SQLException {
        int rawUserId = rs.getInt("user_id");
        Integer userId = rs.wasNull() ? null : rawUserId;
        Timestamp ts = rs.getTimestamp("created_at");
        LocalDateTime createdAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        return new Technician(
                rs.getInt("technician_id"),
                userId,
                rs.getString("name"),
                rs.getString("email"),
                rs.getString("phone"),
                rs.getString("specialization"),
                rs.getString("status"),
                createdAt
        );
    }
}`,
  },
  {
    id: 'ticket_history_dao',
    path: 'src/dao/TicketHistoryDAO.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'JDBC DAO for logging and retrieving chronological ticket_history audit records.',
    content: `package dao;

import database.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import model.TicketHistory;

public class TicketHistoryDAO {

    public boolean addHistory(TicketHistory history) {
        String sql = "INSERT INTO ticket_history (ticket_id, previous_status, new_status, changed_by, change_description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, history.getTicketId());
            if (history.getPreviousStatus() != null && !history.getPreviousStatus().isBlank()) {
                pstmt.setString(2, history.getPreviousStatus());
            } else {
                pstmt.setNull(2, Types.VARCHAR);
            }
            pstmt.setString(3, history.getNewStatus());
            pstmt.setInt(4, history.getChangedBy());
            pstmt.setString(5, history.getChangeDescription());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error adding history record: " + e.getMessage());
            return false;
        }
    }

    public List<TicketHistory> getAllHistory() {
        List<TicketHistory> list = new ArrayList<>();
        String sql = "SELECT th.*, u.name AS changed_by_name, u.role AS changed_by_role "
                + "FROM ticket_history th "
                + "LEFT JOIN users u ON th.changed_by = u.user_id "
                + "ORDER BY th.changed_at ASC, th.history_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                list.add(mapResultSetToHistory(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error fetching all history: " + e.getMessage());
        }
        return list;
    }

    public List<TicketHistory> getHistoryByTicketId(String ticketId) {
        List<TicketHistory> list = new ArrayList<>();
        String sql = "SELECT th.*, u.name AS changed_by_name, u.role AS changed_by_role "
                + "FROM ticket_history th "
                + "LEFT JOIN users u ON th.changed_by = u.user_id "
                + "WHERE th.ticket_id = ? "
                + "ORDER BY th.changed_at ASC, th.history_id ASC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ticketId.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToHistory(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("[TicketHistoryDAO] Error fetching ticket history: " + e.getMessage());
        }
        return list;
    }

    private TicketHistory mapResultSetToHistory(ResultSet rs) throws SQLException {
        Timestamp ts = rs.getTimestamp("changed_at");
        LocalDateTime changedAt = ts != null ? ts.toLocalDateTime() : LocalDateTime.now();
        TicketHistory item = new TicketHistory(
                rs.getInt("history_id"),
                rs.getString("ticket_id"),
                rs.getString("previous_status"),
                rs.getString("new_status"),
                rs.getInt("changed_by"),
                rs.getString("change_description"),
                changedAt
        );
        item.setChangedByName(rs.getString("changed_by_name"));
        item.setChangedByRole(rs.getString("changed_by_role"));
        return item;
    }
}`,
  },
  {
    id: 'ticket_dao',
    path: 'src/dao/TicketDAO.java',
    phase: 'Phase 2',
    language: 'java',
    description: 'JDBC DAO for Ticket creation, multi-column filtering, technician assignment, resolution, and SQL aggregate reports.',
    content: `package dao;

import database.DBConnection;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.*;
import model.Technician;
import model.Ticket;
import model.TicketHistory;

public class TicketDAO {

    private final TicketHistoryDAO historyDAO = new TicketHistoryDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();

    private static final String BASE_SELECT_JOIN =
            "SELECT t.*, u.name AS user_name, u.email AS user_email, "
            + "tech.name AS tech_name, tech.specialization AS tech_spec "
            + "FROM tickets t "
            + "INNER JOIN users u ON t.user_id = u.user_id "
            + "LEFT JOIN technicians tech ON t.technician_id = tech.technician_id ";

    public boolean createTicket(Ticket ticket) {
        String sql = "INSERT INTO tickets (ticket_id, subject, description, category, priority, status, user_id) "
                + "VALUES (?, ?, ?, ?, ?, 'OPEN', ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ticket.getTicketId());
            pstmt.setString(2, ticket.getSubject().trim());
            pstmt.setString(3, ticket.getDescription().trim());
            pstmt.setString(4, ticket.getCategory());
            pstmt.setString(5, ticket.getPriority());
            pstmt.setInt(6, ticket.getUserId());
            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticket.getTicketId(), null, "OPEN", ticket.getUserId(),
                        "Ticket created with priority " + ticket.getPriority() + " under category " + ticket.getCategory() + "."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error creating ticket: " + e.getMessage());
        }
        return false;
    }

    public Ticket getTicketById(String ticketId) {
        String sql = BASE_SELECT_JOIN + "WHERE t.ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, ticketId.trim());
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return mapResultSetToTicket(rs);
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching ticket by ID: " + e.getMessage());
        }
        return null;
    }

    public List<Ticket> getAllTickets() {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) list.add(mapResultSetToTicket(rs));
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching all tickets: " + e.getMessage());
        }
        return list;
    }

    public List<Ticket> searchAndFilterTickets(String keyword, String status, String priority, String category) {
        List<Ticket> list = new ArrayList<>();
        StringBuilder sql = new StringBuilder(BASE_SELECT_JOIN + "WHERE 1=1 ");
        List<Object> params = new ArrayList<>();

        if (keyword != null && !keyword.isBlank()) {
            sql.append("AND (t.ticket_id LIKE ? OR t.subject LIKE ? OR u.name LIKE ?) ");
            String pattern = "%" + keyword.trim() + "%";
            params.add(pattern);
            params.add(pattern);
            params.add(pattern);
        }
        if (status != null && !status.equalsIgnoreCase("ALL")) {
            sql.append("AND t.status = ? ");
            params.add(status);
        }
        if (priority != null && !priority.equalsIgnoreCase("ALL")) {
            sql.append("AND t.priority = ? ");
            params.add(priority);
        }
        if (category != null && !category.equalsIgnoreCase("ALL")) {
            sql.append("AND t.category = ? ");
            params.add(category);
        }
        sql.append("ORDER BY t.created_at DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapResultSetToTicket(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error filtering tickets: " + e.getMessage());
        }
        return list;
    }

    public List<Ticket> getTicketsByUserId(int userId) {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "WHERE t.user_id = ? ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapResultSetToTicket(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching user tickets: " + e.getMessage());
        }
        return list;
    }

    public List<Ticket> getTicketsByTechnicianId(int technicianId) {
        List<Ticket> list = new ArrayList<>();
        String sql = BASE_SELECT_JOIN + "WHERE t.technician_id = ? ORDER BY t.created_at DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, technicianId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) list.add(mapResultSetToTicket(rs));
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error fetching technician tickets: " + e.getMessage());
        }
        return list;
    }

    public boolean assignTechnician(String ticketId, int technicianId, int adminUserId) {
        Technician tech = technicianDAO.getTechnicianById(technicianId);
        if (tech == null || !tech.isActive()) return false;
        Ticket existing = getTicketById(ticketId);
        if (existing == null) return false;

        String sql = "UPDATE tickets SET technician_id = ?, status = 'ASSIGNED', updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, technicianId);
            pstmt.setString(2, ticketId);
            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId, existing.getStatus(), "ASSIGNED", adminUserId,
                        "Ticket assigned to Technician " + tech.getName() + " (" + tech.getSpecialization() + ")."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error assigning technician: " + e.getMessage());
        }
        return false;
    }

    public boolean updateStatusAndPriority(String ticketId, String newStatus, String newPriority, int changedByUserId, String note) {
        Ticket existing = getTicketById(ticketId);
        if (existing == null) return false;
        String sql = "UPDATE tickets SET status = ?, priority = ?, updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, newStatus);
            pstmt.setString(2, newPriority);
            pstmt.setString(3, ticketId);
            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId, existing.getStatus(), newStatus, changedByUserId,
                        note != null && !note.isBlank() ? note : "Status updated to " + newStatus + " (Priority: " + newPriority + ")."
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error updating status/priority: " + e.getMessage());
        }
        return false;
    }

    public boolean resolveTicket(String ticketId, String resolutionDetails, int changedByUserId) {
        Ticket existing = getTicketById(ticketId);
        if (existing == null) return false;
        String sql = "UPDATE tickets SET resolution_details = ?, status = 'RESOLVED', "
                + "resolved_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP WHERE ticket_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, resolutionDetails.trim());
            pstmt.setString(2, ticketId);
            if (pstmt.executeUpdate() > 0) {
                historyDAO.addHistory(new TicketHistory(
                        ticketId, existing.getStatus(), "RESOLVED", changedByUserId,
                        "Resolved: " + resolutionDetails.trim()
                ));
                return true;
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error resolving ticket: " + e.getMessage());
        }
        return false;
    }

    public int getTicketCountByStatus(String status) {
        String sql = (status == null || status.equalsIgnoreCase("ALL"))
                ? "SELECT COUNT(*) FROM tickets"
                : "SELECT COUNT(*) FROM tickets WHERE status = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (status != null && !status.equalsIgnoreCase("ALL")) pstmt.setString(1, status);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) return rs.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error counting tickets: " + e.getMessage());
        }
        return 0;
    }

    public Map<String, Integer> getTicketCountsByCategory() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT category, COUNT(*) AS total FROM tickets GROUP BY category ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) map.put(rs.getString("category"), rs.getInt("total"));
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by category: " + e.getMessage());
        }
        return map;
    }

    public Map<String, Integer> getTicketCountsByPriority() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT priority, COUNT(*) AS total FROM tickets GROUP BY priority ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) map.put(rs.getString("priority"), rs.getInt("total"));
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by priority: " + e.getMessage());
        }
        return map;
    }

    public Map<String, Integer> getTicketCountsByTechnician() {
        Map<String, Integer> map = new LinkedHashMap<>();
        String sql = "SELECT tech.name AS tech_name, COUNT(t.ticket_id) AS total "
                + "FROM technicians tech "
                + "LEFT JOIN tickets t ON tech.technician_id = t.technician_id "
                + "GROUP BY tech.technician_id, tech.name ORDER BY total DESC";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) map.put(rs.getString("tech_name"), rs.getInt("total"));
        } catch (SQLException e) {
            System.err.println("[TicketDAO] Error aggregating by technician: " + e.getMessage());
        }
        return map;
    }

    private Ticket mapResultSetToTicket(ResultSet rs) throws SQLException {
        int rawTechId = rs.getInt("technician_id");
        Integer techId = rs.wasNull() ? null : rawTechId;
        Timestamp createdTs = rs.getTimestamp("created_at");
        Timestamp updatedTs = rs.getTimestamp("updated_at");
        Timestamp resolvedTs = rs.getTimestamp("resolved_at");

        Ticket ticket = new Ticket(
                rs.getString("ticket_id"),
                rs.getString("subject"),
                rs.getString("description"),
                rs.getString("category"),
                rs.getString("priority"),
                rs.getString("status"),
                rs.getInt("user_id"),
                techId,
                rs.getString("resolution_details"),
                createdTs != null ? createdTs.toLocalDateTime() : LocalDateTime.now(),
                updatedTs != null ? updatedTs.toLocalDateTime() : LocalDateTime.now(),
                resolvedTs != null ? resolvedTs.toLocalDateTime() : null
        );
        ticket.setUserName(rs.getString("user_name"));
        ticket.setUserEmail(rs.getString("user_email"));
        ticket.setTechnicianName(rs.getString("tech_name"));
        ticket.setTechnicianSpecialization(rs.getString("tech_spec"));
        return ticket;
    }
}`,
  },
];
