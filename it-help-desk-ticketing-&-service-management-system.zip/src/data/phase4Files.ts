import { CodeFileEntry } from './phase1Files';

export const PHASE_4_FILES: CodeFileEntry[] = [
  {
    id: 'main_java',
    path: 'src/Main.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Application entry point that initializes Swing LookAndFeel and launches LoginFrame on the Event Dispatch Thread.',
    content: `import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import ui.LoginFrame;

/**
 * Main entry point for the IT Help Desk Ticketing and Service Management System.
 * Course: TY EXTC Java Programming Micro Project (A.Y. 2026-2027)
 * Tech Stack: Java 22, Java Swing, MySQL 8+, JDBC
 */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {
            System.err.println("[Main] Warning: Could not set LookAndFeel: " + e.getMessage());
        }

        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }
}`,
  },
  {
    id: 'admin_dashboard',
    path: 'src/ui/AdminDashboard.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Admin Dashboard with 8 live metrics, 9-item navigation menu, SQL GROUP BY reports, and CSV file export.',
    content: `package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import dao.UserDAO;
import java.awt.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import model.Ticket;
import utils.SessionManager;

public class AdminDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final UserDAO userDAO = new UserDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final TicketDAO ticketDAO = new TicketDAO();

    private JLabel lblTotalUsers, lblTotalTechs, lblTotalTickets, lblOpenTickets;
    private JLabel lblAssignedTickets, lblInProgressTickets, lblResolvedTickets, lblClosedTickets;
    private JTextArea txtReportSummary;

    public AdminDashboard() {
        if (!SessionManager.isLoggedIn() || !SessionManager.isAdmin()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }
        setTitle("Admin Dashboard — IT Help Desk Ticketing & Service Management System");
        setSize(1160, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        refreshAllMetricsAndReports();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(PRIMARY_COLOR);
        sidebar.setPreferredSize(new Dimension(250, 0));
        sidebar.setBorder(new EmptyBorder(18, 14, 18, 14));

        JPanel menuPanel = new JPanel(new GridLayout(10, 1, 0, 8));
        menuPanel.setOpaque(false);

        JLabel lblBrand = new JLabel("ADMIN CONTROL PANEL");
        lblBrand.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblBrand.setForeground(ACCENT_COLOR);
        menuPanel.add(lblBrand);

        JButton btnDashboard = createMenuButton("1. Dashboard Refresh");
        btnDashboard.addActionListener(e -> refreshAllMetricsAndReports());

        JButton btnManageUsers = createMenuButton("2. Manage Users");
        btnManageUsers.addActionListener(e -> new ManageUsersFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnManageTechs = createMenuButton("3. Manage Technicians");
        btnManageTechs.addActionListener(e -> new ManageTechniciansFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnAllTickets = createMenuButton("4. All Tickets");
        btnAllTickets.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnAssignTech = createMenuButton("5. Assign Technician");
        btnAssignTech.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnUpdateTicket = createMenuButton("6. Update Ticket");
        btnUpdateTicket.addActionListener(e -> new ManageTicketsFrame(this::refreshAllMetricsAndReports).setVisible(true));

        JButton btnTicketHistory = createMenuButton("7. Ticket History");
        btnTicketHistory.addActionListener(e -> new TicketHistoryFrame("").setVisible(true));

        JButton btnReports = createMenuButton("8. Export Reports (CSV)");
        btnReports.addActionListener(e -> exportReportToCSV());

        menuPanel.add(btnDashboard);
        menuPanel.add(btnManageUsers);
        menuPanel.add(btnManageTechs);
        menuPanel.add(btnAllTickets);
        menuPanel.add(btnAssignTech);
        menuPanel.add(btnUpdateTicket);
        menuPanel.add(btnTicketHistory);
        menuPanel.add(btnReports);

        sidebar.add(menuPanel, BorderLayout.NORTH);

        JButton btnLogout = new JButton("9. Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.addActionListener(e -> {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        });
        sidebar.add(btnLogout, BorderLayout.SOUTH);
        add(sidebar, BorderLayout.WEST);

        JPanel mainWorkspace = new JPanel(new BorderLayout(16, 16));
        mainWorkspace.setBackground(BG_COLOR);
        mainWorkspace.setBorder(new EmptyBorder(20, 24, 20, 24));

        JPanel metricsGrid = new JPanel(new GridLayout(2, 4, 14, 14));
        metricsGrid.setBackground(BG_COLOR);

        lblTotalUsers = new JLabel("0");
        lblTotalTechs = new JLabel("0");
        lblTotalTickets = new JLabel("0");
        lblOpenTickets = new JLabel("0");
        lblAssignedTickets = new JLabel("0");
        lblInProgressTickets = new JLabel("0");
        lblResolvedTickets = new JLabel("0");
        lblClosedTickets = new JLabel("0");

        metricsGrid.add(createMetricCard("Total Users", lblTotalUsers, PRIMARY_COLOR));
        metricsGrid.add(createMetricCard("Total Technicians", lblTotalTechs, SECONDARY_COLOR));
        metricsGrid.add(createMetricCard("Total Tickets", lblTotalTickets, PRIMARY_COLOR));
        metricsGrid.add(createMetricCard("Open Tickets", lblOpenTickets, ACCENT_COLOR));
        metricsGrid.add(createMetricCard("Assigned Tickets", lblAssignedTickets, SECONDARY_COLOR));
        metricsGrid.add(createMetricCard("In Progress Tickets", lblInProgressTickets, new Color(217, 119, 6)));
        metricsGrid.add(createMetricCard("Resolved Tickets", lblResolvedTickets, new Color(22, 163, 74)));
        metricsGrid.add(createMetricCard("Closed Tickets", lblClosedTickets, new Color(100, 116, 139)));

        mainWorkspace.add(metricsGrid, BorderLayout.NORTH);

        JPanel reportPanel = new JPanel(new BorderLayout(10, 10));
        reportPanel.setBackground(Color.WHITE);
        reportPanel.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(16, 18, 16, 18)
        ));

        JPanel reportHeader = new JPanel(new BorderLayout());
        reportHeader.setBackground(Color.WHITE);
        JLabel lblReportHeading = new JLabel("SQL Aggregate System Reports (Category, Priority & Technician Workload)");
        lblReportHeading.setFont(new Font("SansSerif", Font.BOLD, 15));
        lblReportHeading.setForeground(PRIMARY_COLOR);
        reportHeader.add(lblReportHeading, BorderLayout.WEST);

        JButton btnExportCsv = new JButton("Export Tickets Report to CSV");
        btnExportCsv.setBackground(ACCENT_COLOR);
        btnExportCsv.setForeground(Color.WHITE);
        btnExportCsv.addActionListener(e -> exportReportToCSV());
        reportHeader.add(btnExportCsv, BorderLayout.EAST);
        reportPanel.add(reportHeader, BorderLayout.NORTH);

        txtReportSummary = new JTextArea();
        txtReportSummary.setEditable(false);
        txtReportSummary.setFont(new Font("Monospaced", Font.PLAIN, 13));
        reportPanel.add(new JScrollPane(txtReportSummary), BorderLayout.CENTER);

        mainWorkspace.add(reportPanel, BorderLayout.CENTER);
        add(mainWorkspace, BorderLayout.CENTER);
    }

    private JButton createMenuButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(SECONDARY_COLOR);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setHorizontalAlignment(SwingConstants.LEFT);
        return btn;
    }

    private JPanel createMetricCard(String title, JLabel valLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 6));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(14, 16, 14, 16)
        ));
        JLabel lbl = new JLabel(title);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        lbl.setForeground(new Color(100, 116, 139));
        valLabel.setFont(new Font("Monospaced", Font.BOLD, 26));
        valLabel.setForeground(color);
        card.add(lbl, BorderLayout.NORTH);
        card.add(valLabel, BorderLayout.CENTER);
        return card;
    }

    public final void refreshAllMetricsAndReports() {
        lblTotalUsers.setText(String.valueOf(userDAO.getTotalUserCount()));
        lblTotalTechs.setText(String.valueOf(technicianDAO.getTotalTechnicianCount()));
        lblTotalTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("ALL")));
        lblOpenTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("OPEN")));
        lblAssignedTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("ASSIGNED")));
        lblInProgressTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("IN_PROGRESS")));
        lblResolvedTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("RESOLVED")));
        lblClosedTickets.setText(String.valueOf(ticketDAO.getTicketCountByStatus("CLOSED")));

        StringBuilder sb = new StringBuilder();
        sb.append("1. TICKETS BY CATEGORY:\\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByCategory().entrySet()) {
            sb.append(String.format("   - %-20s : %d\\n", e.getKey(), e.getValue()));
        }
        sb.append("\\n2. TICKETS BY PRIORITY:\\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByPriority().entrySet()) {
            sb.append(String.format("   - %-20s : %d\\n", e.getKey(), e.getValue()));
        }
        sb.append("\\n3. TICKETS HANDLED BY TECHNICIAN:\\n");
        for (Map.Entry<String, Integer> e : ticketDAO.getTicketCountsByTechnician().entrySet()) {
            sb.append(String.format("   - %-24s : %d tickets\\n", e.getKey(), e.getValue()));
        }
        txtReportSummary.setText(sb.toString());
    }

    private void exportReportToCSV() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("helpdesk_tickets_report.csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            File file = chooser.getSelectedFile();
            List<Ticket> allTickets = ticketDAO.getAllTickets();
            try (FileWriter writer = new FileWriter(file)) {
                writer.write("Ticket ID,Subject,Category,Priority,Status,User,Technician,Created At\\n");
                for (Ticket t : allTickets) {
                    writer.write(String.format("\\"%s\\",\\"%s\\",\\"%s\\",\\"%s\\",\\"%s\\",\\"%s\\",\\"%s\\",\\"%s\\"\\n",
                            t.getTicketId(), t.getSubject().replace("\\"", "\\"\\""),
                            t.getCategory(), t.getPriority(), t.getStatus(),
                            t.getUserName(), t.getTechnicianName(),
                            t.getCreatedAt() != null ? t.getCreatedAt().toString() : ""
                    ));
                }
                JOptionPane.showMessageDialog(this, "CSV Report exported to:\\n" + file.getAbsolutePath());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Error writing CSV: " + ex.getMessage());
            }
        }
    }
}`,
  },
  {
    id: 'technician_dashboard',
    path: 'src/ui/TechnicianDashboard.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Technician Dashboard displaying assigned ticket metrics, Accept/Start Work controls, and the Resolution Form.',
    content: `package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import model.Ticket;
import model.User;
import utils.SessionManager;

public class TechnicianDashboard extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private Technician currentTech;
    private JLabel lblAssigned, lblInProgress, lblResolved, lblHighPriority, lblCritical;
    private DefaultTableModel tableModel;
    private JTable table;

    private JTextField txtResTicketId, txtResTechnician, txtResDate, txtResStatus;
    private JTextArea txtProblemDesc, txtResolutionDetails;

    public TechnicianDashboard() {
        if (!SessionManager.isLoggedIn() || !SessionManager.isTechnician()) {
            dispose();
            new LoginFrame().setVisible(true);
            return;
        }
        User user = SessionManager.getCurrentUser();
        this.currentTech = SessionManager.getCurrentTechnician();
        if (this.currentTech == null && user != null) {
            this.currentTech = technicianDAO.getTechnicianByUser(user.getUserId(), user.getEmail());
        }

        setTitle("Technician Dashboard & Resolution Console — IT Help Desk System");
        setSize(1120, 680);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadAssignedTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 22, 14, 22));

        String techTitle = currentTech != null
                ? "Technician Portal: " + currentTech.getName() + " [" + currentTech.getSpecialization() + "]"
                : "Technician Portal";
        JLabel lblTitle = new JLabel(techTitle);
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);

        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(new Color(220, 38, 38));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.addActionListener(e -> {
            SessionManager.logout();
            dispose();
            new LoginFrame().setVisible(true);
        });
        headerPanel.add(btnLogout, BorderLayout.EAST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel mainContainer = new JPanel(new BorderLayout(12, 12));
        mainContainer.setBackground(BG_COLOR);
        mainContainer.setBorder(new EmptyBorder(10, 18, 14, 18));

        JPanel statsGrid = new JPanel(new GridLayout(1, 5, 12, 0));
        statsGrid.setBackground(BG_COLOR);

        lblAssigned = new JLabel("0");
        lblInProgress = new JLabel("0");
        lblResolved = new JLabel("0");
        lblHighPriority = new JLabel("0");
        lblCritical = new JLabel("0");

        statsGrid.add(createStatCard("Assigned Tickets", lblAssigned, PRIMARY_COLOR));
        statsGrid.add(createStatCard("In Progress", lblInProgress, ACCENT_COLOR));
        statsGrid.add(createStatCard("Resolved", lblResolved, new Color(22, 163, 74)));
        statsGrid.add(createStatCard("High Priority", lblHighPriority, new Color(217, 119, 6)));
        statsGrid.add(createStatCard("Critical Tickets", lblCritical, new Color(220, 38, 38)));
        mainContainer.add(statsGrid, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setDividerLocation(270);

        JPanel tableSection = new JPanel(new BorderLayout(6, 6));
        tableSection.setBackground(Color.WHITE);
        tableSection.setBorder(BorderFactory.createTitledBorder("Tickets Assigned to Me"));

        String[] cols = {"Ticket ID", "Subject", "Category", "Priority", "Raised By", "Status", "Created Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() >= 0) {
                populateResolutionForm((String) tableModel.getValueAt(table.getSelectedRow(), 0));
            }
        });
        tableSection.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        actionRow.setBackground(Color.WHITE);

        JButton btnAcceptStart = new JButton("Accept & Start Work (IN_PROGRESS)");
        btnAcceptStart.setBackground(PRIMARY_COLOR);
        btnAcceptStart.setForeground(Color.WHITE);
        btnAcceptStart.addActionListener(e -> handleQuickStatusChange("IN_PROGRESS", "Technician accepted ticket and started work."));

        JButton btnCloseResolved = new JButton("Close Resolved Ticket (CLOSED)");
        btnCloseResolved.setBackground(SECONDARY_COLOR);
        btnCloseResolved.setForeground(Color.WHITE);
        btnCloseResolved.addActionListener(e -> handleQuickStatusChange("CLOSED", "Technician verified resolution and closed ticket."));

        JButton btnViewDetails = new JButton("View Ticket Details");
        btnViewDetails.addActionListener(e -> {
            int r = table.getSelectedRow();
            if (r >= 0) new TicketDetailsFrame((String) tableModel.getValueAt(r, 0)).setVisible(true);
        });

        actionRow.add(btnAcceptStart);
        actionRow.add(btnCloseResolved);
        actionRow.add(btnViewDetails);
        tableSection.add(actionRow, BorderLayout.SOUTH);

        JPanel resolutionForm = new JPanel(new BorderLayout(10, 10));
        resolutionForm.setBackground(Color.WHITE);
        resolutionForm.setBorder(BorderFactory.createTitledBorder("Ticket Resolution Form"));

        JPanel metaRow = new JPanel(new GridLayout(1, 4, 10, 0));
        metaRow.setBackground(Color.WHITE);
        txtResTicketId = createReadOnlyField(metaRow, "Ticket ID:");
        txtResTechnician = createReadOnlyField(metaRow, "Technician:");
        txtResDate = createReadOnlyField(metaRow, "Resolution Date:");
        txtResStatus = createReadOnlyField(metaRow, "Current Status:");
        resolutionForm.add(metaRow, BorderLayout.NORTH);

        JPanel textSplit = new JPanel(new GridLayout(1, 2, 12, 0));
        textSplit.setBackground(Color.WHITE);
        txtProblemDesc = new JTextArea(4, 25);
        txtProblemDesc.setEditable(false);
        JScrollPane pScroll = new JScrollPane(txtProblemDesc);
        pScroll.setBorder(BorderFactory.createTitledBorder("Problem Description"));

        txtResolutionDetails = new JTextArea(4, 25);
        JScrollPane rScroll = new JScrollPane(txtResolutionDetails);
        rScroll.setBorder(BorderFactory.createTitledBorder("Resolution Details *"));

        textSplit.add(pScroll);
        textSplit.add(rScroll);
        resolutionForm.add(textSplit, BorderLayout.CENTER);

        JPanel resFooter = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 6));
        resFooter.setBackground(Color.WHITE);
        JButton btnResolve = new JButton("Submit Resolution & Mark Ticket as RESOLVED");
        btnResolve.setBackground(new Color(22, 163, 74));
        btnResolve.setForeground(Color.WHITE);
        btnResolve.addActionListener(e -> handleSubmitResolution());
        resFooter.add(btnResolve);
        resolutionForm.add(resFooter, BorderLayout.SOUTH);

        splitPane.setTopComponent(tableSection);
        splitPane.setBottomComponent(resolutionForm);
        mainContainer.add(splitPane, BorderLayout.CENTER);
        add(mainContainer, BorderLayout.CENTER);
    }

    private JTextField createReadOnlyField(JPanel parent, String label) {
        JPanel p = new JPanel(new BorderLayout(4, 2));
        p.setBackground(Color.WHITE);
        p.add(new JLabel(label), BorderLayout.NORTH);
        JTextField tf = new JTextField();
        tf.setEditable(false);
        p.add(tf, BorderLayout.CENTER);
        parent.add(p);
        return tf;
    }

    private JPanel createStatCard(String title, JLabel valLabel, Color color) {
        JPanel card = new JPanel(new BorderLayout(0, 4));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(226, 232, 240), 1),
                new EmptyBorder(12, 14, 12, 14)
        ));
        JLabel t = new JLabel(title);
        t.setFont(new Font("SansSerif", Font.BOLD, 12));
        valLabel.setFont(new Font("Monospaced", Font.BOLD, 24));
        valLabel.setForeground(color);
        card.add(t, BorderLayout.NORTH);
        card.add(valLabel, BorderLayout.CENTER);
        return card;
    }

    public final void loadAssignedTickets() {
        tableModel.setRowCount(0);
        if (currentTech == null) return;
        List<Ticket> list = ticketDAO.getTicketsByTechnicianId(currentTech.getTechnicianId());
        int assigned = list.size(), inProg = 0, resolved = 0, high = 0, critical = 0;

        for (Ticket t : list) {
            if ("IN_PROGRESS".equalsIgnoreCase(t.getStatus())) inProg++;
            if ("RESOLVED".equalsIgnoreCase(t.getStatus())) resolved++;
            if ("High".equalsIgnoreCase(t.getPriority())) high++;
            if ("Critical".equalsIgnoreCase(t.getPriority())) critical++;

            tableModel.addRow(new Object[]{
                    t.getTicketId(), t.getSubject(), t.getCategory(),
                    t.getPriority(), t.getUserName(), t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-"
            });
        }

        lblAssigned.setText(String.valueOf(assigned));
        lblInProgress.setText(String.valueOf(inProg));
        lblResolved.setText(String.valueOf(resolved));
        lblHighPriority.setText(String.valueOf(high));
        lblCritical.setText(String.valueOf(critical));
    }

    private void populateResolutionForm(String ticketId) {
        Ticket t = ticketDAO.getTicketById(ticketId);
        if (t == null) return;
        txtResTicketId.setText(t.getTicketId());
        txtResTechnician.setText(currentTech != null ? currentTech.getName() : "Technician");
        txtResDate.setText(LocalDateTime.now().format(FMT));
        txtResStatus.setText(t.getStatus());
        txtProblemDesc.setText(t.getDescription());
        txtResolutionDetails.setText(t.getResolutionDetails() != null ? t.getResolutionDetails() : "");
    }

    private void handleQuickStatusChange(String targetStatus, String note) {
        int r = table.getSelectedRow();
        if (r < 0) return;
        String ticketId = (String) tableModel.getValueAt(r, 0);
        String priority = (String) tableModel.getValueAt(r, 3);
        User user = SessionManager.getCurrentUser();
        if (user != null && ticketDAO.updateStatusAndPriority(ticketId, targetStatus, priority, user.getUserId(), note)) {
            loadAssignedTickets();
            populateResolutionForm(ticketId);
        }
    }

    private void handleSubmitResolution() {
        String ticketId = txtResTicketId.getText().trim();
        String resDetails = txtResolutionDetails.getText().trim();
        if (ticketId.isEmpty() || resDetails.isEmpty()) return;
        User user = SessionManager.getCurrentUser();
        if (user != null && ticketDAO.resolveTicket(ticketId, resDetails, user.getUserId())) {
            JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " marked as RESOLVED!");
            loadAssignedTickets();
            populateResolutionForm(ticketId);
        }
    }
}`,
  },
  {
    id: 'manage_tickets_frame',
    path: 'src/ui/ManageTicketsFrame.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Admin Ticket Management table with Search, multi-column filters, Active Technician assignment, and status/priority updates.',
    content: `package ui;

import dao.TechnicianDAO;
import dao.TicketDAO;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import model.Ticket;
import model.User;
import utils.SessionManager;

public class ManageTicketsFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TicketDAO ticketDAO = new TicketDAO();
    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final Runnable onChangeCallback;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private JTextField txtSearch;
    private JComboBox<String> cmbFilterStatus, cmbFilterPriority, cmbFilterCategory;
    private DefaultTableModel tableModel;
    private JTable table;
    private JComboBox<Technician> cmbActiveTechnicians;
    private JComboBox<String> cmbNewStatus, cmbNewPriority;

    public ManageTicketsFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        setTitle("All Tickets Management & Technician Assignment — IT Help Desk Admin");
        setSize(1140, 660);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadTickets();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("All Tickets Management, Technician Assignment & Status Updates");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel mainBody = new JPanel(new BorderLayout(10, 10));
        mainBody.setBackground(BG_COLOR);
        mainBody.setBorder(new EmptyBorder(8, 14, 8, 14));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 8));
        filterPanel.setBackground(Color.WHITE);

        filterPanel.add(new JLabel("Search:"));
        txtSearch = new JTextField(16);
        filterPanel.add(txtSearch);

        filterPanel.add(new JLabel("Status:"));
        cmbFilterStatus = new JComboBox<>(new String[]{"ALL", "OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"});
        filterPanel.add(cmbFilterStatus);

        filterPanel.add(new JLabel("Priority:"));
        cmbFilterPriority = new JComboBox<>(new String[]{"ALL", "Low", "Medium", "High", "Critical"});
        filterPanel.add(cmbFilterPriority);

        filterPanel.add(new JLabel("Category:"));
        cmbFilterCategory = new JComboBox<>(new String[]{"ALL", "Hardware", "Software", "Network", "Printer", "Email", "Account/Login", "Other"});
        filterPanel.add(cmbFilterCategory);

        JButton btnFilter = new JButton("Apply Filters");
        btnFilter.setBackground(PRIMARY_COLOR);
        btnFilter.setForeground(Color.WHITE);
        btnFilter.addActionListener(e -> loadTickets());
        filterPanel.add(btnFilter);

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setBackground(ACCENT_COLOR);
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.addActionListener(e -> {
            txtSearch.setText("");
            cmbFilterStatus.setSelectedIndex(0);
            cmbFilterPriority.setSelectedIndex(0);
            cmbFilterCategory.setSelectedIndex(0);
            loadActiveTechniciansDropdown();
            loadTickets();
        });
        filterPanel.add(btnRefresh);

        mainBody.add(filterPanel, BorderLayout.NORTH);

        String[] cols = {"Ticket ID", "Subject", "Category", "Priority", "User", "Technician", "Status", "Created Date", "Updated Date"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(27);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);
        mainBody.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel actionStrip = new JPanel(new GridLayout(1, 2, 12, 0));
        actionStrip.setBackground(BG_COLOR);

        JPanel assignPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        assignPanel.setBackground(Color.WHITE);
        assignPanel.setBorder(BorderFactory.createTitledBorder("Assign Active Technician to Selected Ticket"));
        cmbActiveTechnicians = new JComboBox<>();
        loadActiveTechniciansDropdown();
        assignPanel.add(cmbActiveTechnicians);

        JButton btnAssign = new JButton("Assign Technician");
        btnAssign.setBackground(PRIMARY_COLOR);
        btnAssign.setForeground(Color.WHITE);
        btnAssign.addActionListener(e -> handleAssignTechnician());
        assignPanel.add(btnAssign);

        JPanel updatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        updatePanel.setBackground(Color.WHITE);
        updatePanel.setBorder(BorderFactory.createTitledBorder("Update Ticket Status / Priority & Inspect"));
        updatePanel.add(new JLabel("Priority:"));
        cmbNewPriority = new JComboBox<>(new String[]{"Low", "Medium", "High", "Critical"});
        updatePanel.add(cmbNewPriority);

        updatePanel.add(new JLabel("Status:"));
        cmbNewStatus = new JComboBox<>(new String[]{"OPEN", "ASSIGNED", "IN_PROGRESS", "RESOLVED", "CLOSED"});
        updatePanel.add(cmbNewStatus);

        JButton btnUpdate = new JButton("Update Ticket");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateStatusAndPriority());
        updatePanel.add(btnUpdate);

        actionStrip.add(assignPanel);
        actionStrip.add(updatePanel);
        mainBody.add(actionStrip, BorderLayout.SOUTH);
        add(mainBody, BorderLayout.CENTER);
    }

    private void loadActiveTechniciansDropdown() {
        cmbActiveTechnicians.removeAllItems();
        for (Technician t : technicianDAO.getActiveTechnicians()) {
            cmbActiveTechnicians.addItem(t);
        }
    }

    public final void loadTickets() {
        tableModel.setRowCount(0);
        List<Ticket> list = ticketDAO.searchAndFilterTickets(
                txtSearch.getText(),
                (String) cmbFilterStatus.getSelectedItem(),
                (String) cmbFilterPriority.getSelectedItem(),
                (String) cmbFilterCategory.getSelectedItem()
        );
        for (Ticket t : list) {
            tableModel.addRow(new Object[]{
                    t.getTicketId(), t.getSubject(), t.getCategory(), t.getPriority(),
                    t.getUserName(), t.getTechnicianName(), t.getStatus(),
                    t.getCreatedAt() != null ? t.getCreatedAt().format(FMT) : "-",
                    t.getUpdatedAt() != null ? t.getUpdatedAt().format(FMT) : "-"
            });
        }
    }

    private void handleAssignTechnician() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String ticketId = (String) tableModel.getValueAt(row, 0);
        Technician selectedTech = (Technician) cmbActiveTechnicians.getSelectedItem();
        User admin = SessionManager.getCurrentUser();
        if (selectedTech != null && admin != null && ticketDAO.assignTechnician(ticketId, selectedTech.getTechnicianId(), admin.getUserId())) {
            JOptionPane.showMessageDialog(this, "Ticket " + ticketId + " assigned to " + selectedTech.getName());
            loadTickets();
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateStatusAndPriority() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        String ticketId = (String) tableModel.getValueAt(row, 0);
        String newPriority = (String) cmbNewPriority.getSelectedItem();
        String newStatus = (String) cmbNewStatus.getSelectedItem();
        User admin = SessionManager.getCurrentUser();
        if (admin != null && ticketDAO.updateStatusAndPriority(ticketId, newStatus, newPriority, admin.getUserId(), "Admin updated status/priority.")) {
            loadTickets();
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }
}`,
  },
  {
    id: 'manage_users_frame',
    path: 'src/ui/ManageUsersFrame.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Admin User Management frame with Add, Edit, Delete, Search, and JTable display.',
    content: `package ui;

import dao.UserDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.User;
import utils.PasswordUtil;
import utils.SessionManager;

public class ManageUsersFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final UserDAO userDAO = new UserDAO();
    private final Runnable onChangeCallback;

    private JTextField txtUserId, txtName, txtEmail, txtPhone, txtDepartment, txtUsername, txtSearch;
    private JPasswordField txtPassword;
    private JComboBox<String> cmbRole, cmbStatus;
    private DefaultTableModel tableModel;
    private JTable table;

    public ManageUsersFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        setTitle("Manage Users — IT Help Desk Admin");
        setSize(1080, 640);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadUsersTable(userDAO.getAllUsers());
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Manage System Users (Add / Edit / Delete / Search)");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setPreferredSize(new Dimension(360, 0));
        formPanel.setBorder(BorderFactory.createTitledBorder("User Details Form"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 6, 5, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        txtUserId = new JTextField();
        txtUserId.setEditable(false);
        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();
        txtDepartment = new JTextField();
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();
        cmbRole = new JComboBox<>(new String[]{"USER", "TECHNICIAN", "ADMIN"});
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        int row = 0;
        addFormField(formPanel, gbc, row++, "User ID:", txtUserId);
        addFormField(formPanel, gbc, row++, "Full Name *:", txtName);
        addFormField(formPanel, gbc, row++, "Email *:", txtEmail);
        addFormField(formPanel, gbc, row++, "Phone (10 digits) *:", txtPhone);
        addFormField(formPanel, gbc, row++, "Department *:", txtDepartment);
        addFormField(formPanel, gbc, row++, "Username *:", txtUsername);
        addFormField(formPanel, gbc, row++, "Password (SHA-256):", txtPassword);
        addFormField(formPanel, gbc, row++, "Role:", cmbRole);
        addFormField(formPanel, gbc, row++, "Status:", cmbStatus);

        JPanel crudBtnPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        JButton btnAdd = new JButton("Add User");
        btnAdd.setBackground(PRIMARY_COLOR);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> handleAddUser());

        JButton btnUpdate = new JButton("Edit / Update");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateUser());

        JButton btnDelete = new JButton("Delete User");
        btnDelete.setBackground(new Color(220, 38, 38));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> handleDeleteUser());

        JButton btnClear = new JButton("Clear Form");
        btnClear.addActionListener(e -> clearForm());

        crudBtnPanel.add(btnAdd);
        crudBtnPanel.add(btnUpdate);
        crudBtnPanel.add(btnDelete);
        crudBtnPanel.add(btnClear);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        formPanel.add(crudBtnPanel, gbc);
        add(formPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new BorderLayout(8, 8));
        rightPanel.setBackground(BG_COLOR);

        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Search User:"));
        txtSearch = new JTextField(20);
        searchBar.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> loadUsersTable(userDAO.searchUsers(txtSearch.getText())));
        searchBar.add(btnSearch);

        JButton btnViewAll = new JButton("View All Users");
        btnViewAll.setBackground(ACCENT_COLOR);
        btnViewAll.setForeground(Color.WHITE);
        btnViewAll.addActionListener(e -> loadUsersTable(userDAO.getAllUsers()));
        searchBar.add(btnViewAll);

        rightPanel.add(searchBar, BorderLayout.NORTH);

        String[] cols = {"User ID", "Name", "Email", "Phone", "Department", "Username", "Role", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        rightPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        add(rightPanel, BorderLayout.CENTER);
    }

    private void addFormField(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(comp, gbc);
    }

    private void loadUsersTable(List<User> users) {
        tableModel.setRowCount(0);
        for (User u : users) {
            tableModel.addRow(new Object[]{
                    u.getUserId(), u.getName(), u.getEmail(), u.getPhone(),
                    u.getDepartment(), u.getUsername(), u.getRole(), u.getStatus()
            });
        }
    }

    private void handleAddUser() {
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String dept = txtDepartment.getText().trim();
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword()).trim();
        String role = (String) cmbRole.getSelectedItem();
        String status = (String) cmbStatus.getSelectedItem();

        if (!PasswordUtil.isValidEmail(email) || !PasswordUtil.isValidPhone(phone) || !PasswordUtil.isValidPassword(password)) {
            JOptionPane.showMessageDialog(this, "Invalid email, 10-digit phone, or password (<6 chars).");
            return;
        }
        User newUser = new User(name, email, phone, dept, username, PasswordUtil.hashPassword(password), role, status);
        if (userDAO.addUser(newUser)) {
            clearForm();
            loadUsersTable(userDAO.getAllUsers());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateUser() {
        if (txtUserId.getText().isEmpty()) return;
        int userId = Integer.parseInt(txtUserId.getText());
        User updated = new User(userId, txtName.getText().trim(), txtEmail.getText().trim(),
                txtPhone.getText().trim(), txtDepartment.getText().trim(), txtUsername.getText().trim(),
                "", (String) cmbRole.getSelectedItem(), (String) cmbStatus.getSelectedItem(), null);
        if (userDAO.updateUser(updated, new String(txtPassword.getPassword()).trim())) {
            loadUsersTable(userDAO.getAllUsers());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleDeleteUser() {
        if (txtUserId.getText().isEmpty()) return;
        int userId = Integer.parseInt(txtUserId.getText());
        if (userDAO.deleteUser(userId)) {
            clearForm();
            loadUsersTable(userDAO.getAllUsers());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void clearForm() {
        txtUserId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtDepartment.setText("");
        txtUsername.setText("");
        txtPassword.setText("");
    }
}`,
  },
  {
    id: 'manage_technicians_frame',
    path: 'src/ui/ManageTechniciansFrame.java',
    phase: 'Phase 4',
    language: 'java',
    description: 'Admin Technician Management frame with Add, Edit, Delete, Search, View Details, and Activate/Deactivate.',
    content: `package ui;

import dao.TechnicianDAO;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import model.Technician;
import utils.PasswordUtil;

public class ManageTechniciansFrame extends JFrame {

    private static final Color PRIMARY_COLOR = Color.decode("#1E3A5F");
    private static final Color SECONDARY_COLOR = Color.decode("#2E6F95");
    private static final Color ACCENT_COLOR = Color.decode("#00A8E8");
    private static final Color BG_COLOR = Color.decode("#F4F7FA");

    private final TechnicianDAO technicianDAO = new TechnicianDAO();
    private final Runnable onChangeCallback;

    private JTextField txtTechId, txtName, txtEmail, txtPhone, txtSearch;
    private JComboBox<String> cmbSpecialization, cmbStatus;
    private DefaultTableModel tableModel;
    private JTable table;

    public ManageTechniciansFrame(Runnable onChangeCallback) {
        this.onChangeCallback = onChangeCallback;
        setTitle("Manage Technicians — IT Help Desk Admin");
        setSize(1040, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        getContentPane().setBackground(BG_COLOR);
        initComponents();
        loadTechnicians(technicianDAO.getAllTechnicians());
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(PRIMARY_COLOR);
        headerPanel.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel lblTitle = new JLabel("Manage Technicians & Specializations");
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 17));
        lblTitle.setForeground(Color.WHITE);
        headerPanel.add(lblTitle, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        formPanel.setPreferredSize(new Dimension(350, 0));
        formPanel.setBorder(BorderFactory.createTitledBorder("Technician Form"));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;

        txtTechId = new JTextField();
        txtTechId.setEditable(false);
        txtName = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();
        cmbSpecialization = new JComboBox<>(new String[]{"Hardware", "Software", "Network", "Database", "General Support"});
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});

        int row = 0;
        addField(formPanel, gbc, row++, "Technician ID:", txtTechId);
        addField(formPanel, gbc, row++, "Name *:", txtName);
        addField(formPanel, gbc, row++, "Email *:", txtEmail);
        addField(formPanel, gbc, row++, "Phone *:", txtPhone);
        addField(formPanel, gbc, row++, "Specialization:", cmbSpecialization);
        addField(formPanel, gbc, row++, "Status:", cmbStatus);

        JPanel btnGrid = new JPanel(new GridLayout(3, 2, 8, 8));
        JButton btnAdd = new JButton("Add Technician");
        btnAdd.setBackground(PRIMARY_COLOR);
        btnAdd.setForeground(Color.WHITE);
        btnAdd.addActionListener(e -> handleAddTechnician());

        JButton btnUpdate = new JButton("Edit Technician");
        btnUpdate.setBackground(SECONDARY_COLOR);
        btnUpdate.setForeground(Color.WHITE);
        btnUpdate.addActionListener(e -> handleUpdateTechnician());

        JButton btnToggle = new JButton("Activate / Deactivate");
        btnToggle.setBackground(ACCENT_COLOR);
        btnToggle.setForeground(Color.WHITE);
        btnToggle.addActionListener(e -> handleToggleActive());

        JButton btnDelete = new JButton("Delete");
        btnDelete.setBackground(new Color(220, 38, 38));
        btnDelete.setForeground(Color.WHITE);
        btnDelete.addActionListener(e -> handleDeleteTechnician());

        btnGrid.add(btnAdd);
        btnGrid.add(btnUpdate);
        btnGrid.add(btnToggle);
        btnGrid.add(btnDelete);

        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 2;
        formPanel.add(btnGrid, gbc);
        add(formPanel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel(new BorderLayout(8, 8));
        JPanel searchBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 6));
        searchBar.setBackground(Color.WHITE);
        searchBar.add(new JLabel("Search Technician:"));
        txtSearch = new JTextField(20);
        searchBar.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBackground(PRIMARY_COLOR);
        btnSearch.setForeground(Color.WHITE);
        btnSearch.addActionListener(e -> loadTechnicians(technicianDAO.searchTechnicians(txtSearch.getText())));
        searchBar.add(btnSearch);

        rightPanel.add(searchBar, BorderLayout.NORTH);

        String[] cols = {"Technician ID", "Name", "Email", "Phone", "Specialization", "Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            @Override
            public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(26);
        table.getTableHeader().setBackground(PRIMARY_COLOR);
        table.getTableHeader().setForeground(Color.WHITE);

        rightPanel.add(new JScrollPane(table), BorderLayout.CENTER);
        add(rightPanel, BorderLayout.CENTER);
    }

    private void addField(JPanel panel, GridBagConstraints gbc, int row, String label, JComponent comp) {
        gbc.gridx = 0; gbc.gridy = row; gbc.gridwidth = 1;
        panel.add(new JLabel(label), gbc);
        gbc.gridx = 1;
        panel.add(comp, gbc);
    }

    private void loadTechnicians(List<Technician> list) {
        tableModel.setRowCount(0);
        for (Technician t : list) {
            tableModel.addRow(new Object[]{
                    t.getTechnicianId(), t.getName(), t.getEmail(),
                    t.getPhone(), t.getSpecialization(), t.getStatus()
            });
        }
    }

    private void handleAddTechnician() {
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        if (name.isEmpty() || !PasswordUtil.isValidEmail(email) || !PasswordUtil.isValidPhone(phone)) return;
        Technician t = new Technician(null, name, email, phone, (String) cmbSpecialization.getSelectedItem(), (String) cmbStatus.getSelectedItem());
        if (technicianDAO.addTechnician(t)) {
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleUpdateTechnician() {
        if (txtTechId.getText().isEmpty()) return;
        int id = Integer.parseInt(txtTechId.getText());
        Technician t = new Technician(id, null, txtName.getText().trim(), txtEmail.getText().trim(),
                txtPhone.getText().trim(), (String) cmbSpecialization.getSelectedItem(), (String) cmbStatus.getSelectedItem(), null);
        if (technicianDAO.updateTechnician(t)) {
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleToggleActive() {
        if (txtTechId.getText().isEmpty()) return;
        int id = Integer.parseInt(txtTechId.getText());
        String current = (String) cmbStatus.getSelectedItem();
        String next = "ACTIVE".equalsIgnoreCase(current) ? "INACTIVE" : "ACTIVE";
        if (technicianDAO.updateTechnicianStatus(id, next)) {
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }

    private void handleDeleteTechnician() {
        if (txtTechId.getText().isEmpty()) return;
        int id = Integer.parseInt(txtTechId.getText());
        if (technicianDAO.deleteTechnician(id)) {
            loadTechnicians(technicianDAO.getAllTechnicians());
            if (onChangeCallback != null) onChangeCallback.run();
        }
    }
}`,
  },
  {
    id: 'project_readme',
    path: 'README.md',
    phase: 'Phase 4',
    language: 'text',
    description: 'Complete README.md with setup instructions, sample login accounts, project structure, and future scope.',
    content: `# IT Help Desk Ticketing and Service Management System Using Java

Course: TY EXTC — Java Programming Micro Project (A.Y. 2026–2027)
Tech Stack: Java 22 · Java Swing · MySQL 8+ · JDBC

## Sample Login Credentials
- Admin: admin@helpdesk.com / Admin@123
- Technician: technician@helpdesk.com / Tech@123
- User: user@helpdesk.com / User@123

## Compile & Run Instructions
javac -cp "lib/mysql-connector-j-8.4.0.jar" -d out src/database/*.java src/model/*.java src/utils/*.java src/dao/*.java src/ui/*.java src/Main.java
java -cp "out:lib/mysql-connector-j-8.4.0.jar" Main`,
  },
];
