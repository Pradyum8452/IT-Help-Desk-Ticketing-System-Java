import React, { useState } from 'react';
import { Phase1Explorer } from './components/Phase1Explorer';
import { SwingSimulator } from './components/SwingSimulator';

export default function App() {
  const [activeView, setActiveView] = useState<'phase1' | 'simulator'>('phase1');

  return (
    <div className="min-h-screen bg-[#F4F7FA] text-[#1F2937] flex flex-col">
      {/* Top Bar Contract: 3 Zones */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between">
        {/* Zone 1: Brand Title */}
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveView('phase1');
          }}
          className="text-lg font-bold tracking-tight text-[#1E3A5F] whitespace-nowrap"
        >
          IT Help Desk System
        </a>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveView('phase1')}
            className={`hover:text-[#1E3A5F] transition-colors whitespace-nowrap ${
              activeView === 'phase1' ? 'text-[#1E3A5F] underline underline-offset-4' : ''
            }`}
          >
            Phase 1 Code & SQL
          </button>
          <button
            onClick={() => setActiveView('simulator')}
            className={`hover:text-[#1E3A5F] transition-colors whitespace-nowrap ${
              activeView === 'simulator' ? 'text-[#1E3A5F] underline underline-offset-4' : ''
            }`}
          >
            Swing GUI Simulator
          </button>
        </nav>

        {/* Zone 3: Primary Action */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveView(activeView === 'phase1' ? 'simulator' : 'phase1')}
            className="px-4 py-2 text-xs font-semibold text-white bg-[#1E3A5F] rounded-lg hover:bg-[#2E6F95] transition-colors whitespace-nowrap"
          >
            {activeView === 'phase1' ? 'Launch Live Swing Demo' : 'View Phase 1 Source Code'}
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-6 py-8">
        {activeView === 'phase1' ? <Phase1Explorer /> : <SwingSimulator />}
      </main>
    </div>
  );
}
