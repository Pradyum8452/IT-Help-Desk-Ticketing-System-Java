import React, { useState } from 'react';
import { PHASE_1_FILES, CodeFileEntry } from '../data/phase1Files';
import { PHASE_2_FILES } from '../data/phase2Files';
import { PHASE_3_FILES } from '../data/phase3Files';
import { PHASE_4_FILES } from '../data/phase4Files';
import { Copy, Check, Download, Database, FolderTree, Layers, Terminal, FileText } from 'lucide-react';

const REPORT_SECTIONS = [
  { num: '1. Title', body: 'IT Help Desk Ticketing and Service Management System Using Java (TY EXTC Java Programming Micro Project, A.Y. 2026–2027).' },
  { num: '2. Abstract', body: 'A role-based desktop application built with Java 22, Java Swing, JDBC, and MySQL 8+ that streamlines technical support ticket logging, technician assignment, status tracking, chronological audit logging, and SQL aggregate reporting.' },
  { num: '3. Introduction', body: 'Provides a single point of contact between employees (USER), support specialists (TECHNICIAN), and system administrators (ADMIN) using a 3-Tier Object-Oriented Java architecture.' },
  { num: '4. Problem Statement', body: 'Manual paper registers and informal emails lead to lost support requests, zero visibility into resolution progress, and unbalanced technician workloads.' },
  { num: '5. Objectives', body: 'Implement role-based dashboards, SHA-256 password hashing, auto-generated Ticket IDs (HD-2026-0001), 5-stage workflow tracking, and SQL aggregate reports with CSV export.' },
  { num: '6. Scope', body: 'Supports Hardware, Software, Network, Printer, Email, Account/Login, and Other categories across Low, Medium, High, and Critical priorities.' },
  { num: '7. Existing System', body: 'Unstructured spreadsheet or verbal complaint logging without automated ticket IDs, audit history, or active-technician validation.' },
  { num: '8. Proposed System', body: 'Centralized MySQL 8+ helpdesk_db with JDBC PreparedStatements, role-based Swing dashboards, visual status pipeline, and chronological ticket_history.' },
  { num: '9. Hardware Requirements', body: 'Intel Core i3 / Ryzen 3 (2.0 GHz+), 4 GB RAM minimum (8 GB recommended), 500 MB free disk space, 1366×768 or 1920×1080 display.' },
  { num: '10. Software Requirements', body: 'Windows 10/11 or Linux/macOS, JDK 22, Java Swing, MySQL Server 8.0+, MySQL Connector/J 8.4+, VS Code / IntelliJ IDEA / Eclipse.' },
  { num: '11. System Architecture', body: '3-Tier Layered Architecture: Presentation Layer (package ui) -> Utility & DAO Layer (package utils, dao, model) -> MySQL Database Layer (package database).' },
  { num: '12. Modules', body: '1) Authentication & Session Module, 2) User Ticket & Tracker Module, 3) Admin CRUD & Assignment Module, 4) Technician Resolution Module, 5) Audit History & CSV Reporting Module.' },
  { num: '13. Database Design', body: 'Four normalized InnoDB tables in helpdesk_db: users (PK: user_id), technicians (PK: technician_id), tickets (PK: ticket_id), and ticket_history (PK: history_id).' },
  { num: '14. ER Diagram Description', body: 'users (1:N) tickets; technicians (1:N) tickets; tickets (1:N) ticket_history; users (1:0..1) technicians.' },
  { num: '15. DFD Level 0 Description', body: 'Context diagram connecting User, Technician, and Admin external entities to Process 0.0 (IT Help Desk System).' },
  { num: '16. DFD Level 1 Description', body: 'Five sub-processes: 1.0 Authenticate, 2.0 Create & Track Ticket, 3.0 Manage Users/Techs, 4.0 Assign & Resolve Ticket, 5.0 Generate Reports across data stores D1–D4.' },
  { num: '17. UML Use Case Description', body: 'Actors: User (Create Ticket, My Tickets, Track Status, Confirm Resolution), Technician (Accept Ticket, Add Resolution, Close Ticket), Admin (Manage Users/Techs, Assign Tech, Update Status, Export CSV).' },
  { num: '18. Class Diagram Description', body: 'Encapsulated POJOs (User, Technician, Ticket, TicketHistory), JDBC DAOs (UserDAO, TechnicianDAO, TicketDAO, TicketHistoryDAO), Utilities (DBConnection, PasswordUtil, TicketIDGenerator, SessionManager), and 11 JFrame UI classes.' },
  { num: '19. Flowchart Description', body: 'Start -> Main -> LoginFrame -> SHA-256 Verification -> Role Router -> [AdminDashboard | TechnicianDashboard | UserDashboard] -> CRUD/Workflow -> Logout -> End.' },
  { num: '20. Testing', body: 'Verified positive/negative test cases for SHA-256 login, duplicate email prevention, inactive technician blocking, sequential HD-2026-XXXX generation, and status transitions.' },
  { num: '21. Advantages', body: 'SQL-injection safe (PreparedStatements), SHA-256 password security, full auditability via ticket_history, and clean framework-free Java 22 OOP structure.' },
  { num: '22. Limitations', body: 'Requires active MySQL 8+ server connectivity; does not send external SMTP emails out of the box.' },
  { num: '23. Future Scope', body: 'JavaMail SMTP integration, automated SLA escalation alerts, and screenshot file attachments.' },
  { num: '24. Conclusion', body: 'Successfully fulfills all requirements of the TY EXTC Java Programming Microproject using Java 22, Swing, JDBC, and MySQL 8+.' },
];

export const Phase1Explorer: React.FC = () => {
  const allCodeFiles = [...PHASE_4_FILES, ...PHASE_3_FILES, ...PHASE_2_FILES, ...PHASE_1_FILES];
  const [selectedPhaseFilter, setSelectedPhaseFilter] = useState<'ALL' | 'Phase 1' | 'Phase 2' | 'Phase 3' | 'Phase 4'>('Phase 4');
  const [selectedFile, setSelectedFile] = useState<CodeFileEntry>(PHASE_4_FILES[0]);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [activeSubTab, setActiveSubTab] = useState<'code' | 'report' | 'architecture' | 'er' | 'jdbc'>('code');

  const visibleFiles = allCodeFiles.filter(
    (f) => selectedPhaseFilter === 'ALL' || f.phase === selectedPhaseFilter
  );

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  const handleDownload = (file: CodeFileEntry) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = file.path.split('/').pop() || 'file.txt';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Header & Segmented Control */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <h2 className="text-xl font-semibold text-[#1E3A5F]">
            Complete Java 22 Project Repository (Phases 1–4) & 24-Section College Report
          </h2>
          <p className="text-sm text-slate-600 mt-0.5">
            TY EXTC Java Programming Microproject (A.Y. 2026–2027) · All 25 Files Completed
          </p>
        </div>
        <div className="flex items-center gap-1 p-1 bg-slate-200/75 rounded-lg">
          <button
            onClick={() => setActiveSubTab('code')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeSubTab === 'code' ? 'bg-[#1E3A5F] text-white' : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            All Project Files ({allCodeFiles.length})
          </button>
          <button
            onClick={() => setActiveSubTab('report')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeSubTab === 'report' ? 'bg-[#1E3A5F] text-white' : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            24-Section College Report
          </button>
          <button
            onClick={() => setActiveSubTab('architecture')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeSubTab === 'architecture' ? 'bg-[#1E3A5F] text-white' : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            Architecture & Folder Tree
          </button>
          <button
            onClick={() => setActiveSubTab('er')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeSubTab === 'er' ? 'bg-[#1E3A5F] text-white' : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            Database ER Design
          </button>
          <button
            onClick={() => setActiveSubTab('jdbc')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap ${
              activeSubTab === 'jdbc' ? 'bg-[#1E3A5F] text-white' : 'text-slate-700 hover:text-slate-900'
            }`}
          >
            JDBC Setup Guide
          </button>
        </div>
      </div>

      {activeSubTab === 'code' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* File list sidebar */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center justify-between px-1">
              <span className="text-xs font-semibold text-slate-600">Filter by Phase</span>
              <div className="flex gap-1 bg-slate-200/75 p-0.5 rounded-md">
                {(['Phase 4', 'Phase 3', 'Phase 2', 'Phase 1', 'ALL'] as const).map((phase) => (
                  <button
                    key={phase}
                    onClick={() => {
                      setSelectedPhaseFilter(phase);
                      if (phase === 'Phase 4') setSelectedFile(PHASE_4_FILES[0]);
                      else if (phase === 'Phase 3') setSelectedFile(PHASE_3_FILES[0]);
                      else if (phase === 'Phase 2') setSelectedFile(PHASE_2_FILES[0]);
                      else if (phase === 'Phase 1') setSelectedFile(PHASE_1_FILES[0]);
                    }}
                    className={`px-2 py-1 text-xs font-medium rounded transition-colors ${
                      selectedPhaseFilter === phase
                        ? 'bg-[#1E3A5F] text-white'
                        : 'text-slate-700 hover:text-slate-900'
                    }`}
                  >
                    {phase}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2 max-h-[560px] overflow-y-auto pr-1">
              {visibleFiles.map((file) => {
                const isSelected = file.id === selectedFile.id;
                return (
                  <button
                    key={file.id}
                    onClick={() => setSelectedFile(file)}
                    className={`w-full text-left p-3.5 rounded-lg border transition-colors ${
                      isSelected
                        ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                        : 'bg-white text-slate-800 border-slate-200 hover:border-[#2E6F95]'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono text-xs font-semibold truncate">{file.path}</span>
                      <span
                        className={`text-[11px] font-mono shrink-0 ${
                          isSelected ? 'text-[#00A8E8]' : 'text-slate-400'
                        }`}
                      >
                        {file.phase}
                      </span>
                    </div>
                    <div
                      className={`text-xs mt-1 line-clamp-2 ${
                        isSelected ? 'text-slate-200' : 'text-slate-500'
                      }`}
                    >
                      {file.description}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Code viewer */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-lg overflow-hidden flex flex-col">
            <div className="flex items-center justify-between px-4 py-3 bg-slate-900 text-slate-100 border-b border-slate-800">
              <div>
                <span className="font-mono text-xs text-[#00A8E8]">
                  {selectedFile.path} · {selectedFile.phase}
                </span>
                <p className="text-xs text-slate-400 mt-0.5">{selectedFile.description}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleCopy(selectedFile.content, selectedFile.id)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-100 rounded transition-colors whitespace-nowrap"
                >
                  {copiedId === selectedFile.id ? (
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  {copiedId === selectedFile.id ? 'Copied' : 'Copy Code'}
                </button>
                <button
                  onClick={() => handleDownload(selectedFile)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium bg-[#00A8E8] hover:bg-[#0284c7] text-white rounded transition-colors whitespace-nowrap"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download
                </button>
              </div>
            </div>
            <pre className="p-4 text-xs font-mono leading-relaxed overflow-x-auto bg-slate-950 text-slate-100 max-h-[600px] overflow-y-auto">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      )}

      {activeSubTab === 'report' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 pb-3">
            <div className="flex items-center gap-2 text-[#1E3A5F] font-semibold">
              <FileText className="w-5 h-5" />
              <h3>TY EXTC College Microproject Report (All 24 Sections)</h3>
            </div>
            <span className="text-xs text-slate-500 font-mono">Saved in java_project/PROJECT_REPORT.md</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {REPORT_SECTIONS.map((sec) => (
              <div key={sec.num} className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-xs font-bold text-[#1E3A5F]">{sec.num}</div>
                <p className="text-xs text-slate-700 mt-1 leading-relaxed">{sec.body}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'architecture' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
            <div className="flex items-center gap-2 text-[#1E3A5F] font-semibold">
              <Layers className="w-5 h-5" />
              <h3>3-Tier Layered MVC / DAO Architecture</h3>
            </div>
            <div className="space-y-3 pt-2">
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-xs font-semibold text-[#1E3A5F]">1. Presentation Layer (package ui + Main.java) — Completed in Phases 3 & 4</div>
                <div className="text-xs text-slate-600 mt-1">
                  Main, LoginFrame, AdminDashboard, TechnicianDashboard, UserDashboard, CreateTicketFrame, MyTicketsFrame, ManageUsersFrame, ManageTechniciansFrame, ManageTicketsFrame, TicketDetailsFrame, TicketHistoryFrame.
                </div>
              </div>
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-xs font-semibold text-[#1E3A5F]">2. Utility & Security Layer (package utils) — Completed in Phase 2</div>
                <div className="text-xs text-slate-600 mt-1">
                  PasswordUtil (SHA-256 hashing & input validators), TicketIDGenerator (auto-generates HD-2026-XXXX IDs), SessionManager.
                </div>
              </div>
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-xs font-semibold text-[#1E3A5F]">3. Data Access Layer (package dao) — Completed in Phase 2</div>
                <div className="text-xs text-slate-600 mt-1">
                  UserDAO, TechnicianDAO, TicketDAO, TicketHistoryDAO using parameterized PreparedStatements.
                </div>
              </div>
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                <div className="text-xs font-semibold text-[#1E3A5F]">4. Model & Database Layer (package model & database) — Completed in Phase 1</div>
                <div className="text-xs text-slate-600 mt-1">
                  Encapsulated POJOs (User, Technician, Ticket, TicketHistory) and DBConnection connecting to MySQL 8+ helpdesk_db.
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
            <div className="flex items-center gap-2 text-[#1E3A5F] font-semibold">
              <FolderTree className="w-5 h-5" />
              <h3>Complete Java Project Folder Structure (All Phases Complete)</h3>
            </div>
            <pre className="p-4 bg-slate-950 text-slate-100 rounded-lg font-mono text-xs leading-relaxed overflow-x-auto">
{`ITHelpDeskSystem/
├── database/
│   └── helpdesk.sql                   [Completed - Phase 1]
├── lib/
│   └── mysql-connector-j-8.4.0.jar
├── src/
│   ├── Main.java                      [Completed - Phase 4]
│   ├── database/
│   │   └── DBConnection.java          [Completed - Phase 1]
│   ├── model/
│   │   ├── User.java                  [Completed - Phase 1]
│   │   ├── Technician.java            [Completed - Phase 1]
│   │   ├── Ticket.java                [Completed - Phase 1]
│   │   └── TicketHistory.java         [Completed - Phase 1]
│   ├── utils/
│   │   ├── PasswordUtil.java          [Completed - Phase 2]
│   │   ├── TicketIDGenerator.java     [Completed - Phase 2]
│   │   └── SessionManager.java        [Completed - Phase 2]
│   ├── dao/
│   │   ├── UserDAO.java               [Completed - Phase 2]
│   │   ├── TechnicianDAO.java         [Completed - Phase 2]
│   │   ├── TicketDAO.java             [Completed - Phase 2]
│   │   └── TicketHistoryDAO.java      [Completed - Phase 2]
│   └── ui/
│       ├── LoginFrame.java            [Completed - Phase 3]
│       ├── UserDashboard.java         [Completed - Phase 3]
│       ├── CreateTicketFrame.java     [Completed - Phase 3]
│       ├── MyTicketsFrame.java        [Completed - Phase 3]
│       ├── TicketDetailsFrame.java    [Completed - Phase 3]
│       ├── TicketHistoryFrame.java    [Completed - Phase 3]
│       ├── AdminDashboard.java        [Completed - Phase 4]
│       ├── ManageUsersFrame.java      [Completed - Phase 4]
│       ├── ManageTechniciansFrame.java[Completed - Phase 4]
│       ├── ManageTicketsFrame.java    [Completed - Phase 4]
│       └── TechnicianDashboard.java   [Completed - Phase 4]
├── README.md                          [Completed - Phase 4]
└── PROJECT_REPORT.md                  [Completed - Phase 4]`}
            </pre>
          </div>
        </div>
      )}

      {activeSubTab === 'er' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-5">
          <div className="flex items-center gap-2 text-[#1E3A5F] font-semibold">
            <Database className="w-5 h-5" />
            <h3>Entity-Relationship (ER) Schema & Cardinality</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="font-mono text-xs font-bold text-[#1E3A5F] border-b border-slate-200 pb-2 mb-2">
                1. users (PK: user_id)
              </div>
              <ul className="font-mono text-xs text-slate-700 space-y-1">
                <li>user_id INT PK AUTO_INCREMENT</li>
                <li>name VARCHAR(100) NOT NULL</li>
                <li>email VARCHAR(100) UNIQUE</li>
                <li>phone VARCHAR(20) NOT NULL</li>
                <li>department VARCHAR(80)</li>
                <li>username VARCHAR(50) UNIQUE</li>
                <li>password VARCHAR(64) SHA-256</li>
                <li>role ENUM(ADMIN,TECH,USER)</li>
                <li>status ENUM(ACTIVE,INACTIVE)</li>
                <li>created_at DATETIME</li>
              </ul>
            </div>

            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="font-mono text-xs font-bold text-[#1E3A5F] border-b border-slate-200 pb-2 mb-2">
                2. technicians (PK: technician_id)
              </div>
              <ul className="font-mono text-xs text-slate-700 space-y-1">
                <li>technician_id INT PK</li>
                <li>user_id INT FK UNIQUE NULL</li>
                <li>name VARCHAR(100) NOT NULL</li>
                <li>email VARCHAR(100) UNIQUE</li>
                <li>phone VARCHAR(20) NOT NULL</li>
                <li>specialization ENUM(...)</li>
                <li>status ENUM(ACTIVE,INACTIVE)</li>
                <li>created_at DATETIME</li>
              </ul>
            </div>

            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="font-mono text-xs font-bold text-[#1E3A5F] border-b border-slate-200 pb-2 mb-2">
                3. tickets (PK: ticket_id)
              </div>
              <ul className="font-mono text-xs text-slate-700 space-y-1">
                <li>ticket_id VARCHAR(20) PK</li>
                <li>subject VARCHAR(200)</li>
                <li>description TEXT</li>
                <li>category ENUM(...)</li>
                <li>priority ENUM(Low..Critical)</li>
                <li>status ENUM(OPEN..CLOSED)</li>
                <li>user_id INT FK (users)</li>
                <li>technician_id INT FK NULL</li>
                <li>resolution_details TEXT NULL</li>
                <li>created_at / updated_at</li>
                <li>resolved_at DATETIME NULL</li>
              </ul>
            </div>

            <div className="border border-slate-200 rounded-lg p-4 bg-slate-50">
              <div className="font-mono text-xs font-bold text-[#1E3A5F] border-b border-slate-200 pb-2 mb-2">
                4. ticket_history (PK: history_id)
              </div>
              <ul className="font-mono text-xs text-slate-700 space-y-1">
                <li>history_id INT PK</li>
                <li>ticket_id VARCHAR(20) FK</li>
                <li>previous_status VARCHAR(30)</li>
                <li>new_status ENUM(...)</li>
                <li>changed_by INT FK (users)</li>
                <li>change_description TEXT</li>
                <li>changed_at DATETIME</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'jdbc' && (
        <div className="bg-white border border-slate-200 rounded-lg p-6 space-y-4">
          <div className="flex items-center gap-2 text-[#1E3A5F] font-semibold">
            <Terminal className="w-5 h-5" />
            <h3>JDBC Driver Setup & Compilation Instructions (Java 22 + MySQL 8+)</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-700">
            <div className="p-4 border border-slate-200 rounded-lg space-y-2">
              <div className="font-semibold text-[#1E3A5F] text-sm">VS Code Setup</div>
              <p>1. Install Extension Pack for Java.</p>
              <p>2. Place <code className="font-mono bg-slate-100 px-1">mysql-connector-j-8.4.0.jar</code> inside the <code className="font-mono bg-slate-100 px-1">lib/</code> folder.</p>
              <p>3. In Java Projects sidebar → Referenced Libraries → click <code className="font-mono">+</code> and select the JAR file.</p>
            </div>
            <div className="p-4 border border-slate-200 rounded-lg space-y-2">
              <div className="font-semibold text-[#1E3A5F] text-sm">IntelliJ IDEA Setup</div>
              <p>1. Open Project → File → Project Structure (<code className="font-mono">Ctrl+Alt+Shift+S</code>).</p>
              <p>2. Set Project SDK to <strong>Java 22</strong>.</p>
              <p>3. Go to Libraries → <code className="font-mono">+</code> → Java → select <code className="font-mono">mysql-connector-j-8.4.0.jar</code> → Apply.</p>
            </div>
            <div className="p-4 border border-slate-200 rounded-lg space-y-2">
              <div className="font-semibold text-[#1E3A5F] text-sm">Eclipse IDE Setup</div>
              <p>1. Right-click Project → Build Path → Configure Build Path.</p>
              <p>2. Select Libraries tab → Click <strong>Classpath</strong> → Add External JARs.</p>
              <p>3. Select <code className="font-mono">mysql-connector-j-8.4.0.jar</code> → Apply and Close.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
