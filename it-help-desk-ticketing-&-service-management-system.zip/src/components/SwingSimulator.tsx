import React, { useState } from 'react';
import {
  INITIAL_USERS,
  INITIAL_TECHNICIANS,
  INITIAL_TICKETS,
  INITIAL_HISTORY,
  UserModel,
  TechnicianModel,
  TicketModel,
  TicketHistoryModel,
  TicketCategory,
  TicketPriority,
  TicketStatus,
  Specialization,
  sha256Hex,
} from '../data/initialData';

const CATEGORIES: TicketCategory[] = ['Hardware', 'Software', 'Network', 'Printer', 'Email', 'Account/Login', 'Other'];
const PRIORITIES: TicketPriority[] = ['Low', 'Medium', 'High', 'Critical'];
const STATUSES: TicketStatus[] = ['OPEN', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'];
const SPECIALIZATIONS: Specialization[] = ['Hardware', 'Software', 'Network', 'Database', 'General Support'];

export const SwingSimulator: React.FC = () => {
  const [users, setUsers] = useState<UserModel[]>(INITIAL_USERS);
  const [technicians, setTechnicians] = useState<TechnicianModel[]>(INITIAL_TECHNICIANS);
  const [tickets, setTickets] = useState<TicketModel[]>(INITIAL_TICKETS);
  const [history, setHistory] = useState<TicketHistoryModel[]>(INITIAL_HISTORY);

  const [currentUser, setCurrentUser] = useState<UserModel | null>(null);
  const [loginInput, setLoginInput] = useState('admin@helpdesk.com');
  const [passwordInput, setPasswordInput] = useState('Admin@123');
  const [dialogMsg, setDialogMsg] = useState<{ title: string; text: string; type: 'info' | 'error' } | null>(null);

  // Navigation inside role dashboards
  const [adminTab, setAdminTab] = useState<'dashboard' | 'tickets' | 'assign' | 'users' | 'technicians' | 'history' | 'reports'>('dashboard');
  const [userTab, setUserTab] = useState<'dashboard' | 'create' | 'mytickets' | 'track' | 'profile'>('dashboard');
  const [techTab, setTechTab] = useState<'dashboard' | 'resolve'>('dashboard');

  // Filter states
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [priorityFilter, setPriorityFilter] = useState<string>('ALL');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');

  // Create Ticket Form
  const [newSubject, setNewSubject] = useState('');
  const [newCategory, setNewCategory] = useState<TicketCategory>('Hardware');
  const [newPriority, setNewPriority] = useState<TicketPriority>('Medium');
  const [newDesc, setNewDesc] = useState('');

  // Assign Technician Form
  const [selectedOpenTicketId, setSelectedOpenTicketId] = useState<string>('HD-2026-0003');
  const [selectedTechId, setSelectedTechId] = useState<number>(1);

  // Track Ticket
  const [trackTicketId, setTrackTicketId] = useState('HD-2026-0001');

  // Technician Resolution Form
  const [resolveTicketId, setResolveTicketId] = useState('HD-2026-0001');
  const [resolutionText, setResolutionText] = useState('');

  // Manage User Form
  const [uName, setUName] = useState('');
  const [uEmail, setUEmail] = useState('');
  const [uPhone, setUPhone] = useState('');
  const [uDept, setUDept] = useState('');
  const [uUsername, setUUsername] = useState('');
  const [uRole, setURole] = useState<'ADMIN' | 'TECHNICIAN' | 'USER'>('USER');

  // Manage Technician Form
  const [tName, setTName] = useState('');
  const [tEmail, setTEmail] = useState('');
  const [tPhone, setTPhone] = useState('');
  const [tSpec, setTSpec] = useState<Specialization>('Hardware');

  const nowStr = () => new Date().toISOString().slice(0, 19).replace('T', ' ');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginInput.trim() || !passwordInput.trim()) {
      setDialogMsg({ title: 'Validation Error', text: 'Email/Username and Password cannot be empty.', type: 'error' });
      return;
    }
    const found = users.find(
      (u) => u.email.toLowerCase() === loginInput.trim().toLowerCase() || u.username.toLowerCase() === loginInput.trim().toLowerCase()
    );
    if (!found) {
      setDialogMsg({ title: 'Authentication Failed', text: 'Invalid username or email. Account not found in MySQL.', type: 'error' });
      return;
    }
    const inputHash = await sha256Hex(passwordInput);
    if (inputHash !== found.passwordHash) {
      setDialogMsg({ title: 'Authentication Failed', text: 'Invalid password (SHA-256 hash mismatch).', type: 'error' });
      return;
    }
    if (found.status !== 'ACTIVE') {
      setDialogMsg({ title: 'Account Inactive', text: 'Your account is currently INACTIVE. Contact System Administrator.', type: 'error' });
      return;
    }
    setCurrentUser(found);
  };

  const quickFillLogin = (email: string, pass: string) => {
    setLoginInput(email);
    setPasswordInput(pass);
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!newSubject.trim() || !newDesc.trim()) {
      setDialogMsg({ title: 'Input Validation', text: 'Please fill in both Subject and Problem Description.', type: 'error' });
      return;
    }
    const nextNum = tickets.length + 1;
    const generatedId = `HD-2026-${String(nextNum).padStart(4, '0')}`;
    const timestamp = nowStr();
    const created: TicketModel = {
      ticketId: generatedId,
      subject: newSubject.trim(),
      description: newDesc.trim(),
      category: newCategory,
      priority: newPriority,
      status: 'OPEN',
      userId: currentUser.userId,
      technicianId: null,
      resolutionDetails: null,
      createdAt: timestamp,
      updatedAt: timestamp,
      resolvedAt: null,
    };
    setTickets([created, ...tickets]);
    setHistory([
      ...history,
      {
        historyId: history.length + 1,
        ticketId: generatedId,
        previousStatus: null,
        newStatus: 'OPEN',
        changedBy: currentUser.userId,
        changeDescription: `Ticket created by ${currentUser.name} (Priority: ${newPriority}).`,
        changedAt: timestamp,
      },
    ]);
    setNewSubject('');
    setNewDesc('');
    setTrackTicketId(generatedId);
    setDialogMsg({
      title: 'Ticket Created Successfully',
      text: `Ticket inserted into MySQL helpdesk_db.\nGenerated Ticket ID: ${generatedId}\nInitial Status: OPEN`,
      type: 'info',
    });
  };

  const handleAssignTechnician = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    const tech = technicians.find((t) => t.technicianId === selectedTechId);
    if (!tech || tech.status !== 'ACTIVE') {
      setDialogMsg({ title: 'Assignment Blocked', text: 'Cannot assign an INACTIVE technician.', type: 'error' });
      return;
    }
    const target = tickets.find((t) => t.ticketId === selectedOpenTicketId);
    if (!target) {
      setDialogMsg({ title: 'Invalid Ticket', text: 'Please select a valid ticket to assign.', type: 'error' });
      return;
    }
    const timestamp = nowStr();
    setTickets(
      tickets.map((t) =>
        t.ticketId === target.ticketId
          ? { ...t, technicianId: tech.technicianId, status: 'ASSIGNED', updatedAt: timestamp }
          : t
      )
    );
    setHistory([
      ...history,
      {
        historyId: history.length + 1,
        ticketId: target.ticketId,
        previousStatus: target.status,
        newStatus: 'ASSIGNED',
        changedBy: currentUser.userId,
        changeDescription: `Assigned to Technician ${tech.name} (${tech.specialization}) by Admin.`,
        changedAt: timestamp,
      },
    ]);
    setDialogMsg({
      title: 'Technician Assigned',
      text: `Ticket ${target.ticketId} assigned to ${tech.name}. Status updated to ASSIGNED.`,
      type: 'info',
    });
  };

  const handleTechStatusUpdate = (ticketId: string, nextStatus: TicketStatus, note: string) => {
    if (!currentUser) return;
    const target = tickets.find((t) => t.ticketId === ticketId);
    if (!target) return;
    const timestamp = nowStr();
    setTickets(
      tickets.map((t) =>
        t.ticketId === ticketId
          ? {
              ...t,
              status: nextStatus,
              updatedAt: timestamp,
              resolvedAt: nextStatus === 'RESOLVED' ? timestamp : t.resolvedAt,
            }
          : t
      )
    );
    setHistory([
      ...history,
      {
        historyId: history.length + 1,
        ticketId,
        previousStatus: target.status,
        newStatus: nextStatus,
        changedBy: currentUser.userId,
        changeDescription: note,
        changedAt: timestamp,
      },
    ]);
    setDialogMsg({
      title: 'Status Updated',
      text: `Ticket ${ticketId} status changed from ${target.status} to ${nextStatus}.`,
      type: 'info',
    });
  };

  const handleResolveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!resolutionText.trim()) {
      setDialogMsg({ title: 'Validation Error', text: 'Resolution Details cannot be empty.', type: 'error' });
      return;
    }
    const target = tickets.find((t) => t.ticketId === resolveTicketId);
    if (!target) return;
    const timestamp = nowStr();
    setTickets(
      tickets.map((t) =>
        t.ticketId === resolveTicketId
          ? {
              ...t,
              status: 'RESOLVED',
              resolutionDetails: resolutionText.trim(),
              updatedAt: timestamp,
              resolvedAt: timestamp,
            }
          : t
      )
    );
    setHistory([
      ...history,
      {
        historyId: history.length + 1,
        ticketId: resolveTicketId,
        previousStatus: target.status,
        newStatus: 'RESOLVED',
        changedBy: currentUser.userId,
        changeDescription: `Resolved by ${currentUser.name}: ${resolutionText.trim()}`,
        changedAt: timestamp,
      },
    ]);
    setResolutionText('');
    setDialogMsg({
      title: 'Ticket Resolved',
      text: `Ticket ${resolveTicketId} marked as RESOLVED and logged to ticket_history.`,
      type: 'info',
    });
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uName.trim() || !uEmail.trim() || !uPhone.trim() || !uUsername.trim()) {
      setDialogMsg({ title: 'Validation Error', text: 'All user fields are required.', type: 'error' });
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(uEmail.trim())) {
      setDialogMsg({ title: 'Validation Error', text: 'Invalid email address format.', type: 'error' });
      return;
    }
    if (users.some((u) => u.email.toLowerCase() === uEmail.trim().toLowerCase())) {
      setDialogMsg({ title: 'Duplicate Email', text: 'A user with this email already exists in MySQL.', type: 'error' });
      return;
    }
    const hash = await sha256Hex('User@123');
    const newUser: UserModel = {
      userId: users.length + 1,
      name: uName.trim(),
      email: uEmail.trim(),
      phone: uPhone.trim(),
      department: uDept.trim() || 'General',
      username: uUsername.trim(),
      passwordHash: hash,
      role: uRole,
      status: 'ACTIVE',
      createdAt: nowStr(),
    };
    setUsers([...users, newUser]);
    setUName('');
    setUEmail('');
    setUPhone('');
    setUDept('');
    setUUsername('');
    setDialogMsg({ title: 'User Added', text: `User ${newUser.name} inserted into users table.`, type: 'info' });
  };

  const handleAddTechnician = (e: React.FormEvent) => {
    e.preventDefault();
    if (!tName.trim() || !tEmail.trim() || !tPhone.trim()) {
      setDialogMsg({ title: 'Validation Error', text: 'Name, Email, and Phone are required.', type: 'error' });
      return;
    }
    const newTech: TechnicianModel = {
      technicianId: technicians.length + 1,
      userId: null,
      name: tName.trim(),
      email: tEmail.trim(),
      phone: tPhone.trim(),
      specialization: tSpec,
      status: 'ACTIVE',
      createdAt: nowStr(),
    };
    setTechnicians([...technicians, newTech]);
    setTName('');
    setTEmail('');
    setTPhone('');
    setDialogMsg({ title: 'Technician Added', text: `Technician ${newTech.name} added to technicians table.`, type: 'info' });
  };

  const toggleTechStatus = (id: number) => {
    setTechnicians(
      technicians.map((t) =>
        t.technicianId === id ? { ...t, status: t.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE' } : t
      )
    );
  };

  const exportReportsCsv = () => {
    const headers = 'Ticket ID,Subject,Category,Priority,Status,User,Technician,Created Date\n';
    const rows = tickets
      .map((t) => {
        const u = users.find((x) => x.userId === t.userId)?.name || '';
        const tech = technicians.find((x) => x.technicianId === t.technicianId)?.name || 'Unassigned';
        return `"${t.ticketId}","${t.subject}","${t.category}","${t.priority}","${t.status}","${u}","${tech}","${t.createdAt}"`;
      })
      .join('\n');
    const blob = new Blob([headers + rows], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'helpdesk_report_2026.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const getUserName = (id: number) => users.find((u) => u.userId === id)?.name || `User #${id}`;
  const getTechName = (id: number | null) =>
    id ? technicians.find((t) => t.technicianId === id)?.name || `Tech #${id}` : 'Unassigned';

  const filteredTickets = tickets.filter((t) => {
    const matchesSearch =
      t.ticketId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.subject.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
    const matchesPriority = priorityFilter === 'ALL' || t.priority === priorityFilter;
    const matchesCategory = categoryFilter === 'ALL' || t.category === categoryFilter;
    return matchesSearch && matchesStatus && matchesPriority && matchesCategory;
  });

  const currentTechObj = currentUser
    ? technicians.find((t) => t.userId === currentUser.userId || t.email === currentUser.email)
    : null;

  return (
    <div className="border-2 border-[#1E3A5F] rounded-lg overflow-hidden shadow-sm bg-[#F4F7FA]">
      {/* Swing JFrame Window Title Bar */}
      <div className="bg-[#1E3A5F] text-white px-4 py-2.5 flex items-center justify-between border-b border-slate-700">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-400 inline-block" />
            <span className="w-3 h-3 rounded-full bg-amber-400 inline-block" />
            <span className="w-3 h-3 rounded-full bg-emerald-400 inline-block" />
          </div>
          <span className="text-xs font-mono font-semibold tracking-tight ml-2">
            javax.swing.JFrame — IT Help Desk Ticketing & Service Management System (Java 22 + MySQL 8)
          </span>
        </div>
        <div className="text-xs font-mono text-slate-300">
          {currentUser ? `Session: ${currentUser.name} [${currentUser.role}]` : 'Not Authenticated'}
        </div>
      </div>

      {/* JOptionPane Modal Overlay */}
      {dialogMsg && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
          <div className="bg-white border-2 border-[#1E3A5F] rounded-lg max-w-md w-full overflow-hidden shadow-lg">
            <div className="bg-[#1E3A5F] text-white px-4 py-2 text-xs font-semibold flex justify-between items-center">
              <span>JOptionPane — {dialogMsg.title}</span>
              <button onClick={() => setDialogMsg(null)} className="text-slate-300 hover:text-white">✕</button>
            </div>
            <div className="p-5 space-y-4">
              <p className="text-sm text-[#1F2937] whitespace-pre-line">{dialogMsg.text}</p>
              <div className="flex justify-end">
                <button
                  onClick={() => setDialogMsg(null)}
                  className="px-4 py-1.5 bg-[#1E3A5F] text-white text-xs font-semibold rounded hover:bg-[#2E6F95]"
                >
                  OK
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LOGIN SCREEN */}
      {!currentUser ? (
        <div className="p-8 max-w-xl mx-auto my-6 bg-white border border-slate-200 rounded-lg">
          <div className="border-b border-slate-200 pb-4 mb-6">
            <h2 className="text-xl font-bold text-[#1E3A5F]">IT Help Desk Login (LoginFrame.java)</h2>
            <p className="text-xs text-slate-600 mt-1">
              Authenticates against MySQL <code className="font-mono">helpdesk_db.users</code> using SHA-256 password verification.
            </p>
          </div>

          {/* Sample Credential Buttons */}
          <div className="mb-5 p-3 bg-[#F4F7FA] border border-slate-200 rounded-lg">
            <div className="text-xs font-semibold text-[#1E3A5F] mb-2">
              Quick Fill Sample Credentials (from database/helpdesk.sql):
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => quickFillLogin('admin@helpdesk.com', 'Admin@123')}
                className="px-3 py-1.5 text-xs font-medium bg-[#1E3A5F] text-white rounded hover:bg-[#2E6F95]"
              >
                Admin (admin@helpdesk.com)
              </button>
              <button
                type="button"
                onClick={() => quickFillLogin('technician@helpdesk.com', 'Tech@123')}
                className="px-3 py-1.5 text-xs font-medium bg-[#2E6F95] text-white rounded hover:bg-[#1E3A5F]"
              >
                Technician (technician@helpdesk.com)
              </button>
              <button
                type="button"
                onClick={() => quickFillLogin('user@helpdesk.com', 'User@123')}
                className="px-3 py-1.5 text-xs font-medium bg-[#00A8E8] text-white rounded hover:bg-[#2E6F95]"
              >
                User (user@helpdesk.com)
              </button>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-[#1F2937] mb-1">Email or Username</label>
              <input
                type="text"
                value={loginInput}
                onChange={(e) => setLoginInput(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded focus:outline-none focus:border-[#00A8E8]"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-[#1F2937] mb-1">Password</label>
              <input
                type="password"
                value={passwordInput}
                onChange={(e) => setPasswordInput(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded focus:outline-none focus:border-[#00A8E8]"
              />
            </div>
            <div className="flex items-center gap-3 pt-2">
              <button
                type="submit"
                className="px-5 py-2 bg-[#1E3A5F] text-white text-xs font-semibold rounded hover:bg-[#2E6F95]"
              >
                Login
              </button>
              <button
                type="button"
                onClick={() => {
                  setLoginInput('');
                  setPasswordInput('');
                }}
                className="px-4 py-2 bg-slate-200 text-slate-800 text-xs font-semibold rounded hover:bg-slate-300"
              >
                Clear
              </button>
            </div>
          </form>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 min-h-[560px]">
          {/* LEFT SIDEBAR MENU */}
          <div className="md:col-span-3 bg-[#1E3A5F] text-white p-4 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="border-b border-slate-600 pb-3">
                <div className="text-xs text-[#00A8E8] font-mono">{currentUser.role} PORTAL</div>
                <div className="text-sm font-bold mt-0.5">{currentUser.name}</div>
                <div className="text-xs text-slate-300">{currentUser.email}</div>
              </div>

              {currentUser.role === 'ADMIN' && (
                <nav className="space-y-1">
                  {[
                    { id: 'dashboard', label: '1. Dashboard' },
                    { id: 'users', label: '2. Manage Users' },
                    { id: 'technicians', label: '3. Manage Technicians' },
                    { id: 'tickets', label: '4. All Tickets' },
                    { id: 'assign', label: '5. Assign Technician' },
                    { id: 'history', label: '6. Ticket History' },
                    { id: 'reports', label: '7. Reports & CSV' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setAdminTab(item.id as typeof adminTab)}
                      className={`w-full text-left px-3 py-2 rounded text-xs font-medium transition-colors ${
                        adminTab === item.id ? 'bg-[#00A8E8] text-white' : 'text-slate-200 hover:bg-[#2E6F95]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </nav>
              )}

              {currentUser.role === 'USER' && (
                <nav className="space-y-1">
                  {[
                    { id: 'dashboard', label: '1. Dashboard' },
                    { id: 'create', label: '2. Create New Ticket' },
                    { id: 'mytickets', label: '3. My Tickets' },
                    { id: 'track', label: '4. Track Ticket' },
                    { id: 'profile', label: '5. My Profile' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setUserTab(item.id as typeof userTab)}
                      className={`w-full text-left px-3 py-2 rounded text-xs font-medium transition-colors ${
                        userTab === item.id ? 'bg-[#00A8E8] text-white' : 'text-slate-200 hover:bg-[#2E6F95]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </nav>
              )}

              {currentUser.role === 'TECHNICIAN' && (
                <nav className="space-y-1">
                  {[
                    { id: 'dashboard', label: '1. Assigned Tickets' },
                    { id: 'resolve', label: '2. Ticket Resolution Form' },
                  ].map((item) => (
                    <button
                      key={item.id}
                      onClick={() => setTechTab(item.id as typeof techTab)}
                      className={`w-full text-left px-3 py-2 rounded text-xs font-medium transition-colors ${
                        techTab === item.id ? 'bg-[#00A8E8] text-white' : 'text-slate-200 hover:bg-[#2E6F95]'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </nav>
              )}
            </div>

            <button
              onClick={() => setCurrentUser(null)}
              className="w-full mt-6 px-3 py-2 bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold rounded"
            >
              Logout ({currentUser.username})
            </button>
          </div>

          {/* MAIN WORKSPACE */}
          <div className="md:col-span-9 p-6 space-y-6 overflow-x-auto">
            {/* ==================== ADMIN VIEWS ==================== */}
            {currentUser.role === 'ADMIN' && adminTab === 'dashboard' && (
              <div className="space-y-6">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Admin Dashboard (AdminDashboard.java)</h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { label: 'Total Users', val: users.length },
                    { label: 'Total Technicians', val: technicians.length },
                    { label: 'Total Tickets', val: tickets.length },
                    { label: 'Open Tickets', val: tickets.filter((t) => t.status === 'OPEN').length },
                    { label: 'Assigned Tickets', val: tickets.filter((t) => t.status === 'ASSIGNED').length },
                    { label: 'In Progress', val: tickets.filter((t) => t.status === 'IN_PROGRESS').length },
                    { label: 'Resolved Tickets', val: tickets.filter((t) => t.status === 'RESOLVED').length },
                    { label: 'Closed Tickets', val: tickets.filter((t) => t.status === 'CLOSED').length },
                  ].map((stat) => (
                    <div key={stat.label} className="bg-white border border-slate-200 rounded p-3.5">
                      <div className="text-xs text-slate-500">{stat.label}</div>
                      <div className="text-2xl font-bold font-mono tabular-nums text-[#1E3A5F] mt-1">{stat.val}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'tickets' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">All Tickets Management (ManageTicketsFrame.java)</h3>
                <div className="flex flex-wrap gap-2 bg-white p-3 border border-slate-200 rounded">
                  <input
                    type="text"
                    placeholder="Search Ticket ID or Subject..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="px-3 py-1.5 text-xs border border-slate-300 rounded flex-1 min-w-[180px]"
                  />
                  <select
                    value={statusFilter}
                    onChange={(e) => setStatusFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                  >
                    <option value="ALL">All Statuses</option>
                    {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <select
                    value={priorityFilter}
                    onChange={(e) => setPriorityFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                  >
                    <option value="ALL">All Priorities</option>
                    {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
                  </select>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                    className="px-2.5 py-1.5 text-xs border border-slate-300 rounded"
                  >
                    <option value="ALL">All Categories</option>
                    {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>

                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5 font-semibold">Ticket ID</th>
                        <th className="p-2.5 font-semibold">Subject</th>
                        <th className="p-2.5 font-semibold">Category</th>
                        <th className="p-2.5 font-semibold">Priority</th>
                        <th className="p-2.5 font-semibold">User</th>
                        <th className="p-2.5 font-semibold">Technician</th>
                        <th className="p-2.5 font-semibold">Status</th>
                        <th className="p-2.5 font-semibold">Created</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredTickets.map((t) => (
                        <tr key={t.ticketId} className="hover:bg-slate-50">
                          <td className="p-2.5 font-mono font-semibold text-[#1E3A5F]">{t.ticketId}</td>
                          <td className="p-2.5">{t.subject}</td>
                          <td className="p-2.5">{t.category}</td>
                          <td className="p-2.5 font-medium">{t.priority}</td>
                          <td className="p-2.5">{getUserName(t.userId)}</td>
                          <td className="p-2.5">{getTechName(t.technicianId)}</td>
                          <td className="p-2.5 font-mono font-semibold">{t.status}</td>
                          <td className="p-2.5 font-mono text-slate-500">{t.createdAt}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'assign' && (
              <div className="space-y-4 max-w-xl">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Assign Technician to Ticket</h3>
                <form onSubmit={handleAssignTechnician} className="bg-white p-5 border border-slate-200 rounded space-y-4">
                  <div>
                    <label className="block text-xs font-semibold mb-1">Select Ticket</label>
                    <select
                      value={selectedOpenTicketId}
                      onChange={(e) => setSelectedOpenTicketId(e.target.value)}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded"
                    >
                      {tickets.map((t) => (
                        <option key={t.ticketId} value={t.ticketId}>
                          {t.ticketId} — {t.subject} [{t.status} / {t.priority}]
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold mb-1">Select Available Technician (Active Only Allowed)</label>
                    <select
                      value={selectedTechId}
                      onChange={(e) => setSelectedTechId(Number(e.target.value))}
                      className="w-full px-3 py-2 text-xs border border-slate-300 rounded"
                    >
                      {technicians.map((tech) => (
                        <option key={tech.technicianId} value={tech.technicianId}>
                          Tech #{tech.technicianId} - {tech.name} ({tech.specialization}) [{tech.status}]
                        </option>
                      ))}
                    </select>
                  </div>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-[#1E3A5F] text-white text-xs font-semibold rounded hover:bg-[#2E6F95]"
                  >
                    Assign Technician & Set Status = ASSIGNED
                  </button>
                </form>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'users' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Manage Users (ManageUsersFrame.java)</h3>
                <form onSubmit={handleAddUser} className="bg-white p-4 border border-slate-200 rounded grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input type="text" placeholder="Full Name" value={uName} onChange={(e) => setUName(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="email" placeholder="Email Address" value={uEmail} onChange={(e) => setUEmail(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="text" placeholder="Phone (10 digits)" value={uPhone} onChange={(e) => setUPhone(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="text" placeholder="Department" value={uDept} onChange={(e) => setUDept(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="text" placeholder="Username" value={uUsername} onChange={(e) => setUUsername(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <div className="flex gap-2">
                    <select value={uRole} onChange={(e) => setURole(e.target.value as 'ADMIN' | 'TECHNICIAN' | 'USER')} className="px-2 py-1.5 text-xs border border-slate-300 rounded flex-1">
                      <option value="USER">USER</option>
                      <option value="TECHNICIAN">TECHNICIAN</option>
                      <option value="ADMIN">ADMIN</option>
                    </select>
                    <button type="submit" className="px-3 py-1.5 bg-[#1E3A5F] text-white text-xs font-semibold rounded">Add User</button>
                  </div>
                </form>

                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5">ID</th>
                        <th className="p-2.5">Name</th>
                        <th className="p-2.5">Email</th>
                        <th className="p-2.5">Phone</th>
                        <th className="p-2.5">Department</th>
                        <th className="p-2.5">Username</th>
                        <th className="p-2.5">Role</th>
                        <th className="p-2.5">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {users.map((u) => (
                        <tr key={u.userId}>
                          <td className="p-2.5 font-mono">{u.userId}</td>
                          <td className="p-2.5 font-medium">{u.name}</td>
                          <td className="p-2.5">{u.email}</td>
                          <td className="p-2.5 font-mono">{u.phone}</td>
                          <td className="p-2.5">{u.department}</td>
                          <td className="p-2.5 font-mono">{u.username}</td>
                          <td className="p-2.5 font-mono">{u.role}</td>
                          <td className="p-2.5 font-mono">{u.status}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'technicians' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Manage Technicians (ManageTechniciansFrame.java)</h3>
                <form onSubmit={handleAddTechnician} className="bg-white p-4 border border-slate-200 rounded grid grid-cols-1 sm:grid-cols-4 gap-3">
                  <input type="text" placeholder="Technician Name" value={tName} onChange={(e) => setTName(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="email" placeholder="Email" value={tEmail} onChange={(e) => setTEmail(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <input type="text" placeholder="Phone" value={tPhone} onChange={(e) => setTPhone(e.target.value)} className="px-3 py-1.5 text-xs border border-slate-300 rounded" />
                  <div className="flex gap-2">
                    <select value={tSpec} onChange={(e) => setTSpec(e.target.value as Specialization)} className="px-2 py-1.5 text-xs border border-slate-300 rounded flex-1">
                      {SPECIALIZATIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                    </select>
                    <button type="submit" className="px-3 py-1.5 bg-[#1E3A5F] text-white text-xs font-semibold rounded">Add</button>
                  </div>
                </form>

                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5">Tech ID</th>
                        <th className="p-2.5">Name</th>
                        <th className="p-2.5">Email</th>
                        <th className="p-2.5">Phone</th>
                        <th className="p-2.5">Specialization</th>
                        <th className="p-2.5">Status</th>
                        <th className="p-2.5">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {technicians.map((t) => (
                        <tr key={t.technicianId}>
                          <td className="p-2.5 font-mono">{t.technicianId}</td>
                          <td className="p-2.5 font-medium">{t.name}</td>
                          <td className="p-2.5">{t.email}</td>
                          <td className="p-2.5 font-mono">{t.phone}</td>
                          <td className="p-2.5">{t.specialization}</td>
                          <td className="p-2.5 font-mono font-semibold">{t.status}</td>
                          <td className="p-2.5">
                            <button
                              onClick={() => toggleTechStatus(t.technicianId)}
                              className="px-2.5 py-1 bg-[#2E6F95] text-white rounded text-xs"
                            >
                              Toggle Active
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'history' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Chronological Ticket History (TicketHistoryFrame.java)</h3>
                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5">ID</th>
                        <th className="p-2.5">Ticket ID</th>
                        <th className="p-2.5">Previous</th>
                        <th className="p-2.5">New Status</th>
                        <th className="p-2.5">Changed By</th>
                        <th className="p-2.5">Description</th>
                        <th className="p-2.5">Timestamp</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {history.map((h) => (
                        <tr key={h.historyId}>
                          <td className="p-2.5 font-mono">{h.historyId}</td>
                          <td className="p-2.5 font-mono font-semibold">{h.ticketId}</td>
                          <td className="p-2.5 font-mono">{h.previousStatus || 'NONE'}</td>
                          <td className="p-2.5 font-mono font-semibold">{h.newStatus}</td>
                          <td className="p-2.5">{getUserName(h.changedBy)}</td>
                          <td className="p-2.5">{h.changeDescription}</td>
                          <td className="p-2.5 font-mono text-slate-500">{h.changedAt}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'ADMIN' && adminTab === 'reports' && (
              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-[#1E3A5F]">SQL Aggregate Reports & CSV Export</h3>
                  <button
                    onClick={exportReportsCsv}
                    className="px-4 py-2 bg-[#00A8E8] text-white text-xs font-semibold rounded hover:bg-[#2E6F95]"
                  >
                    Export Report to CSV
                  </button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                  <div className="bg-white p-4 border border-slate-200 rounded space-y-2">
                    <div className="font-bold text-[#1E3A5F] border-b pb-1">Tickets by Category</div>
                    {CATEGORIES.map((c) => (
                      <div key={c} className="flex justify-between font-mono">
                        <span>{c}</span>
                        <span>{tickets.filter((t) => t.category === c).length}</span>
                      </div>
                    ))}
                  </div>
                  <div className="bg-white p-4 border border-slate-200 rounded space-y-2">
                    <div className="font-bold text-[#1E3A5F] border-b pb-1">Tickets by Priority</div>
                    {PRIORITIES.map((p) => (
                      <div key={p} className="flex justify-between font-mono">
                        <span>{p}</span>
                        <span>{tickets.filter((t) => t.priority === p).length}</span>
                      </div>
                    ))}
                  </div>
                  <div className="bg-white p-4 border border-slate-200 rounded space-y-2">
                    <div className="font-bold text-[#1E3A5F] border-b pb-1">Tickets Handled by Technician</div>
                    {technicians.map((tech) => (
                      <div key={tech.technicianId} className="flex justify-between font-mono">
                        <span>{tech.name}</span>
                        <span>{tickets.filter((t) => t.technicianId === tech.technicianId).length}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* ==================== USER VIEWS ==================== */}
            {currentUser.role === 'USER' && userTab === 'dashboard' && (
              <div className="space-y-5">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Welcome, {currentUser.name} (UserDashboard.java)</h3>
                <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                  {(() => {
                    const my = tickets.filter((t) => t.userId === currentUser.userId);
                    return [
                      { label: 'Total Tickets', val: my.length },
                      { label: 'Open', val: my.filter((t) => t.status === 'OPEN').length },
                      { label: 'In Progress', val: my.filter((t) => t.status === 'IN_PROGRESS' || t.status === 'ASSIGNED').length },
                      { label: 'Resolved', val: my.filter((t) => t.status === 'RESOLVED').length },
                      { label: 'Closed', val: my.filter((t) => t.status === 'CLOSED').length },
                    ].map((s) => (
                      <div key={s.label} className="bg-white p-3.5 border border-slate-200 rounded">
                        <div className="text-xs text-slate-500">{s.label}</div>
                        <div className="text-2xl font-bold font-mono text-[#1E3A5F] mt-1">{s.val}</div>
                      </div>
                    ));
                  })()}
                </div>
              </div>
            )}

            {currentUser.role === 'USER' && userTab === 'create' && (
              <div className="space-y-4 max-w-xl">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Create Support Ticket (CreateTicketFrame.java)</h3>
                <form onSubmit={handleCreateTicket} className="bg-white p-5 border border-slate-200 rounded space-y-4 text-xs">
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Ticket ID (Auto-Generated)</label>
                      <input
                        type="text"
                        disabled
                        value={`HD-2026-${String(tickets.length + 1).padStart(4, '0')}`}
                        className="w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded font-mono"
                      />
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Reported By</label>
                      <input type="text" disabled value={currentUser.name} className="w-full px-3 py-2 bg-slate-100 border border-slate-300 rounded" />
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Subject</label>
                    <input
                      type="text"
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      placeholder="Brief summary of technical issue..."
                      className="w-full px-3 py-2 border border-slate-300 rounded"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block font-semibold mb-1">Category</label>
                      <select value={newCategory} onChange={(e) => setNewCategory(e.target.value as TicketCategory)} className="w-full px-3 py-2 border border-slate-300 rounded">
                        {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="block font-semibold mb-1">Priority</label>
                      <select value={newPriority} onChange={(e) => setNewPriority(e.target.value as TicketPriority)} className="w-full px-3 py-2 border border-slate-300 rounded">
                        {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
                      </select>
                    </div>
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Problem Description</label>
                    <textarea
                      rows={3}
                      value={newDesc}
                      onChange={(e) => setNewDesc(e.target.value)}
                      placeholder="Detailed steps, error messages, workstation number..."
                      className="w-full px-3 py-2 border border-slate-300 rounded"
                    />
                  </div>
                  <button type="submit" className="px-4 py-2 bg-[#1E3A5F] text-white font-semibold rounded hover:bg-[#2E6F95]">
                    Submit Ticket
                  </button>
                </form>
              </div>
            )}

            {currentUser.role === 'USER' && userTab === 'mytickets' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">My Tickets (MyTicketsFrame.java)</h3>
                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5">Ticket ID</th>
                        <th className="p-2.5">Subject</th>
                        <th className="p-2.5">Category</th>
                        <th className="p-2.5">Priority</th>
                        <th className="p-2.5">Technician</th>
                        <th className="p-2.5">Status</th>
                        <th className="p-2.5">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {tickets
                        .filter((t) => t.userId === currentUser.userId)
                        .map((t) => (
                          <tr key={t.ticketId}>
                            <td className="p-2.5 font-mono font-semibold">{t.ticketId}</td>
                            <td className="p-2.5">{t.subject}</td>
                            <td className="p-2.5">{t.category}</td>
                            <td className="p-2.5">{t.priority}</td>
                            <td className="p-2.5">{getTechName(t.technicianId)}</td>
                            <td className="p-2.5 font-mono font-semibold">{t.status}</td>
                            <td className="p-2.5 flex gap-2">
                              <button
                                onClick={() => {
                                  setTrackTicketId(t.ticketId);
                                  setUserTab('track');
                                }}
                                className="px-2.5 py-1 bg-[#2E6F95] text-white rounded"
                              >
                                Track
                              </button>
                              {t.status === 'RESOLVED' && (
                                <button
                                  onClick={() => handleTechStatusUpdate(t.ticketId, 'CLOSED', 'User confirmed resolution and closed ticket.')}
                                  className="px-2.5 py-1 bg-emerald-700 text-white rounded"
                                >
                                  Confirm & Close
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'USER' && userTab === 'track' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Visual Ticket Status Tracker (TicketDetailsFrame.java)</h3>
                <div className="flex gap-2 max-w-md">
                  <input
                    type="text"
                    value={trackTicketId}
                    onChange={(e) => setTrackTicketId(e.target.value)}
                    placeholder="Enter Ticket ID (e.g. HD-2026-0001)"
                    className="px-3 py-2 text-xs border border-slate-300 rounded flex-1 font-mono"
                  />
                </div>
                {(() => {
                  const found = tickets.find((t) => t.ticketId.toUpperCase() === trackTicketId.trim().toUpperCase());
                  if (!found) {
                    return <div className="p-4 bg-white border border-slate-200 rounded text-xs text-rose-600">Ticket ID not found.</div>;
                  }
                  const activeIdx = STATUSES.indexOf(found.status);
                  return (
                    <div className="bg-white p-5 border border-slate-200 rounded space-y-5 text-xs">
                      {/* Visual Status Pipeline */}
                      <div className="grid grid-cols-5 gap-2">
                        {STATUSES.map((st, idx) => (
                          <div
                            key={st}
                            className={`p-2.5 text-center rounded font-mono font-semibold border ${
                              idx === activeIdx
                                ? 'bg-[#00A8E8] text-white border-[#00A8E8]'
                                : idx < activeIdx
                                ? 'bg-[#1E3A5F] text-white border-[#1E3A5F]'
                                : 'bg-slate-100 text-slate-400 border-slate-200'
                            }`}
                          >
                            {st}
                          </div>
                        ))}
                      </div>
                      <div className="grid grid-cols-2 gap-3 pt-2">
                        <div><strong>Ticket ID:</strong> <span className="font-mono">{found.ticketId}</span></div>
                        <div><strong>Status:</strong> <span className="font-mono">{found.status}</span></div>
                        <div><strong>Subject:</strong> {found.subject}</div>
                        <div><strong>Category / Priority:</strong> {found.category} · {found.priority}</div>
                        <div><strong>Assigned Technician:</strong> {getTechName(found.technicianId)}</div>
                        <div><strong>Created / Updated:</strong> <span className="font-mono">{found.createdAt}</span></div>
                      </div>
                      <div className="p-3 bg-slate-50 border border-slate-200 rounded">
                        <strong>Resolution Details:</strong> {found.resolutionDetails || 'Pending resolution by assigned technician.'}
                      </div>
                    </div>
                  );
                })()}
              </div>
            )}

            {currentUser.role === 'USER' && userTab === 'profile' && (
              <div className="bg-white p-5 border border-slate-200 rounded max-w-md space-y-2 text-xs">
                <h3 className="text-base font-bold text-[#1E3A5F] pb-2 border-b">User Profile</h3>
                <div><strong>User ID:</strong> <span className="font-mono">{currentUser.userId}</span></div>
                <div><strong>Name:</strong> {currentUser.name}</div>
                <div><strong>Email:</strong> {currentUser.email}</div>
                <div><strong>Phone:</strong> <span className="font-mono">{currentUser.phone}</span></div>
                <div><strong>Department:</strong> {currentUser.department}</div>
                <div><strong>Role:</strong> <span className="font-mono">{currentUser.role}</span></div>
              </div>
            )}

            {/* ==================== TECHNICIAN VIEWS ==================== */}
            {currentUser.role === 'TECHNICIAN' && techTab === 'dashboard' && (
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-[#1E3A5F]">
                  Technician Dashboard (TechnicianDashboard.java) — {currentTechObj?.name} [{currentTechObj?.specialization}]
                </h3>
                <div className="bg-white border border-slate-200 rounded overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-[#1E3A5F] text-white">
                        <th className="p-2.5">Ticket ID</th>
                        <th className="p-2.5">Subject</th>
                        <th className="p-2.5">Priority</th>
                        <th className="p-2.5">Status</th>
                        <th className="p-2.5">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {tickets
                        .filter((t) => !currentTechObj || t.technicianId === currentTechObj.technicianId)
                        .map((t) => (
                          <tr key={t.ticketId}>
                            <td className="p-2.5 font-mono font-semibold">{t.ticketId}</td>
                            <td className="p-2.5">{t.subject}</td>
                            <td className="p-2.5 font-semibold">{t.priority}</td>
                            <td className="p-2.5 font-mono">{t.status}</td>
                            <td className="p-2.5 flex gap-2">
                              {t.status === 'ASSIGNED' && (
                                <button
                                  onClick={() => handleTechStatusUpdate(t.ticketId, 'IN_PROGRESS', `Technician ${currentUser.name} accepted ticket and started work.`)}
                                  className="px-2.5 py-1 bg-[#2E6F95] text-white rounded"
                                >
                                  Accept & Start Work
                                </button>
                              )}
                              {t.status !== 'CLOSED' && (
                                <button
                                  onClick={() => {
                                    setResolveTicketId(t.ticketId);
                                    setTechTab('resolve');
                                  }}
                                  className="px-2.5 py-1 bg-[#00A8E8] text-white rounded"
                                >
                                  Add Resolution
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {currentUser.role === 'TECHNICIAN' && techTab === 'resolve' && (
              <div className="space-y-4 max-w-xl">
                <h3 className="text-lg font-bold text-[#1E3A5F]">Ticket Resolution Form</h3>
                <form onSubmit={handleResolveSubmit} className="bg-white p-5 border border-slate-200 rounded space-y-4 text-xs">
                  <div>
                    <label className="block font-semibold mb-1">Select Assigned Ticket</label>
                    <select
                      value={resolveTicketId}
                      onChange={(e) => setResolveTicketId(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono"
                    >
                      {tickets.map((t) => (
                        <option key={t.ticketId} value={t.ticketId}>
                          {t.ticketId} — {t.subject} ({t.status})
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block font-semibold mb-1">Resolution Details</label>
                    <textarea
                      rows={4}
                      value={resolutionText}
                      onChange={(e) => setResolutionText(e.target.value)}
                      placeholder="Describe root cause, parts replaced, or configuration applied..."
                      className="w-full px-3 py-2 border border-slate-300 rounded"
                    />
                  </div>
                  <button type="submit" className="px-4 py-2 bg-[#1E3A5F] text-white font-semibold rounded hover:bg-[#2E6F95]">
                    Mark Ticket as RESOLVED
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
